var Co = { value: () => {
} };
function Cl() {
  for (var t = 0, e = arguments.length, n = {}, i; t < e; ++t) {
    if (!(i = arguments[t] + "") || i in n || /[\s.]/.test(i)) throw new Error("illegal type: " + i);
    n[i] = [];
  }
  return new $t(n);
}
function $t(t) {
  this._ = t;
}
function Eo(t, e) {
  return t.trim().split(/^|\s+/).map(function(n) {
    var i = "", l = n.indexOf(".");
    if (l >= 0 && (i = n.slice(l + 1), n = n.slice(0, l)), n && !e.hasOwnProperty(n)) throw new Error("unknown type: " + n);
    return { type: n, name: i };
  });
}
$t.prototype = Cl.prototype = {
  constructor: $t,
  on: function(t, e) {
    var n = this._, i = Eo(t + "", n), l, o = -1, s = i.length;
    if (arguments.length < 2) {
      for (; ++o < s; ) if ((l = (t = i[o]).type) && (l = No(n[l], t.name))) return l;
      return;
    }
    if (e != null && typeof e != "function") throw new Error("invalid callback: " + e);
    for (; ++o < s; )
      if (l = (t = i[o]).type) n[l] = hi(n[l], t.name, e);
      else if (e == null) for (l in n) n[l] = hi(n[l], t.name, null);
    return this;
  },
  copy: function() {
    var t = {}, e = this._;
    for (var n in e) t[n] = e[n].slice();
    return new $t(t);
  },
  call: function(t, e) {
    if ((l = arguments.length - 2) > 0) for (var n = new Array(l), i = 0, l, o; i < l; ++i) n[i] = arguments[i + 2];
    if (!this._.hasOwnProperty(t)) throw new Error("unknown type: " + t);
    for (o = this._[t], i = 0, l = o.length; i < l; ++i) o[i].value.apply(e, n);
  },
  apply: function(t, e, n) {
    if (!this._.hasOwnProperty(t)) throw new Error("unknown type: " + t);
    for (var i = this._[t], l = 0, o = i.length; l < o; ++l) i[l].value.apply(e, n);
  }
};
function No(t, e) {
  for (var n = 0, i = t.length, l; n < i; ++n)
    if ((l = t[n]).name === e)
      return l.value;
}
function hi(t, e, n) {
  for (var i = 0, l = t.length; i < l; ++i)
    if (t[i].name === e) {
      t[i] = Co, t = t.slice(0, i).concat(t.slice(i + 1));
      break;
    }
  return n != null && t.push({ name: e, value: n }), t;
}
var Wn = "http://www.w3.org/1999/xhtml";
const mi = {
  svg: "http://www.w3.org/2000/svg",
  xhtml: Wn,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};
function El(t) {
  var e = t += "", n = e.indexOf(":");
  return n >= 0 && (e = t.slice(0, n)) !== "xmlns" && (t = t.slice(n + 1)), mi.hasOwnProperty(e) ? { space: mi[e], local: t } : t;
}
function Ao(t) {
  return function() {
    var e = this.ownerDocument, n = this.namespaceURI;
    return n === Wn && e.documentElement.namespaceURI === Wn ? e.createElement(t) : e.createElementNS(n, t);
  };
}
function zo(t) {
  return function() {
    return this.ownerDocument.createElementNS(t.space, t.local);
  };
}
function Nl(t) {
  var e = El(t);
  return (e.local ? zo : Ao)(e);
}
function Lo() {
}
function Al(t) {
  return t == null ? Lo : function() {
    return this.querySelector(t);
  };
}
function Do(t) {
  typeof t != "function" && (t = Al(t));
  for (var e = this._groups, n = e.length, i = new Array(n), l = 0; l < n; ++l)
    for (var o = e[l], s = o.length, r = i[l] = new Array(s), a, u, f = 0; f < s; ++f)
      (a = o[f]) && (u = t.call(a, a.__data__, f, o)) && ("__data__" in a && (u.__data__ = a.__data__), r[f] = u);
  return new be(i, this._parents);
}
function Fo(t) {
  return t == null ? [] : Array.isArray(t) ? t : Array.from(t);
}
function Oo() {
  return [];
}
function Io(t) {
  return t == null ? Oo : function() {
    return this.querySelectorAll(t);
  };
}
function To(t) {
  return function() {
    return Fo(t.apply(this, arguments));
  };
}
function Bo(t) {
  typeof t == "function" ? t = To(t) : t = Io(t);
  for (var e = this._groups, n = e.length, i = [], l = [], o = 0; o < n; ++o)
    for (var s = e[o], r = s.length, a, u = 0; u < r; ++u)
      (a = s[u]) && (i.push(t.call(a, a.__data__, u, s)), l.push(a));
  return new be(i, l);
}
function Po(t) {
  return function() {
    return this.matches(t);
  };
}
function zl(t) {
  return function(e) {
    return e.matches(t);
  };
}
var Mo = Array.prototype.find;
function Ro(t) {
  return function() {
    return Mo.call(this.children, t);
  };
}
function Uo() {
  return this.firstElementChild;
}
function jo(t) {
  return this.select(t == null ? Uo : Ro(typeof t == "function" ? t : zl(t)));
}
var Vo = Array.prototype.filter;
function Wo() {
  return Array.from(this.children);
}
function Xo(t) {
  return function() {
    return Vo.call(this.children, t);
  };
}
function Go(t) {
  return this.selectAll(t == null ? Wo : Xo(typeof t == "function" ? t : zl(t)));
}
function Jo(t) {
  typeof t != "function" && (t = Po(t));
  for (var e = this._groups, n = e.length, i = new Array(n), l = 0; l < n; ++l)
    for (var o = e[l], s = o.length, r = i[l] = [], a, u = 0; u < s; ++u)
      (a = o[u]) && t.call(a, a.__data__, u, o) && r.push(a);
  return new be(i, this._parents);
}
function Ll(t) {
  return new Array(t.length);
}
function Yo() {
  return new be(this._enter || this._groups.map(Ll), this._parents);
}
function ln(t, e) {
  this.ownerDocument = t.ownerDocument, this.namespaceURI = t.namespaceURI, this._next = null, this._parent = t, this.__data__ = e;
}
ln.prototype = {
  constructor: ln,
  appendChild: function(t) {
    return this._parent.insertBefore(t, this._next);
  },
  insertBefore: function(t, e) {
    return this._parent.insertBefore(t, e);
  },
  querySelector: function(t) {
    return this._parent.querySelector(t);
  },
  querySelectorAll: function(t) {
    return this._parent.querySelectorAll(t);
  }
};
function Ko(t) {
  return function() {
    return t;
  };
}
function Ho(t, e, n, i, l, o) {
  for (var s = 0, r, a = e.length, u = o.length; s < u; ++s)
    (r = e[s]) ? (r.__data__ = o[s], i[s] = r) : n[s] = new ln(t, o[s]);
  for (; s < a; ++s)
    (r = e[s]) && (l[s] = r);
}
function Zo(t, e, n, i, l, o, s) {
  var r, a, u = /* @__PURE__ */ new Map(), f = e.length, c = o.length, _ = new Array(f), d;
  for (r = 0; r < f; ++r)
    (a = e[r]) && (_[r] = d = s.call(a, a.__data__, r, e) + "", u.has(d) ? l[r] = a : u.set(d, a));
  for (r = 0; r < c; ++r)
    d = s.call(t, o[r], r, o) + "", (a = u.get(d)) ? (i[r] = a, a.__data__ = o[r], u.delete(d)) : n[r] = new ln(t, o[r]);
  for (r = 0; r < f; ++r)
    (a = e[r]) && u.get(_[r]) === a && (l[r] = a);
}
function Qo(t) {
  return t.__data__;
}
function $o(t, e) {
  if (!arguments.length) return Array.from(this, Qo);
  var n = e ? Zo : Ho, i = this._parents, l = this._groups;
  typeof t != "function" && (t = Ko(t));
  for (var o = l.length, s = new Array(o), r = new Array(o), a = new Array(o), u = 0; u < o; ++u) {
    var f = i[u], c = l[u], _ = c.length, d = xo(t.call(f, f && f.__data__, u, i)), h = d.length, k = r[u] = new Array(h), y = s[u] = new Array(h), p = a[u] = new Array(_);
    n(f, c, k, y, p, d, e);
    for (var v = 0, b = 0, m, g; v < h; ++v)
      if (m = k[v]) {
        for (v >= b && (b = v + 1); !(g = y[b]) && ++b < h; ) ;
        m._next = g || null;
      }
  }
  return s = new be(s, i), s._enter = r, s._exit = a, s;
}
function xo(t) {
  return typeof t == "object" && "length" in t ? t : Array.from(t);
}
function es() {
  return new be(this._exit || this._groups.map(Ll), this._parents);
}
function ts(t, e, n) {
  var i = this.enter(), l = this, o = this.exit();
  return typeof t == "function" ? (i = t(i), i && (i = i.selection())) : i = i.append(t + ""), e != null && (l = e(l), l && (l = l.selection())), n == null ? o.remove() : n(o), i && l ? i.merge(l).order() : l;
}
function ns(t) {
  for (var e = t.selection ? t.selection() : t, n = this._groups, i = e._groups, l = n.length, o = i.length, s = Math.min(l, o), r = new Array(l), a = 0; a < s; ++a)
    for (var u = n[a], f = i[a], c = u.length, _ = r[a] = new Array(c), d, h = 0; h < c; ++h)
      (d = u[h] || f[h]) && (_[h] = d);
  for (; a < l; ++a)
    r[a] = n[a];
  return new be(r, this._parents);
}
function is() {
  for (var t = this._groups, e = -1, n = t.length; ++e < n; )
    for (var i = t[e], l = i.length - 1, o = i[l], s; --l >= 0; )
      (s = i[l]) && (o && s.compareDocumentPosition(o) ^ 4 && o.parentNode.insertBefore(s, o), o = s);
  return this;
}
function ls(t) {
  t || (t = os);
  function e(c, _) {
    return c && _ ? t(c.__data__, _.__data__) : !c - !_;
  }
  for (var n = this._groups, i = n.length, l = new Array(i), o = 0; o < i; ++o) {
    for (var s = n[o], r = s.length, a = l[o] = new Array(r), u, f = 0; f < r; ++f)
      (u = s[f]) && (a[f] = u);
    a.sort(e);
  }
  return new be(l, this._parents).order();
}
function os(t, e) {
  return t < e ? -1 : t > e ? 1 : t >= e ? 0 : NaN;
}
function ss() {
  var t = arguments[0];
  return arguments[0] = this, t.apply(null, arguments), this;
}
function rs() {
  return Array.from(this);
}
function as() {
  for (var t = this._groups, e = 0, n = t.length; e < n; ++e)
    for (var i = t[e], l = 0, o = i.length; l < o; ++l) {
      var s = i[l];
      if (s) return s;
    }
  return null;
}
function us() {
  let t = 0;
  for (const e of this) ++t;
  return t;
}
function fs() {
  return !this.node();
}
function cs(t) {
  for (var e = this._groups, n = 0, i = e.length; n < i; ++n)
    for (var l = e[n], o = 0, s = l.length, r; o < s; ++o)
      (r = l[o]) && t.call(r, r.__data__, o, l);
  return this;
}
function _s(t) {
  return function() {
    this.removeAttribute(t);
  };
}
function ds(t) {
  return function() {
    this.removeAttributeNS(t.space, t.local);
  };
}
function hs(t, e) {
  return function() {
    this.setAttribute(t, e);
  };
}
function ms(t, e) {
  return function() {
    this.setAttributeNS(t.space, t.local, e);
  };
}
function gs(t, e) {
  return function() {
    var n = e.apply(this, arguments);
    n == null ? this.removeAttribute(t) : this.setAttribute(t, n);
  };
}
function ps(t, e) {
  return function() {
    var n = e.apply(this, arguments);
    n == null ? this.removeAttributeNS(t.space, t.local) : this.setAttributeNS(t.space, t.local, n);
  };
}
function bs(t, e) {
  var n = El(t);
  if (arguments.length < 2) {
    var i = this.node();
    return n.local ? i.getAttributeNS(n.space, n.local) : i.getAttribute(n);
  }
  return this.each((e == null ? n.local ? ds : _s : typeof e == "function" ? n.local ? ps : gs : n.local ? ms : hs)(n, e));
}
function Dl(t) {
  return t.ownerDocument && t.ownerDocument.defaultView || t.document && t || t.defaultView;
}
function ws(t) {
  return function() {
    this.style.removeProperty(t);
  };
}
function vs(t, e, n) {
  return function() {
    this.style.setProperty(t, e, n);
  };
}
function ys(t, e, n) {
  return function() {
    var i = e.apply(this, arguments);
    i == null ? this.style.removeProperty(t) : this.style.setProperty(t, i, n);
  };
}
function ks(t, e, n) {
  return arguments.length > 1 ? this.each((e == null ? ws : typeof e == "function" ? ys : vs)(t, e, n ?? "")) : Ss(this.node(), t);
}
function Ss(t, e) {
  return t.style.getPropertyValue(e) || Dl(t).getComputedStyle(t, null).getPropertyValue(e);
}
function qs(t) {
  return function() {
    delete this[t];
  };
}
function Cs(t, e) {
  return function() {
    this[t] = e;
  };
}
function Es(t, e) {
  return function() {
    var n = e.apply(this, arguments);
    n == null ? delete this[t] : this[t] = n;
  };
}
function Ns(t, e) {
  return arguments.length > 1 ? this.each((e == null ? qs : typeof e == "function" ? Es : Cs)(t, e)) : this.node()[t];
}
function Fl(t) {
  return t.trim().split(/^|\s+/);
}
function ii(t) {
  return t.classList || new Ol(t);
}
function Ol(t) {
  this._node = t, this._names = Fl(t.getAttribute("class") || "");
}
Ol.prototype = {
  add: function(t) {
    var e = this._names.indexOf(t);
    e < 0 && (this._names.push(t), this._node.setAttribute("class", this._names.join(" ")));
  },
  remove: function(t) {
    var e = this._names.indexOf(t);
    e >= 0 && (this._names.splice(e, 1), this._node.setAttribute("class", this._names.join(" ")));
  },
  contains: function(t) {
    return this._names.indexOf(t) >= 0;
  }
};
function Il(t, e) {
  for (var n = ii(t), i = -1, l = e.length; ++i < l; ) n.add(e[i]);
}
function Tl(t, e) {
  for (var n = ii(t), i = -1, l = e.length; ++i < l; ) n.remove(e[i]);
}
function As(t) {
  return function() {
    Il(this, t);
  };
}
function zs(t) {
  return function() {
    Tl(this, t);
  };
}
function Ls(t, e) {
  return function() {
    (e.apply(this, arguments) ? Il : Tl)(this, t);
  };
}
function Ds(t, e) {
  var n = Fl(t + "");
  if (arguments.length < 2) {
    for (var i = ii(this.node()), l = -1, o = n.length; ++l < o; ) if (!i.contains(n[l])) return !1;
    return !0;
  }
  return this.each((typeof e == "function" ? Ls : e ? As : zs)(n, e));
}
function Fs() {
  this.textContent = "";
}
function Os(t) {
  return function() {
    this.textContent = t;
  };
}
function Is(t) {
  return function() {
    var e = t.apply(this, arguments);
    this.textContent = e ?? "";
  };
}
function Ts(t) {
  return arguments.length ? this.each(t == null ? Fs : (typeof t == "function" ? Is : Os)(t)) : this.node().textContent;
}
function Bs() {
  this.innerHTML = "";
}
function Ps(t) {
  return function() {
    this.innerHTML = t;
  };
}
function Ms(t) {
  return function() {
    var e = t.apply(this, arguments);
    this.innerHTML = e ?? "";
  };
}
function Rs(t) {
  return arguments.length ? this.each(t == null ? Bs : (typeof t == "function" ? Ms : Ps)(t)) : this.node().innerHTML;
}
function Us() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function js() {
  return this.each(Us);
}
function Vs() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function Ws() {
  return this.each(Vs);
}
function Xs(t) {
  var e = typeof t == "function" ? t : Nl(t);
  return this.select(function() {
    return this.appendChild(e.apply(this, arguments));
  });
}
function Gs() {
  return null;
}
function Js(t, e) {
  var n = typeof t == "function" ? t : Nl(t), i = e == null ? Gs : typeof e == "function" ? e : Al(e);
  return this.select(function() {
    return this.insertBefore(n.apply(this, arguments), i.apply(this, arguments) || null);
  });
}
function Ys() {
  var t = this.parentNode;
  t && t.removeChild(this);
}
function Ks() {
  return this.each(Ys);
}
function Hs() {
  var t = this.cloneNode(!1), e = this.parentNode;
  return e ? e.insertBefore(t, this.nextSibling) : t;
}
function Zs() {
  var t = this.cloneNode(!0), e = this.parentNode;
  return e ? e.insertBefore(t, this.nextSibling) : t;
}
function Qs(t) {
  return this.select(t ? Zs : Hs);
}
function $s(t) {
  return arguments.length ? this.property("__data__", t) : this.node().__data__;
}
function xs(t) {
  return function(e) {
    t.call(this, e, this.__data__);
  };
}
function er(t) {
  return t.trim().split(/^|\s+/).map(function(e) {
    var n = "", i = e.indexOf(".");
    return i >= 0 && (n = e.slice(i + 1), e = e.slice(0, i)), { type: e, name: n };
  });
}
function tr(t) {
  return function() {
    var e = this.__on;
    if (e) {
      for (var n = 0, i = -1, l = e.length, o; n < l; ++n)
        o = e[n], (!t.type || o.type === t.type) && o.name === t.name ? this.removeEventListener(o.type, o.listener, o.options) : e[++i] = o;
      ++i ? e.length = i : delete this.__on;
    }
  };
}
function nr(t, e, n) {
  return function() {
    var i = this.__on, l, o = xs(e);
    if (i) {
      for (var s = 0, r = i.length; s < r; ++s)
        if ((l = i[s]).type === t.type && l.name === t.name) {
          this.removeEventListener(l.type, l.listener, l.options), this.addEventListener(l.type, l.listener = o, l.options = n), l.value = e;
          return;
        }
    }
    this.addEventListener(t.type, o, n), l = { type: t.type, name: t.name, value: e, listener: o, options: n }, i ? i.push(l) : this.__on = [l];
  };
}
function ir(t, e, n) {
  var i = er(t + ""), l, o = i.length, s;
  if (arguments.length < 2) {
    var r = this.node().__on;
    if (r) {
      for (var a = 0, u = r.length, f; a < u; ++a)
        for (l = 0, f = r[a]; l < o; ++l)
          if ((s = i[l]).type === f.type && s.name === f.name)
            return f.value;
    }
    return;
  }
  for (r = e ? nr : tr, l = 0; l < o; ++l) this.each(r(i[l], e, n));
  return this;
}
function Bl(t, e, n) {
  var i = Dl(t), l = i.CustomEvent;
  typeof l == "function" ? l = new l(e, n) : (l = i.document.createEvent("Event"), n ? (l.initEvent(e, n.bubbles, n.cancelable), l.detail = n.detail) : l.initEvent(e, !1, !1)), t.dispatchEvent(l);
}
function lr(t, e) {
  return function() {
    return Bl(this, t, e);
  };
}
function or(t, e) {
  return function() {
    return Bl(this, t, e.apply(this, arguments));
  };
}
function sr(t, e) {
  return this.each((typeof e == "function" ? or : lr)(t, e));
}
function* rr() {
  for (var t = this._groups, e = 0, n = t.length; e < n; ++e)
    for (var i = t[e], l = 0, o = i.length, s; l < o; ++l)
      (s = i[l]) && (yield s);
}
var ar = [null];
function be(t, e) {
  this._groups = t, this._parents = e;
}
function ur() {
  return this;
}
be.prototype = {
  constructor: be,
  select: Do,
  selectAll: Bo,
  selectChild: jo,
  selectChildren: Go,
  filter: Jo,
  data: $o,
  enter: Yo,
  exit: es,
  join: ts,
  merge: ns,
  selection: ur,
  order: is,
  sort: ls,
  call: ss,
  nodes: rs,
  node: as,
  size: us,
  empty: fs,
  each: cs,
  attr: bs,
  style: ks,
  property: Ns,
  classed: Ds,
  text: Ts,
  html: Rs,
  raise: js,
  lower: Ws,
  append: Xs,
  insert: Js,
  remove: Ks,
  clone: Qs,
  datum: $s,
  on: ir,
  dispatch: sr,
  [Symbol.iterator]: rr
};
function Dt(t) {
  return typeof t == "string" ? new be([[document.querySelector(t)]], [document.documentElement]) : new be([[t]], ar);
}
function fr(t) {
  let e;
  for (; e = t.sourceEvent; ) t = e;
  return t;
}
function gi(t, e) {
  if (t = fr(t), e === void 0 && (e = t.currentTarget), e) {
    var n = e.ownerSVGElement || e;
    if (n.createSVGPoint) {
      var i = n.createSVGPoint();
      return i.x = t.clientX, i.y = t.clientY, i = i.matrixTransform(e.getScreenCTM().inverse()), [i.x, i.y];
    }
    if (e.getBoundingClientRect) {
      var l = e.getBoundingClientRect();
      return [t.clientX - l.left - e.clientLeft, t.clientY - l.top - e.clientTop];
    }
  }
  return [t.pageX, t.pageY];
}
const cr = { passive: !1 }, Ft = { capture: !0, passive: !1 };
function qn(t) {
  t.stopImmediatePropagation();
}
function pt(t) {
  t.preventDefault(), t.stopImmediatePropagation();
}
function _r(t) {
  var e = t.document.documentElement, n = Dt(t).on("dragstart.drag", pt, Ft);
  "onselectstart" in e ? n.on("selectstart.drag", pt, Ft) : (e.__noselect = e.style.MozUserSelect, e.style.MozUserSelect = "none");
}
function dr(t, e) {
  var n = t.document.documentElement, i = Dt(t).on("dragstart.drag", null);
  e && (i.on("click.drag", pt, Ft), setTimeout(function() {
    i.on("click.drag", null);
  }, 0)), "onselectstart" in n ? i.on("selectstart.drag", null) : (n.style.MozUserSelect = n.__noselect, delete n.__noselect);
}
const Mt = (t) => () => t;
function Xn(t, {
  sourceEvent: e,
  subject: n,
  target: i,
  identifier: l,
  active: o,
  x: s,
  y: r,
  dx: a,
  dy: u,
  dispatch: f
}) {
  Object.defineProperties(this, {
    type: { value: t, enumerable: !0, configurable: !0 },
    sourceEvent: { value: e, enumerable: !0, configurable: !0 },
    subject: { value: n, enumerable: !0, configurable: !0 },
    target: { value: i, enumerable: !0, configurable: !0 },
    identifier: { value: l, enumerable: !0, configurable: !0 },
    active: { value: o, enumerable: !0, configurable: !0 },
    x: { value: s, enumerable: !0, configurable: !0 },
    y: { value: r, enumerable: !0, configurable: !0 },
    dx: { value: a, enumerable: !0, configurable: !0 },
    dy: { value: u, enumerable: !0, configurable: !0 },
    _: { value: f }
  });
}
Xn.prototype.on = function() {
  var t = this._.on.apply(this._, arguments);
  return t === this._ ? this : t;
};
function hr(t) {
  return !t.ctrlKey && !t.button;
}
function mr() {
  return this.parentNode;
}
function gr(t, e) {
  return e ?? { x: t.x, y: t.y };
}
function pr() {
  return navigator.maxTouchPoints || "ontouchstart" in this;
}
function br() {
  var t = hr, e = mr, n = gr, i = pr, l = {}, o = Cl("start", "drag", "end"), s = 0, r, a, u, f, c = 0;
  function _(m) {
    m.on("mousedown.drag", d).filter(i).on("touchstart.drag", y).on("touchmove.drag", p, cr).on("touchend.drag touchcancel.drag", v).style("touch-action", "none").style("-webkit-tap-highlight-color", "rgba(0,0,0,0)");
  }
  function d(m, g) {
    if (!(f || !t.call(this, m, g))) {
      var A = b(this, e.call(this, m, g), m, g, "mouse");
      A && (Dt(m.view).on("mousemove.drag", h, Ft).on("mouseup.drag", k, Ft), _r(m.view), qn(m), u = !1, r = m.clientX, a = m.clientY, A("start", m));
    }
  }
  function h(m) {
    if (pt(m), !u) {
      var g = m.clientX - r, A = m.clientY - a;
      u = g * g + A * A > c;
    }
    l.mouse("drag", m);
  }
  function k(m) {
    Dt(m.view).on("mousemove.drag mouseup.drag", null), dr(m.view, u), pt(m), l.mouse("end", m);
  }
  function y(m, g) {
    if (t.call(this, m, g)) {
      var A = m.changedTouches, E = e.call(this, m, g), z = A.length, P, R;
      for (P = 0; P < z; ++P)
        (R = b(this, E, m, g, A[P].identifier, A[P])) && (qn(m), R("start", m, A[P]));
    }
  }
  function p(m) {
    var g = m.changedTouches, A = g.length, E, z;
    for (E = 0; E < A; ++E)
      (z = l[g[E].identifier]) && (pt(m), z("drag", m, g[E]));
  }
  function v(m) {
    var g = m.changedTouches, A = g.length, E, z;
    for (f && clearTimeout(f), f = setTimeout(function() {
      f = null;
    }, 500), E = 0; E < A; ++E)
      (z = l[g[E].identifier]) && (qn(m), z("end", m, g[E]));
  }
  function b(m, g, A, E, z, P) {
    var R = o.copy(), j = gi(P || A, g), L, Y, C;
    if ((C = n.call(m, new Xn("beforestart", {
      sourceEvent: A,
      target: _,
      identifier: z,
      active: s,
      x: j[0],
      y: j[1],
      dx: 0,
      dy: 0,
      dispatch: R
    }), E)) != null)
      return L = C.x - j[0] || 0, Y = C.y - j[1] || 0, function w(V, T, N) {
        var U = j, O;
        switch (V) {
          case "start":
            l[z] = w, O = s++;
            break;
          case "end":
            delete l[z], --s;
          case "drag":
            j = gi(N || T, g), O = s;
            break;
        }
        R.call(
          V,
          m,
          new Xn(V, {
            sourceEvent: T,
            subject: C,
            target: _,
            identifier: z,
            active: O,
            x: j[0] + L,
            y: j[1] + Y,
            dx: j[0] - U[0],
            dy: j[1] - U[1],
            dispatch: R
          }),
          E
        );
      };
  }
  return _.filter = function(m) {
    return arguments.length ? (t = typeof m == "function" ? m : Mt(!!m), _) : t;
  }, _.container = function(m) {
    return arguments.length ? (e = typeof m == "function" ? m : Mt(m), _) : e;
  }, _.subject = function(m) {
    return arguments.length ? (n = typeof m == "function" ? m : Mt(m), _) : n;
  }, _.touchable = function(m) {
    return arguments.length ? (i = typeof m == "function" ? m : Mt(!!m), _) : i;
  }, _.on = function() {
    var m = o.on.apply(o, arguments);
    return m === o ? _ : m;
  }, _.clickDistance = function(m) {
    return arguments.length ? (c = (m = +m) * m, _) : Math.sqrt(c);
  }, _;
}
function pi(t, e, n) {
  return Math.min(Math.max(t, e), n);
}
const {
  SvelteComponent: wr,
  append: vr,
  attr: ft,
  detach: yr,
  init: kr,
  insert: Sr,
  noop: Cn,
  safe_not_equal: qr,
  svg_element: bi
} = window.__gradio__svelte__internal;
function Cr(t) {
  let e, n;
  return {
    c() {
      e = bi("svg"), n = bi("path"), ft(n, "fill", "currentColor"), ft(n, "d", "M16 22L6 12L16 2l1.775 1.775L9.55 12l8.225 8.225z"), ft(e, "xmlns", "http://www.w3.org/2000/svg"), ft(e, "width", "100%"), ft(e, "height", "100%"), ft(e, "viewBox", "0 0 24 24");
    },
    m(i, l) {
      Sr(i, e, l), vr(e, n);
    },
    p: Cn,
    i: Cn,
    o: Cn,
    d(i) {
      i && yr(e);
    }
  };
}
class wi extends wr {
  constructor(e) {
    super(), kr(this, e, null, Cr, qr, {});
  }
}
const {
  SvelteComponent: Er,
  append: $e,
  attr: ct,
  binding_callbacks: vi,
  create_component: yi,
  create_slot: Nr,
  destroy_component: ki,
  detach: Ar,
  element: Nt,
  get_all_dirty_from_scope: zr,
  get_slot_changes: Lr,
  init: Dr,
  insert: Fr,
  listen: Or,
  mount_component: Si,
  safe_not_equal: Ir,
  set_style: Rt,
  space: En,
  toggle_class: Ae,
  transition_in: Nn,
  transition_out: An,
  update_slot_base: Tr
} = window.__gradio__svelte__internal, { onMount: Br } = window.__gradio__svelte__internal;
function Pr(t) {
  let e, n, i, l, o, s, r, a, u, f, c, _, d;
  const h = (
    /*#slots*/
    t[10].default
  ), k = Nr(
    h,
    t,
    /*$$scope*/
    t[9],
    null
  );
  return o = new wi({}), f = new wi({}), {
    c() {
      e = Nt("div"), k && k.c(), n = En(), i = Nt("div"), l = Nt("span"), yi(o.$$.fragment), s = En(), r = Nt("div"), a = En(), u = Nt("span"), yi(f.$$.fragment), ct(l, "class", "icon-wrap svelte-1w37x6c"), Ae(
        l,
        "active",
        /*active*/
        t[2]
      ), Ae(
        l,
        "disabled",
        /*disabled*/
        t[0]
      ), ct(r, "class", "inner svelte-1w37x6c"), Rt(
        r,
        "--color",
        /*slider_color*/
        t[1]
      ), ct(u, "class", "icon-wrap right svelte-1w37x6c"), Ae(
        u,
        "active",
        /*active*/
        t[2]
      ), Ae(
        u,
        "disabled",
        /*disabled*/
        t[0]
      ), ct(i, "class", "outer svelte-1w37x6c"), ct(i, "role", "none"), Rt(i, "transform", "translateX(" + /*px*/
      t[5] + "px)"), Ae(
        i,
        "disabled",
        /*disabled*/
        t[0]
      ), ct(e, "class", "wrap svelte-1w37x6c");
    },
    m(y, p) {
      Fr(y, e, p), k && k.m(e, null), $e(e, n), $e(e, i), $e(i, l), Si(o, l, null), $e(i, s), $e(i, r), $e(i, a), $e(i, u), Si(f, u, null), t[11](i), t[12](e), c = !0, _ || (d = Or(
        window,
        "resize",
        /*set_position*/
        t[6]
      ), _ = !0);
    },
    p(y, [p]) {
      k && k.p && (!c || p & /*$$scope*/
      512) && Tr(
        k,
        h,
        y,
        /*$$scope*/
        y[9],
        c ? Lr(
          h,
          /*$$scope*/
          y[9],
          p,
          null
        ) : zr(
          /*$$scope*/
          y[9]
        ),
        null
      ), (!c || p & /*active*/
      4) && Ae(
        l,
        "active",
        /*active*/
        y[2]
      ), (!c || p & /*disabled*/
      1) && Ae(
        l,
        "disabled",
        /*disabled*/
        y[0]
      ), p & /*slider_color*/
      2 && Rt(
        r,
        "--color",
        /*slider_color*/
        y[1]
      ), (!c || p & /*active*/
      4) && Ae(
        u,
        "active",
        /*active*/
        y[2]
      ), (!c || p & /*disabled*/
      1) && Ae(
        u,
        "disabled",
        /*disabled*/
        y[0]
      ), (!c || p & /*px*/
      32) && Rt(i, "transform", "translateX(" + /*px*/
      y[5] + "px)"), (!c || p & /*disabled*/
      1) && Ae(
        i,
        "disabled",
        /*disabled*/
        y[0]
      );
    },
    i(y) {
      c || (Nn(k, y), Nn(o.$$.fragment, y), Nn(f.$$.fragment, y), c = !0);
    },
    o(y) {
      An(k, y), An(o.$$.fragment, y), An(f.$$.fragment, y), c = !1;
    },
    d(y) {
      y && Ar(e), k && k.d(y), ki(o), ki(f), t[11](null), t[12](null), _ = !1, d();
    }
  };
}
function Mr(t, e) {
  const n = Math.pow(10, e);
  return Math.round((t + Number.EPSILON) * n) / n;
}
function Rr(t, e, n) {
  let { $$slots: i = {}, $$scope: l } = e, { position: o = 0.5 } = e, { disabled: s = !1 } = e, { slider_color: r = "var(--border-color-primary)" } = e, a = !1, u, f, c, _ = 0;
  function d() {
    n(8, c = u.getBoundingClientRect()), n(5, _ = pi(c.width * o - 10, 0, c.width - 20));
  }
  function h(m) {
    n(5, _ = m - 10), n(7, o = Mr(m / c.width, 5));
  }
  function k(m) {
    s || (n(2, a = !0), h(m.x));
  }
  function y(m, g) {
    s || h(m.x);
  }
  function p() {
    s || n(2, a = !1);
  }
  Br(() => {
    d();
    const m = br().on("start", k).on("drag", y).on("end", p);
    Dt(u).call(m);
  });
  function v(m) {
    vi[m ? "unshift" : "push"](() => {
      f = m, n(4, f);
    });
  }
  function b(m) {
    vi[m ? "unshift" : "push"](() => {
      u = m, n(3, u);
    });
  }
  return t.$$set = (m) => {
    "position" in m && n(7, o = m.position), "disabled" in m && n(0, s = m.disabled), "slider_color" in m && n(1, r = m.slider_color), "$$scope" in m && n(9, l = m.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*box, position*/
    384 && n(5, _ = c ? pi(c.width * o - 10, 0, c.width - 20) : 0);
  }, [
    s,
    r,
    a,
    u,
    f,
    _,
    d,
    o,
    c,
    l,
    i,
    v,
    b
  ];
}
class Pl extends Er {
  constructor(e) {
    super(), Dr(this, e, Rr, Pr, Ir, {
      position: 7,
      disabled: 0,
      slider_color: 1
    });
  }
}
const {
  SvelteComponent: Ur,
  assign: jr,
  create_slot: Vr,
  detach: Wr,
  element: Xr,
  get_all_dirty_from_scope: Gr,
  get_slot_changes: Jr,
  get_spread_update: Yr,
  init: Kr,
  insert: Hr,
  safe_not_equal: Zr,
  set_dynamic_element_data: qi,
  set_style: fe,
  toggle_class: je,
  transition_in: Ml,
  transition_out: Rl,
  update_slot_base: Qr
} = window.__gradio__svelte__internal;
function $r(t) {
  let e, n, i;
  const l = (
    /*#slots*/
    t[17].default
  ), o = Vr(
    l,
    t,
    /*$$scope*/
    t[16],
    null
  );
  let s = [
    { "data-testid": (
      /*test_id*/
      t[7]
    ) },
    { id: (
      /*elem_id*/
      t[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      t[3].join(" ") + " svelte-1t38q2d"
    }
  ], r = {};
  for (let a = 0; a < s.length; a += 1)
    r = jr(r, s[a]);
  return {
    c() {
      e = Xr(
        /*tag*/
        t[14]
      ), o && o.c(), qi(
        /*tag*/
        t[14]
      )(e, r), je(
        e,
        "hidden",
        /*visible*/
        t[10] === !1
      ), je(
        e,
        "padded",
        /*padding*/
        t[6]
      ), je(
        e,
        "border_focus",
        /*border_mode*/
        t[5] === "focus"
      ), je(e, "hide-container", !/*explicit_call*/
      t[8] && !/*container*/
      t[9]), fe(e, "height", typeof /*height*/
      t[0] == "number" ? (
        /*height*/
        t[0] + "px"
      ) : void 0), fe(e, "width", typeof /*width*/
      t[1] == "number" ? `calc(min(${/*width*/
      t[1]}px, 100%))` : void 0), fe(
        e,
        "border-style",
        /*variant*/
        t[4]
      ), fe(
        e,
        "overflow",
        /*allow_overflow*/
        t[11] ? "visible" : "hidden"
      ), fe(
        e,
        "flex-grow",
        /*scale*/
        t[12]
      ), fe(e, "min-width", `calc(min(${/*min_width*/
      t[13]}px, 100%))`), fe(e, "border-width", "var(--block-border-width)");
    },
    m(a, u) {
      Hr(a, e, u), o && o.m(e, null), i = !0;
    },
    p(a, u) {
      o && o.p && (!i || u & /*$$scope*/
      65536) && Qr(
        o,
        l,
        a,
        /*$$scope*/
        a[16],
        i ? Jr(
          l,
          /*$$scope*/
          a[16],
          u,
          null
        ) : Gr(
          /*$$scope*/
          a[16]
        ),
        null
      ), qi(
        /*tag*/
        a[14]
      )(e, r = Yr(s, [
        (!i || u & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          a[7]
        ) },
        (!i || u & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          a[2]
        ) },
        (!i || u & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        a[3].join(" ") + " svelte-1t38q2d")) && { class: n }
      ])), je(
        e,
        "hidden",
        /*visible*/
        a[10] === !1
      ), je(
        e,
        "padded",
        /*padding*/
        a[6]
      ), je(
        e,
        "border_focus",
        /*border_mode*/
        a[5] === "focus"
      ), je(e, "hide-container", !/*explicit_call*/
      a[8] && !/*container*/
      a[9]), u & /*height*/
      1 && fe(e, "height", typeof /*height*/
      a[0] == "number" ? (
        /*height*/
        a[0] + "px"
      ) : void 0), u & /*width*/
      2 && fe(e, "width", typeof /*width*/
      a[1] == "number" ? `calc(min(${/*width*/
      a[1]}px, 100%))` : void 0), u & /*variant*/
      16 && fe(
        e,
        "border-style",
        /*variant*/
        a[4]
      ), u & /*allow_overflow*/
      2048 && fe(
        e,
        "overflow",
        /*allow_overflow*/
        a[11] ? "visible" : "hidden"
      ), u & /*scale*/
      4096 && fe(
        e,
        "flex-grow",
        /*scale*/
        a[12]
      ), u & /*min_width*/
      8192 && fe(e, "min-width", `calc(min(${/*min_width*/
      a[13]}px, 100%))`);
    },
    i(a) {
      i || (Ml(o, a), i = !0);
    },
    o(a) {
      Rl(o, a), i = !1;
    },
    d(a) {
      a && Wr(e), o && o.d(a);
    }
  };
}
function xr(t) {
  let e, n = (
    /*tag*/
    t[14] && $r(t)
  );
  return {
    c() {
      n && n.c();
    },
    m(i, l) {
      n && n.m(i, l), e = !0;
    },
    p(i, [l]) {
      /*tag*/
      i[14] && n.p(i, l);
    },
    i(i) {
      e || (Ml(n, i), e = !0);
    },
    o(i) {
      Rl(n, i), e = !1;
    },
    d(i) {
      n && n.d(i);
    }
  };
}
function ea(t, e, n) {
  let { $$slots: i = {}, $$scope: l } = e, { height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: r = "" } = e, { elem_classes: a = [] } = e, { variant: u = "solid" } = e, { border_mode: f = "base" } = e, { padding: c = !0 } = e, { type: _ = "normal" } = e, { test_id: d = void 0 } = e, { explicit_call: h = !1 } = e, { container: k = !0 } = e, { visible: y = !0 } = e, { allow_overflow: p = !0 } = e, { scale: v = null } = e, { min_width: b = 0 } = e, m = _ === "fieldset" ? "fieldset" : "div";
  return t.$$set = (g) => {
    "height" in g && n(0, o = g.height), "width" in g && n(1, s = g.width), "elem_id" in g && n(2, r = g.elem_id), "elem_classes" in g && n(3, a = g.elem_classes), "variant" in g && n(4, u = g.variant), "border_mode" in g && n(5, f = g.border_mode), "padding" in g && n(6, c = g.padding), "type" in g && n(15, _ = g.type), "test_id" in g && n(7, d = g.test_id), "explicit_call" in g && n(8, h = g.explicit_call), "container" in g && n(9, k = g.container), "visible" in g && n(10, y = g.visible), "allow_overflow" in g && n(11, p = g.allow_overflow), "scale" in g && n(12, v = g.scale), "min_width" in g && n(13, b = g.min_width), "$$scope" in g && n(16, l = g.$$scope);
  }, [
    o,
    s,
    r,
    a,
    u,
    f,
    c,
    d,
    h,
    k,
    y,
    p,
    v,
    b,
    m,
    _,
    l,
    i
  ];
}
class Ul extends Ur {
  constructor(e) {
    super(), Kr(this, e, ea, xr, Zr, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 15,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: ta,
  append: zn,
  attr: Ut,
  create_component: na,
  destroy_component: ia,
  detach: la,
  element: Ci,
  init: oa,
  insert: sa,
  mount_component: ra,
  safe_not_equal: aa,
  set_data: ua,
  space: fa,
  text: ca,
  toggle_class: Ve,
  transition_in: _a,
  transition_out: da
} = window.__gradio__svelte__internal;
function ha(t) {
  let e, n, i, l, o, s;
  return i = new /*Icon*/
  t[1]({}), {
    c() {
      e = Ci("label"), n = Ci("span"), na(i.$$.fragment), l = fa(), o = ca(
        /*label*/
        t[0]
      ), Ut(n, "class", "svelte-9gxdi0"), Ut(e, "for", ""), Ut(e, "data-testid", "block-label"), Ut(e, "class", "svelte-9gxdi0"), Ve(e, "hide", !/*show_label*/
      t[2]), Ve(e, "sr-only", !/*show_label*/
      t[2]), Ve(
        e,
        "float",
        /*float*/
        t[4]
      ), Ve(
        e,
        "hide-label",
        /*disable*/
        t[3]
      );
    },
    m(r, a) {
      sa(r, e, a), zn(e, n), ra(i, n, null), zn(e, l), zn(e, o), s = !0;
    },
    p(r, [a]) {
      (!s || a & /*label*/
      1) && ua(
        o,
        /*label*/
        r[0]
      ), (!s || a & /*show_label*/
      4) && Ve(e, "hide", !/*show_label*/
      r[2]), (!s || a & /*show_label*/
      4) && Ve(e, "sr-only", !/*show_label*/
      r[2]), (!s || a & /*float*/
      16) && Ve(
        e,
        "float",
        /*float*/
        r[4]
      ), (!s || a & /*disable*/
      8) && Ve(
        e,
        "hide-label",
        /*disable*/
        r[3]
      );
    },
    i(r) {
      s || (_a(i.$$.fragment, r), s = !0);
    },
    o(r) {
      da(i.$$.fragment, r), s = !1;
    },
    d(r) {
      r && la(e), ia(i);
    }
  };
}
function ma(t, e, n) {
  let { label: i = null } = e, { Icon: l } = e, { show_label: o = !0 } = e, { disable: s = !1 } = e, { float: r = !0 } = e;
  return t.$$set = (a) => {
    "label" in a && n(0, i = a.label), "Icon" in a && n(1, l = a.Icon), "show_label" in a && n(2, o = a.show_label), "disable" in a && n(3, s = a.disable), "float" in a && n(4, r = a.float);
  }, [i, l, o, s, r];
}
class jl extends ta {
  constructor(e) {
    super(), oa(this, e, ma, ha, aa, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: ga,
  append: Gn,
  attr: Te,
  bubble: pa,
  create_component: ba,
  destroy_component: wa,
  detach: Vl,
  element: Jn,
  init: va,
  insert: Wl,
  listen: ya,
  mount_component: ka,
  safe_not_equal: Sa,
  set_data: qa,
  set_style: jt,
  space: Ca,
  text: Ea,
  toggle_class: he,
  transition_in: Na,
  transition_out: Aa
} = window.__gradio__svelte__internal;
function Ei(t) {
  let e, n;
  return {
    c() {
      e = Jn("span"), n = Ea(
        /*label*/
        t[1]
      ), Te(e, "class", "svelte-lpi64a");
    },
    m(i, l) {
      Wl(i, e, l), Gn(e, n);
    },
    p(i, l) {
      l & /*label*/
      2 && qa(
        n,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && Vl(e);
    }
  };
}
function za(t) {
  let e, n, i, l, o, s, r, a = (
    /*show_label*/
    t[2] && Ei(t)
  );
  return l = new /*Icon*/
  t[0]({}), {
    c() {
      e = Jn("button"), a && a.c(), n = Ca(), i = Jn("div"), ba(l.$$.fragment), Te(i, "class", "svelte-lpi64a"), he(
        i,
        "small",
        /*size*/
        t[4] === "small"
      ), he(
        i,
        "large",
        /*size*/
        t[4] === "large"
      ), e.disabled = /*disabled*/
      t[7], Te(
        e,
        "aria-label",
        /*label*/
        t[1]
      ), Te(
        e,
        "aria-haspopup",
        /*hasPopup*/
        t[8]
      ), Te(
        e,
        "title",
        /*label*/
        t[1]
      ), Te(e, "class", "svelte-lpi64a"), he(
        e,
        "pending",
        /*pending*/
        t[3]
      ), he(
        e,
        "padded",
        /*padded*/
        t[5]
      ), he(
        e,
        "highlight",
        /*highlight*/
        t[6]
      ), he(
        e,
        "transparent",
        /*transparent*/
        t[9]
      ), jt(e, "color", !/*disabled*/
      t[7] && /*_color*/
      t[11] ? (
        /*_color*/
        t[11]
      ) : "var(--block-label-text-color)"), jt(e, "--bg-color", /*disabled*/
      t[7] ? "auto" : (
        /*background*/
        t[10]
      ));
    },
    m(u, f) {
      Wl(u, e, f), a && a.m(e, null), Gn(e, n), Gn(e, i), ka(l, i, null), o = !0, s || (r = ya(
        e,
        "click",
        /*click_handler*/
        t[13]
      ), s = !0);
    },
    p(u, [f]) {
      /*show_label*/
      u[2] ? a ? a.p(u, f) : (a = Ei(u), a.c(), a.m(e, n)) : a && (a.d(1), a = null), (!o || f & /*size*/
      16) && he(
        i,
        "small",
        /*size*/
        u[4] === "small"
      ), (!o || f & /*size*/
      16) && he(
        i,
        "large",
        /*size*/
        u[4] === "large"
      ), (!o || f & /*disabled*/
      128) && (e.disabled = /*disabled*/
      u[7]), (!o || f & /*label*/
      2) && Te(
        e,
        "aria-label",
        /*label*/
        u[1]
      ), (!o || f & /*hasPopup*/
      256) && Te(
        e,
        "aria-haspopup",
        /*hasPopup*/
        u[8]
      ), (!o || f & /*label*/
      2) && Te(
        e,
        "title",
        /*label*/
        u[1]
      ), (!o || f & /*pending*/
      8) && he(
        e,
        "pending",
        /*pending*/
        u[3]
      ), (!o || f & /*padded*/
      32) && he(
        e,
        "padded",
        /*padded*/
        u[5]
      ), (!o || f & /*highlight*/
      64) && he(
        e,
        "highlight",
        /*highlight*/
        u[6]
      ), (!o || f & /*transparent*/
      512) && he(
        e,
        "transparent",
        /*transparent*/
        u[9]
      ), f & /*disabled, _color*/
      2176 && jt(e, "color", !/*disabled*/
      u[7] && /*_color*/
      u[11] ? (
        /*_color*/
        u[11]
      ) : "var(--block-label-text-color)"), f & /*disabled, background*/
      1152 && jt(e, "--bg-color", /*disabled*/
      u[7] ? "auto" : (
        /*background*/
        u[10]
      ));
    },
    i(u) {
      o || (Na(l.$$.fragment, u), o = !0);
    },
    o(u) {
      Aa(l.$$.fragment, u), o = !1;
    },
    d(u) {
      u && Vl(e), a && a.d(), wa(l), s = !1, r();
    }
  };
}
function La(t, e, n) {
  let i, { Icon: l } = e, { label: o = "" } = e, { show_label: s = !1 } = e, { pending: r = !1 } = e, { size: a = "small" } = e, { padded: u = !0 } = e, { highlight: f = !1 } = e, { disabled: c = !1 } = e, { hasPopup: _ = !1 } = e, { color: d = "var(--block-label-text-color)" } = e, { transparent: h = !1 } = e, { background: k = "var(--background-fill-primary)" } = e;
  function y(p) {
    pa.call(this, t, p);
  }
  return t.$$set = (p) => {
    "Icon" in p && n(0, l = p.Icon), "label" in p && n(1, o = p.label), "show_label" in p && n(2, s = p.show_label), "pending" in p && n(3, r = p.pending), "size" in p && n(4, a = p.size), "padded" in p && n(5, u = p.padded), "highlight" in p && n(6, f = p.highlight), "disabled" in p && n(7, c = p.disabled), "hasPopup" in p && n(8, _ = p.hasPopup), "color" in p && n(12, d = p.color), "transparent" in p && n(9, h = p.transparent), "background" in p && n(10, k = p.background);
  }, t.$$.update = () => {
    t.$$.dirty & /*highlight, color*/
    4160 && n(11, i = f ? "var(--color-accent)" : d);
  }, [
    l,
    o,
    s,
    r,
    a,
    u,
    f,
    c,
    _,
    h,
    k,
    i,
    d,
    y
  ];
}
class vn extends ga {
  constructor(e) {
    super(), va(this, e, La, za, Sa, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Da,
  append: Fa,
  attr: Ln,
  binding_callbacks: Oa,
  create_slot: Ia,
  detach: Ta,
  element: Ni,
  get_all_dirty_from_scope: Ba,
  get_slot_changes: Pa,
  init: Ma,
  insert: Ra,
  safe_not_equal: Ua,
  toggle_class: We,
  transition_in: ja,
  transition_out: Va,
  update_slot_base: Wa
} = window.__gradio__svelte__internal;
function Xa(t) {
  let e, n, i;
  const l = (
    /*#slots*/
    t[5].default
  ), o = Ia(
    l,
    t,
    /*$$scope*/
    t[4],
    null
  );
  return {
    c() {
      e = Ni("div"), n = Ni("div"), o && o.c(), Ln(n, "class", "icon svelte-3w3rth"), Ln(e, "class", "empty svelte-3w3rth"), Ln(e, "aria-label", "Empty value"), We(
        e,
        "small",
        /*size*/
        t[0] === "small"
      ), We(
        e,
        "large",
        /*size*/
        t[0] === "large"
      ), We(
        e,
        "unpadded_box",
        /*unpadded_box*/
        t[1]
      ), We(
        e,
        "small_parent",
        /*parent_height*/
        t[3]
      );
    },
    m(s, r) {
      Ra(s, e, r), Fa(e, n), o && o.m(n, null), t[6](e), i = !0;
    },
    p(s, [r]) {
      o && o.p && (!i || r & /*$$scope*/
      16) && Wa(
        o,
        l,
        s,
        /*$$scope*/
        s[4],
        i ? Pa(
          l,
          /*$$scope*/
          s[4],
          r,
          null
        ) : Ba(
          /*$$scope*/
          s[4]
        ),
        null
      ), (!i || r & /*size*/
      1) && We(
        e,
        "small",
        /*size*/
        s[0] === "small"
      ), (!i || r & /*size*/
      1) && We(
        e,
        "large",
        /*size*/
        s[0] === "large"
      ), (!i || r & /*unpadded_box*/
      2) && We(
        e,
        "unpadded_box",
        /*unpadded_box*/
        s[1]
      ), (!i || r & /*parent_height*/
      8) && We(
        e,
        "small_parent",
        /*parent_height*/
        s[3]
      );
    },
    i(s) {
      i || (ja(o, s), i = !0);
    },
    o(s) {
      Va(o, s), i = !1;
    },
    d(s) {
      s && Ta(e), o && o.d(s), t[6](null);
    }
  };
}
function Ga(t, e, n) {
  let i, { $$slots: l = {}, $$scope: o } = e, { size: s = "small" } = e, { unpadded_box: r = !1 } = e, a;
  function u(c) {
    var _;
    if (!c) return !1;
    const { height: d } = c.getBoundingClientRect(), { height: h } = ((_ = c.parentElement) === null || _ === void 0 ? void 0 : _.getBoundingClientRect()) || { height: d };
    return d > h + 2;
  }
  function f(c) {
    Oa[c ? "unshift" : "push"](() => {
      a = c, n(2, a);
    });
  }
  return t.$$set = (c) => {
    "size" in c && n(0, s = c.size), "unpadded_box" in c && n(1, r = c.unpadded_box), "$$scope" in c && n(4, o = c.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*el*/
    4 && n(3, i = u(a));
  }, [s, r, a, i, o, l, f];
}
class Xl extends Da {
  constructor(e) {
    super(), Ma(this, e, Ga, Xa, Ua, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: Ja,
  append: Dn,
  attr: Se,
  detach: Ya,
  init: Ka,
  insert: Ha,
  noop: Fn,
  safe_not_equal: Za,
  set_style: ze,
  svg_element: Vt
} = window.__gradio__svelte__internal;
function Qa(t) {
  let e, n, i, l;
  return {
    c() {
      e = Vt("svg"), n = Vt("g"), i = Vt("path"), l = Vt("path"), Se(i, "d", "M18,6L6.087,17.913"), ze(i, "fill", "none"), ze(i, "fill-rule", "nonzero"), ze(i, "stroke-width", "2px"), Se(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Se(l, "d", "M4.364,4.364L19.636,19.636"), ze(l, "fill", "none"), ze(l, "fill-rule", "nonzero"), ze(l, "stroke-width", "2px"), Se(e, "width", "100%"), Se(e, "height", "100%"), Se(e, "viewBox", "0 0 24 24"), Se(e, "version", "1.1"), Se(e, "xmlns", "http://www.w3.org/2000/svg"), Se(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Se(e, "xml:space", "preserve"), Se(e, "stroke", "currentColor"), ze(e, "fill-rule", "evenodd"), ze(e, "clip-rule", "evenodd"), ze(e, "stroke-linecap", "round"), ze(e, "stroke-linejoin", "round");
    },
    m(o, s) {
      Ha(o, e, s), Dn(e, n), Dn(n, i), Dn(e, l);
    },
    p: Fn,
    i: Fn,
    o: Fn,
    d(o) {
      o && Ya(e);
    }
  };
}
class $a extends Ja {
  constructor(e) {
    super(), Ka(this, e, null, Qa, Za, {});
  }
}
const {
  SvelteComponent: xa,
  append: eu,
  attr: _t,
  detach: tu,
  init: nu,
  insert: iu,
  noop: On,
  safe_not_equal: lu,
  svg_element: Ai
} = window.__gradio__svelte__internal;
function ou(t) {
  let e, n;
  return {
    c() {
      e = Ai("svg"), n = Ai("path"), _t(n, "fill", "currentColor"), _t(n, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), _t(e, "xmlns", "http://www.w3.org/2000/svg"), _t(e, "width", "100%"), _t(e, "height", "100%"), _t(e, "viewBox", "0 0 32 32");
    },
    m(i, l) {
      iu(i, e, l), eu(e, n);
    },
    p: On,
    i: On,
    o: On,
    d(i) {
      i && tu(e);
    }
  };
}
class li extends xa {
  constructor(e) {
    super(), nu(this, e, null, ou, lu, {});
  }
}
const {
  SvelteComponent: su,
  append: In,
  attr: $,
  detach: ru,
  init: au,
  insert: uu,
  noop: Tn,
  safe_not_equal: fu,
  svg_element: Wt
} = window.__gradio__svelte__internal;
function cu(t) {
  let e, n, i, l;
  return {
    c() {
      e = Wt("svg"), n = Wt("rect"), i = Wt("circle"), l = Wt("polyline"), $(n, "x", "3"), $(n, "y", "3"), $(n, "width", "18"), $(n, "height", "18"), $(n, "rx", "2"), $(n, "ry", "2"), $(i, "cx", "8.5"), $(i, "cy", "8.5"), $(i, "r", "1.5"), $(l, "points", "21 15 16 10 5 21"), $(e, "xmlns", "http://www.w3.org/2000/svg"), $(e, "width", "100%"), $(e, "height", "100%"), $(e, "viewBox", "0 0 24 24"), $(e, "fill", "none"), $(e, "stroke", "currentColor"), $(e, "stroke-width", "1.5"), $(e, "stroke-linecap", "round"), $(e, "stroke-linejoin", "round"), $(e, "class", "feather feather-image");
    },
    m(o, s) {
      uu(o, e, s), In(e, n), In(e, i), In(e, l);
    },
    p: Tn,
    i: Tn,
    o: Tn,
    d(o) {
      o && ru(e);
    }
  };
}
class yn extends su {
  constructor(e) {
    super(), au(this, e, null, cu, fu, {});
  }
}
const {
  SvelteComponent: _u,
  append: Bn,
  attr: ie,
  detach: du,
  init: hu,
  insert: mu,
  noop: Pn,
  safe_not_equal: gu,
  svg_element: Xt
} = window.__gradio__svelte__internal;
function pu(t) {
  let e, n, i, l;
  return {
    c() {
      e = Xt("svg"), n = Xt("path"), i = Xt("polyline"), l = Xt("line"), ie(n, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), ie(i, "points", "17 8 12 3 7 8"), ie(l, "x1", "12"), ie(l, "y1", "3"), ie(l, "x2", "12"), ie(l, "y2", "15"), ie(e, "xmlns", "http://www.w3.org/2000/svg"), ie(e, "width", "90%"), ie(e, "height", "90%"), ie(e, "viewBox", "0 0 24 24"), ie(e, "fill", "none"), ie(e, "stroke", "currentColor"), ie(e, "stroke-width", "2"), ie(e, "stroke-linecap", "round"), ie(e, "stroke-linejoin", "round"), ie(e, "class", "feather feather-upload");
    },
    m(o, s) {
      mu(o, e, s), Bn(e, n), Bn(e, i), Bn(e, l);
    },
    p: Pn,
    i: Pn,
    o: Pn,
    d(o) {
      o && du(e);
    }
  };
}
let bu = class extends _u {
  constructor(e) {
    super(), hu(this, e, null, pu, gu, {});
  }
};
const wu = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], zi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
wu.reduce(
  (t, { color: e, primary: n, secondary: i }) => ({
    ...t,
    [e]: {
      primary: zi[e][n],
      secondary: zi[e][i]
    }
  }),
  {}
);
const {
  SvelteComponent: vu,
  append: lt,
  attr: Yn,
  create_component: yu,
  destroy_component: ku,
  detach: xt,
  element: Kn,
  init: Su,
  insert: en,
  mount_component: qu,
  safe_not_equal: Cu,
  set_data: Hn,
  space: Zn,
  text: zt,
  toggle_class: Li,
  transition_in: Eu,
  transition_out: Nu
} = window.__gradio__svelte__internal;
function Di(t) {
  let e, n, i = (
    /*i18n*/
    t[1]("common.or") + ""
  ), l, o, s, r = (
    /*message*/
    (t[2] || /*i18n*/
    t[1]("upload_text.click_to_upload")) + ""
  ), a;
  return {
    c() {
      e = Kn("span"), n = zt("- "), l = zt(i), o = zt(" -"), s = Zn(), a = zt(r), Yn(e, "class", "or svelte-kzcjhc");
    },
    m(u, f) {
      en(u, e, f), lt(e, n), lt(e, l), lt(e, o), en(u, s, f), en(u, a, f);
    },
    p(u, f) {
      f & /*i18n*/
      2 && i !== (i = /*i18n*/
      u[1]("common.or") + "") && Hn(l, i), f & /*message, i18n*/
      6 && r !== (r = /*message*/
      (u[2] || /*i18n*/
      u[1]("upload_text.click_to_upload")) + "") && Hn(a, r);
    },
    d(u) {
      u && (xt(e), xt(s), xt(a));
    }
  };
}
function Au(t) {
  let e, n, i, l, o = (
    /*i18n*/
    t[1](
      /*defs*/
      t[5][
        /*type*/
        t[0]
      ] || /*defs*/
      t[5].file
    ) + ""
  ), s, r, a;
  i = new bu({});
  let u = (
    /*mode*/
    t[3] !== "short" && Di(t)
  );
  return {
    c() {
      e = Kn("div"), n = Kn("span"), yu(i.$$.fragment), l = Zn(), s = zt(o), r = Zn(), u && u.c(), Yn(n, "class", "icon-wrap svelte-kzcjhc"), Li(
        n,
        "hovered",
        /*hovered*/
        t[4]
      ), Yn(e, "class", "wrap svelte-kzcjhc");
    },
    m(f, c) {
      en(f, e, c), lt(e, n), qu(i, n, null), lt(e, l), lt(e, s), lt(e, r), u && u.m(e, null), a = !0;
    },
    p(f, [c]) {
      (!a || c & /*hovered*/
      16) && Li(
        n,
        "hovered",
        /*hovered*/
        f[4]
      ), (!a || c & /*i18n, type*/
      3) && o !== (o = /*i18n*/
      f[1](
        /*defs*/
        f[5][
          /*type*/
          f[0]
        ] || /*defs*/
        f[5].file
      ) + "") && Hn(s, o), /*mode*/
      f[3] !== "short" ? u ? u.p(f, c) : (u = Di(f), u.c(), u.m(e, null)) : u && (u.d(1), u = null);
    },
    i(f) {
      a || (Eu(i.$$.fragment, f), a = !0);
    },
    o(f) {
      Nu(i.$$.fragment, f), a = !1;
    },
    d(f) {
      f && xt(e), ku(i), u && u.d();
    }
  };
}
function zu(t, e, n) {
  let { type: i = "file" } = e, { i18n: l } = e, { message: o = void 0 } = e, { mode: s = "full" } = e, { hovered: r = !1 } = e;
  const a = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv"
  };
  return t.$$set = (u) => {
    "type" in u && n(0, i = u.type), "i18n" in u && n(1, l = u.i18n), "message" in u && n(2, o = u.message), "mode" in u && n(3, s = u.mode), "hovered" in u && n(4, r = u.hovered);
  }, [i, l, o, s, r, a];
}
class Lu extends vu {
  constructor(e) {
    super(), Su(this, e, zu, Au, Cu, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4
    });
  }
}
const {
  SvelteComponent: Du,
  attr: Fu,
  create_component: Ou,
  destroy_component: Iu,
  detach: Tu,
  element: Bu,
  init: Pu,
  insert: Mu,
  mount_component: Ru,
  noop: Uu,
  safe_not_equal: ju,
  transition_in: Vu,
  transition_out: Wu
} = window.__gradio__svelte__internal, { createEventDispatcher: Xu } = window.__gradio__svelte__internal;
function Gu(t) {
  let e, n, i;
  return n = new vn({
    props: { Icon: $a, label: "Remove Image" }
  }), n.$on(
    "click",
    /*click_handler*/
    t[1]
  ), {
    c() {
      e = Bu("div"), Ou(n.$$.fragment), Fu(e, "class", "svelte-1g74h68");
    },
    m(l, o) {
      Mu(l, e, o), Ru(n, e, null), i = !0;
    },
    p: Uu,
    i(l) {
      i || (Vu(n.$$.fragment, l), i = !0);
    },
    o(l) {
      Wu(n.$$.fragment, l), i = !1;
    },
    d(l) {
      l && Tu(e), Iu(n);
    }
  };
}
function Ju(t) {
  const e = Xu();
  return [e, (i) => {
    e("remove_image"), i.stopPropagation();
  }];
}
class Yu extends Du {
  constructor(e) {
    super(), Pu(this, e, Ju, Gu, ju, {});
  }
}
var Mn = new Intl.Collator(0, { numeric: 1 }).compare;
function Fi(t, e, n) {
  return t = t.split("."), e = e.split("."), Mn(t[0], e[0]) || Mn(t[1], e[1]) || (e[2] = e.slice(2).join("."), n = /[.-]/.test(t[2] = t.slice(2).join(".")), n == /[.-]/.test(e[2]) ? Mn(t[2], e[2]) : n ? -1 : 1);
}
function Ge(t, e, n) {
  return e.startsWith("http://") || e.startsWith("https://") ? n ? t : e : t + e;
}
function Rn(t) {
  if (t.startsWith("http")) {
    const { protocol: e, host: n } = new URL(t);
    return n.endsWith("hf.space") ? {
      ws_protocol: "wss",
      host: n,
      http_protocol: e
    } : {
      ws_protocol: e === "https:" ? "wss" : "ws",
      http_protocol: e,
      host: n
    };
  } else if (t.startsWith("file:"))
    return {
      ws_protocol: "ws",
      http_protocol: "http:",
      host: "lite.local"
      // Special fake hostname only used for this case. This matches the hostname allowed in `is_self_host()` in `js/wasm/network/host.ts`.
    };
  return {
    ws_protocol: "wss",
    http_protocol: "https:",
    host: t
  };
}
const Gl = /^[^\/]*\/[^\/]*$/, Ku = /.*hf\.space\/{0,1}$/;
async function Hu(t, e) {
  const n = {};
  e && (n.Authorization = `Bearer ${e}`);
  const i = t.trim();
  if (Gl.test(i))
    try {
      const l = await fetch(
        `https://huggingface.co/api/spaces/${i}/host`,
        { headers: n }
      );
      if (l.status !== 200)
        throw new Error("Space metadata could not be loaded.");
      const o = (await l.json()).host;
      return {
        space_id: t,
        ...Rn(o)
      };
    } catch (l) {
      throw new Error("Space metadata could not be loaded." + l.message);
    }
  if (Ku.test(i)) {
    const { ws_protocol: l, http_protocol: o, host: s } = Rn(i);
    return {
      space_id: s.replace(".hf.space", ""),
      ws_protocol: l,
      http_protocol: o,
      host: s
    };
  }
  return {
    space_id: !1,
    ...Rn(i)
  };
}
function Zu(t) {
  let e = {};
  return t.forEach(({ api_name: n }, i) => {
    n && (e[n] = i);
  }), e;
}
const Qu = /^(?=[^]*\b[dD]iscussions{0,1}\b)(?=[^]*\b[dD]isabled\b)[^]*$/;
async function Oi(t) {
  try {
    const n = (await fetch(
      `https://huggingface.co/api/spaces/${t}/discussions`,
      {
        method: "HEAD"
      }
    )).headers.get("x-error-message");
    return !(n && Qu.test(n));
  } catch {
    return !1;
  }
}
function Ee(t, e, n) {
  if (t == null)
    return null;
  if (Array.isArray(t)) {
    const i = [];
    for (const l of t)
      l == null ? i.push(null) : i.push(Ee(l, e, n));
    return i;
  }
  return t.is_stream ? n == null ? new bt({
    ...t,
    url: e + "/stream/" + t.path
  }) : new bt({
    ...t,
    url: "/proxy=" + n + "stream/" + t.path
  }) : new bt({
    ...t,
    url: xu(t.path, e, n)
  });
}
function $u(t) {
  try {
    const e = new URL(t);
    return e.protocol === "http:" || e.protocol === "https:";
  } catch {
    return !1;
  }
}
function xu(t, e, n) {
  return t == null ? n ? `/proxy=${n}file=` : `${e}/file=` : $u(t) ? t : n ? `/proxy=${n}file=${t}` : `${e}/file=${t}`;
}
async function ef(t, e, n, i = of) {
  let l = (Array.isArray(t) ? t : [t]).map(
    (o) => o.blob
  );
  return await Promise.all(
    await i(e, l, void 0, n).then(
      async (o) => {
        if (o.error)
          throw new Error(o.error);
        return o.files ? o.files.map((s, r) => {
          const a = new bt({ ...t[r], path: s });
          return Ee(a, e, null);
        }) : [];
      }
    )
  );
}
async function tf(t, e) {
  return t.map(
    (n, i) => new bt({
      path: n.name,
      orig_name: n.name,
      blob: n,
      size: n.size,
      mime_type: n.type,
      is_stream: e
    })
  );
}
class bt {
  constructor({
    path: e,
    url: n,
    orig_name: i,
    size: l,
    blob: o,
    is_stream: s,
    mime_type: r,
    alt_text: a
  }) {
    this.path = e, this.url = n, this.orig_name = i, this.size = l, this.blob = n ? void 0 : o, this.is_stream = s, this.mime_type = r, this.alt_text = a;
  }
}
const nf = "This application is too busy. Keep trying!", At = "Connection errored out.";
let Jl;
function lf(t, e) {
  return { post_data: n, upload_files: i, client: l, handle_blob: o };
  async function n(s, r, a) {
    const u = { "Content-Type": "application/json" };
    a && (u.Authorization = `Bearer ${a}`);
    try {
      var f = await t(s, {
        method: "POST",
        body: JSON.stringify(r),
        headers: u
      });
    } catch {
      return [{ error: At }, 500];
    }
    return [await f.json(), f.status];
  }
  async function i(s, r, a, u) {
    const f = {};
    a && (f.Authorization = `Bearer ${a}`);
    const c = 1e3, _ = [];
    for (let h = 0; h < r.length; h += c) {
      const k = r.slice(h, h + c), y = new FormData();
      k.forEach((v) => {
        y.append("files", v);
      });
      try {
        const v = u ? `${s}/upload?upload_id=${u}` : `${s}/upload`;
        var d = await t(v, {
          method: "POST",
          body: y,
          headers: f
        });
      } catch {
        return { error: At };
      }
      const p = await d.json();
      _.push(...p);
    }
    return { files: _ };
  }
  async function l(s, r = { normalise_files: !0 }) {
    return new Promise(async (a) => {
      const { status_callback: u, hf_token: f, normalise_files: c } = r, _ = {
        predict: R,
        submit: j,
        view_api: Y,
        component_server: L
      }, d = c ?? !0;
      if ((typeof window > "u" || !("WebSocket" in window)) && !global.Websocket) {
        const C = await import("./wrapper-6f348d45-B5bCGhfq.js");
        Jl = (await import("./__vite-browser-external-DYxpcVy9.js")).Blob, global.WebSocket = C.WebSocket;
      }
      const { ws_protocol: h, http_protocol: k, host: y, space_id: p } = await Hu(s, f), v = Math.random().toString(36).substring(2), b = {};
      let m, g = {}, A = !1;
      f && p && (A = await rf(p, f));
      async function E(C) {
        if (m = C, g = Zu(C?.dependencies || []), m.auth_required)
          return {
            config: m,
            ..._
          };
        try {
          z = await Y(m);
        } catch (w) {
          console.error(`Could not get api details: ${w.message}`);
        }
        return {
          config: m,
          ..._
        };
      }
      let z;
      async function P(C) {
        if (u && u(C), C.status === "running")
          try {
            m = await Pi(
              t,
              `${k}//${y}`,
              f
            );
            const w = await E(m);
            a(w);
          } catch (w) {
            console.error(w), u && u({
              status: "error",
              message: "Could not load this space.",
              load_status: "error",
              detail: "NOT_FOUND"
            });
          }
      }
      try {
        m = await Pi(
          t,
          `${k}//${y}`,
          f
        );
        const C = await E(m);
        a(C);
      } catch (C) {
        console.error(C), p ? $n(
          p,
          Gl.test(p) ? "space_name" : "subdomain",
          P
        ) : u && u({
          status: "error",
          message: "Could not load this space.",
          load_status: "error",
          detail: "NOT_FOUND"
        });
      }
      function R(C, w, V) {
        let T = !1, N = !1, U;
        if (typeof C == "number")
          U = m.dependencies[C];
        else {
          const O = C.replace(/^\//, "");
          U = m.dependencies[g[O]];
        }
        if (U.types.continuous)
          throw new Error(
            "Cannot call predict on this function as it may run forever. Use submit instead"
          );
        return new Promise((O, q) => {
          const I = j(C, w, V);
          let S;
          I.on("data", (W) => {
            N && (I.destroy(), O(W)), T = !0, S = W;
          }).on("status", (W) => {
            W.stage === "error" && q(W), W.stage === "complete" && (N = !0, T && (I.destroy(), O(S)));
          });
        });
      }
      function j(C, w, V, T = null) {
        let N, U;
        if (typeof C == "number")
          N = C, U = z.unnamed_endpoints[N];
        else {
          const K = C.replace(/^\//, "");
          N = g[K], U = z.named_endpoints[C.trim()];
        }
        if (typeof N != "number")
          throw new Error(
            "There is no endpoint matching that name of fn_index matching that number."
          );
        let O, q, I = m.protocol ?? "sse";
        const S = typeof C == "number" ? "/predict" : C;
        let W, Q = null, X = !1;
        const ce = {};
        let se = "";
        typeof window < "u" && (se = new URLSearchParams(window.location.search).toString()), o(
          `${k}//${Ge(y, m.path, !0)}`,
          w,
          U,
          f
        ).then((K) => {
          if (W = { data: K || [], event_data: V, fn_index: N, trigger_id: T }, af(N, m))
            M({
              type: "status",
              endpoint: S,
              stage: "pending",
              queue: !1,
              fn_index: N,
              time: /* @__PURE__ */ new Date()
            }), n(
              `${k}//${Ge(y, m.path, !0)}/run${S.startsWith("/") ? S : `/${S}`}${se ? "?" + se : ""}`,
              {
                ...W,
                session_hash: v
              },
              f
            ).then(([H, te]) => {
              const Ue = d ? Un(
                H.data,
                U,
                m.root,
                m.root_url
              ) : H.data;
              te == 200 ? (M({
                type: "data",
                endpoint: S,
                fn_index: N,
                data: Ue,
                time: /* @__PURE__ */ new Date()
              }), M({
                type: "status",
                endpoint: S,
                fn_index: N,
                stage: "complete",
                eta: H.average_duration,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              })) : M({
                type: "status",
                stage: "error",
                endpoint: S,
                fn_index: N,
                message: H.error,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              });
            }).catch((H) => {
              M({
                type: "status",
                stage: "error",
                message: H.message,
                endpoint: S,
                fn_index: N,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              });
            });
          else if (I == "ws") {
            M({
              type: "status",
              stage: "pending",
              queue: !0,
              endpoint: S,
              fn_index: N,
              time: /* @__PURE__ */ new Date()
            });
            let H = new URL(`${h}://${Ge(
              y,
              m.path,
              !0
            )}
							/queue/join${se ? "?" + se : ""}`);
            A && H.searchParams.set("__sign", A), O = e(H), O.onclose = (te) => {
              te.wasClean || M({
                type: "status",
                stage: "error",
                broken: !0,
                message: At,
                queue: !0,
                endpoint: S,
                fn_index: N,
                time: /* @__PURE__ */ new Date()
              });
            }, O.onmessage = function(te) {
              const Ue = JSON.parse(te.data), { type: de, status: ee, data: ke } = Mi(
                Ue,
                b[N]
              );
              if (de === "update" && ee && !X)
                M({
                  type: "status",
                  endpoint: S,
                  fn_index: N,
                  time: /* @__PURE__ */ new Date(),
                  ...ee
                }), ee.stage === "error" && O.close();
              else if (de === "hash") {
                O.send(JSON.stringify({ fn_index: N, session_hash: v }));
                return;
              } else de === "data" ? O.send(JSON.stringify({ ...W, session_hash: v })) : de === "complete" ? X = ee : de === "log" ? M({
                type: "log",
                log: ke.log,
                level: ke.level,
                endpoint: S,
                fn_index: N
              }) : de === "generating" && M({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...ee,
                stage: ee?.stage,
                queue: !0,
                endpoint: S,
                fn_index: N
              });
              ke && (M({
                type: "data",
                time: /* @__PURE__ */ new Date(),
                data: d ? Un(
                  ke.data,
                  U,
                  m.root,
                  m.root_url
                ) : ke.data,
                endpoint: S,
                fn_index: N
              }), X && (M({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...X,
                stage: ee?.stage,
                queue: !0,
                endpoint: S,
                fn_index: N
              }), O.close()));
            }, Fi(m.version || "2.0.0", "3.6") < 0 && addEventListener(
              "open",
              () => O.send(JSON.stringify({ hash: v }))
            );
          } else {
            M({
              type: "status",
              stage: "pending",
              queue: !0,
              endpoint: S,
              fn_index: N,
              time: /* @__PURE__ */ new Date()
            });
            var _e = new URLSearchParams({
              fn_index: N.toString(),
              session_hash: v
            }).toString();
            let H = new URL(
              `${k}//${Ge(
                y,
                m.path,
                !0
              )}/queue/join?${se ? se + "&" : ""}${_e}`
            );
            q = new EventSource(H), q.onmessage = async function(te) {
              const Ue = JSON.parse(te.data), { type: de, status: ee, data: ke } = Mi(
                Ue,
                b[N]
              );
              if (de === "update" && ee && !X)
                M({
                  type: "status",
                  endpoint: S,
                  fn_index: N,
                  time: /* @__PURE__ */ new Date(),
                  ...ee
                }), ee.stage === "error" && q.close();
              else if (de === "data") {
                Q = Ue.event_id;
                let [pd, qo] = await n(
                  `${k}//${Ge(
                    y,
                    m.path,
                    !0
                  )}/queue/data`,
                  {
                    ...W,
                    session_hash: v,
                    event_id: Q
                  },
                  f
                );
                qo !== 200 && (M({
                  type: "status",
                  stage: "error",
                  message: At,
                  queue: !0,
                  endpoint: S,
                  fn_index: N,
                  time: /* @__PURE__ */ new Date()
                }), q.close());
              } else de === "complete" ? X = ee : de === "log" ? M({
                type: "log",
                log: ke.log,
                level: ke.level,
                endpoint: S,
                fn_index: N
              }) : de === "generating" && M({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...ee,
                stage: ee?.stage,
                queue: !0,
                endpoint: S,
                fn_index: N
              });
              ke && (M({
                type: "data",
                time: /* @__PURE__ */ new Date(),
                data: d ? Un(
                  ke.data,
                  U,
                  m.root,
                  m.root_url
                ) : ke.data,
                endpoint: S,
                fn_index: N
              }), X && (M({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...X,
                stage: ee?.stage,
                queue: !0,
                endpoint: S,
                fn_index: N
              }), q.close()));
            };
          }
        });
        function M(K) {
          const H = ce[K.type] || [];
          H?.forEach((te) => te(K));
        }
        function Ie(K, _e) {
          const H = ce, te = H[K] || [];
          return H[K] = te, te?.push(_e), { on: Ie, off: re, cancel: ve, destroy: ye };
        }
        function re(K, _e) {
          const H = ce;
          let te = H[K] || [];
          return te = te?.filter((Ue) => Ue !== _e), H[K] = te, { on: Ie, off: re, cancel: ve, destroy: ye };
        }
        async function ve() {
          const K = {
            stage: "complete",
            queue: !1,
            time: /* @__PURE__ */ new Date()
          };
          X = K, M({
            ...K,
            type: "status",
            endpoint: S,
            fn_index: N
          });
          let _e = {};
          I === "ws" ? (O && O.readyState === 0 ? O.addEventListener("open", () => {
            O.close();
          }) : O.close(), _e = { fn_index: N, session_hash: v }) : (q.close(), _e = { event_id: Q });
          try {
            await t(
              `${k}//${Ge(
                y,
                m.path,
                !0
              )}/reset`,
              {
                headers: { "Content-Type": "application/json" },
                method: "POST",
                body: JSON.stringify(_e)
              }
            );
          } catch {
            console.warn(
              "The `/reset` endpoint could not be called. Subsequent endpoint results may be unreliable."
            );
          }
        }
        function ye() {
          for (const K in ce)
            ce[K].forEach((_e) => {
              re(K, _e);
            });
        }
        return {
          on: Ie,
          off: re,
          cancel: ve,
          destroy: ye
        };
      }
      async function L(C, w, V) {
        var T;
        const N = { "Content-Type": "application/json" };
        f && (N.Authorization = `Bearer ${f}`);
        let U, O = m.components.find(
          (S) => S.id === C
        );
        (T = O?.props) != null && T.root_url ? U = O.props.root_url : U = `${k}//${Ge(
          y,
          m.path,
          !0
        )}/`;
        const q = await t(
          `${U}component_server/`,
          {
            method: "POST",
            body: JSON.stringify({
              data: V,
              component_id: C,
              fn_name: w,
              session_hash: v
            }),
            headers: N
          }
        );
        if (!q.ok)
          throw new Error(
            "Could not connect to component server: " + q.statusText
          );
        return await q.json();
      }
      async function Y(C) {
        if (z)
          return z;
        const w = { "Content-Type": "application/json" };
        f && (w.Authorization = `Bearer ${f}`);
        let V;
        if (Fi(C.version || "2.0.0", "3.30") < 0 ? V = await t(
          "https://gradio-space-api-fetcher-v2.hf.space/api",
          {
            method: "POST",
            body: JSON.stringify({
              serialize: !1,
              config: JSON.stringify(C)
            }),
            headers: w
          }
        ) : V = await t(`${C.root}/info`, {
          headers: w
        }), !V.ok)
          throw new Error(At);
        let T = await V.json();
        return "api" in T && (T = T.api), T.named_endpoints["/predict"] && !T.unnamed_endpoints[0] && (T.unnamed_endpoints[0] = T.named_endpoints["/predict"]), sf(T, C, g);
      }
    });
  }
  async function o(s, r, a, u) {
    const f = await Qn(
      r,
      void 0,
      [],
      !0,
      a
    );
    return Promise.all(
      f.map(async ({ path: c, blob: _, type: d }) => {
        if (_) {
          const h = (await i(s, [_], u)).files[0];
          return { path: c, file_url: h, type: d, name: _?.name };
        }
        return { path: c, type: d };
      })
    ).then((c) => (c.forEach(({ path: _, file_url: d, type: h, name: k }) => {
      if (h === "Gallery")
        Bi(r, d, _);
      else if (d) {
        const y = new bt({ path: d, orig_name: k });
        Bi(r, y, _);
      }
    }), r));
  }
}
const { post_data: wd, upload_files: of, client: vd, handle_blob: yd } = lf(
  fetch,
  (...t) => new WebSocket(...t)
);
function Un(t, e, n, i) {
  return t.map((l, o) => {
    var s, r, a, u;
    return ((r = (s = e?.returns) == null ? void 0 : s[o]) == null ? void 0 : r.component) === "File" ? Ee(l, n, i) : ((u = (a = e?.returns) == null ? void 0 : a[o]) == null ? void 0 : u.component) === "Gallery" ? l.map((f) => Array.isArray(f) ? [Ee(f[0], n, i), f[1]] : [Ee(f, n, i), null]) : typeof l == "object" && l.path ? Ee(l, n, i) : l;
  });
}
function Ii(t, e, n, i) {
  switch (t.type) {
    case "string":
      return "string";
    case "boolean":
      return "boolean";
    case "number":
      return "number";
  }
  if (n === "JSONSerializable" || n === "StringSerializable")
    return "any";
  if (n === "ListStringSerializable")
    return "string[]";
  if (e === "Image")
    return i === "parameter" ? "Blob | File | Buffer" : "string";
  if (n === "FileSerializable")
    return t?.type === "array" ? i === "parameter" ? "(Blob | File | Buffer)[]" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}[]" : i === "parameter" ? "Blob | File | Buffer" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}";
  if (n === "GallerySerializable")
    return i === "parameter" ? "[(Blob | File | Buffer), (string | null)][]" : "[{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}, (string | null))][]";
}
function Ti(t, e) {
  return e === "GallerySerializable" ? "array of [file, label] tuples" : e === "ListStringSerializable" ? "array of strings" : e === "FileSerializable" ? "array of files or single file" : t.description;
}
function sf(t, e, n) {
  const i = {
    named_endpoints: {},
    unnamed_endpoints: {}
  };
  for (const l in t) {
    const o = t[l];
    for (const s in o) {
      const r = e.dependencies[s] ? s : n[s.replace("/", "")], a = o[s];
      i[l][s] = {}, i[l][s].parameters = {}, i[l][s].returns = {}, i[l][s].type = e.dependencies[r].types, i[l][s].parameters = a.parameters.map(
        ({ label: u, component: f, type: c, serializer: _ }) => ({
          label: u,
          component: f,
          type: Ii(c, f, _, "parameter"),
          description: Ti(c, _)
        })
      ), i[l][s].returns = a.returns.map(
        ({ label: u, component: f, type: c, serializer: _ }) => ({
          label: u,
          component: f,
          type: Ii(c, f, _, "return"),
          description: Ti(c, _)
        })
      );
    }
  }
  return i;
}
async function rf(t, e) {
  try {
    return (await (await fetch(`https://huggingface.co/api/spaces/${t}/jwt`, {
      headers: {
        Authorization: `Bearer ${e}`
      }
    })).json()).token || !1;
  } catch (n) {
    return console.error(n), !1;
  }
}
function Bi(t, e, n) {
  for (; n.length > 1; )
    t = t[n.shift()];
  t[n.shift()] = e;
}
async function Qn(t, e = void 0, n = [], i = !1, l = void 0) {
  if (Array.isArray(t)) {
    let o = [];
    return await Promise.all(
      t.map(async (s, r) => {
        var a;
        let u = n.slice();
        u.push(r);
        const f = await Qn(
          t[r],
          i ? ((a = l?.parameters[r]) == null ? void 0 : a.component) || void 0 : e,
          u,
          !1,
          l
        );
        o = o.concat(f);
      })
    ), o;
  } else {
    if (globalThis.Buffer && t instanceof globalThis.Buffer)
      return [
        {
          path: n,
          blob: e === "Image" ? !1 : new Jl([t]),
          type: e
        }
      ];
    if (typeof t == "object") {
      let o = [];
      for (let s in t)
        if (t.hasOwnProperty(s)) {
          let r = n.slice();
          r.push(s), o = o.concat(
            await Qn(
              t[s],
              void 0,
              r,
              !1,
              l
            )
          );
        }
      return o;
    }
  }
  return [];
}
function af(t, e) {
  var n, i, l, o;
  return !(((i = (n = e?.dependencies) == null ? void 0 : n[t]) == null ? void 0 : i.queue) === null ? e.enable_queue : (o = (l = e?.dependencies) == null ? void 0 : l[t]) != null && o.queue) || !1;
}
async function Pi(t, e, n) {
  const i = {};
  if (n && (i.Authorization = `Bearer ${n}`), typeof window < "u" && window.gradio_config && location.origin !== "http://localhost:9876" && !window.gradio_config.dev_mode) {
    const l = window.gradio_config.root, o = window.gradio_config;
    return o.root = Ge(e, o.root, !1), { ...o, path: l };
  } else if (e) {
    let l = await t(`${e}/config`, {
      headers: i
    });
    if (l.status === 200) {
      const o = await l.json();
      return o.path = o.path ?? "", o.root = e, o;
    }
    throw new Error("Could not get config.");
  }
  throw new Error("No config or app endpoint found");
}
async function $n(t, e, n) {
  let i = e === "subdomain" ? `https://huggingface.co/api/spaces/by-subdomain/${t}` : `https://huggingface.co/api/spaces/${t}`, l, o;
  try {
    if (l = await fetch(i), o = l.status, o !== 200)
      throw new Error();
    l = await l.json();
  } catch {
    n({
      status: "error",
      load_status: "error",
      message: "Could not get space status",
      detail: "NOT_FOUND"
    });
    return;
  }
  if (!l || o !== 200)
    return;
  const {
    runtime: { stage: s },
    id: r
  } = l;
  switch (s) {
    case "STOPPED":
    case "SLEEPING":
      n({
        status: "sleeping",
        load_status: "pending",
        message: "Space is asleep. Waking it up...",
        detail: s
      }), setTimeout(() => {
        $n(t, e, n);
      }, 1e3);
      break;
    case "PAUSED":
      n({
        status: "paused",
        load_status: "error",
        message: "This space has been paused by the author. If you would like to try this demo, consider duplicating the space.",
        detail: s,
        discussions_enabled: await Oi(r)
      });
      break;
    case "RUNNING":
    case "RUNNING_BUILDING":
      n({
        status: "running",
        load_status: "complete",
        message: "",
        detail: s
      });
      break;
    case "BUILDING":
      n({
        status: "building",
        load_status: "pending",
        message: "Space is building...",
        detail: s
      }), setTimeout(() => {
        $n(t, e, n);
      }, 1e3);
      break;
    default:
      n({
        status: "space_error",
        load_status: "error",
        message: "This space is experiencing an issue.",
        detail: s,
        discussions_enabled: await Oi(r)
      });
      break;
  }
}
function Mi(t, e) {
  switch (t.msg) {
    case "send_data":
      return { type: "data" };
    case "send_hash":
      return { type: "hash" };
    case "queue_full":
      return {
        type: "update",
        status: {
          queue: !0,
          message: nf,
          stage: "error",
          code: t.code,
          success: t.success
        }
      };
    case "estimation":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: e || "pending",
          code: t.code,
          size: t.queue_size,
          position: t.rank,
          eta: t.rank_eta,
          success: t.success
        }
      };
    case "progress":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: t.code,
          progress_data: t.progress_data,
          success: t.success
        }
      };
    case "log":
      return { type: "log", data: t };
    case "process_generating":
      return {
        type: "generating",
        status: {
          queue: !0,
          message: t.success ? null : t.output.error,
          stage: t.success ? "generating" : "error",
          code: t.code,
          progress_data: t.progress_data,
          eta: t.average_duration
        },
        data: t.success ? t.output : null
      };
    case "process_completed":
      return "error" in t.output ? {
        type: "update",
        status: {
          queue: !0,
          message: t.output.error,
          stage: "error",
          code: t.code,
          success: t.success
        }
      } : {
        type: "complete",
        status: {
          queue: !0,
          message: t.success ? void 0 : t.output.error,
          stage: t.success ? "complete" : "error",
          code: t.code,
          progress_data: t.progress_data,
          eta: t.output.average_duration
        },
        data: t.success ? t.output : null
      };
    case "process_starts":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: t.code,
          size: t.rank,
          position: 0,
          success: t.success
        }
      };
  }
  return { type: "none", status: { stage: "error", queue: !0 } };
}
const {
  SvelteComponent: uf,
  append: ue,
  attr: nt,
  detach: Yl,
  element: it,
  init: ff,
  insert: Kl,
  noop: Ri,
  safe_not_equal: cf,
  set_data: on,
  set_style: jn,
  space: xn,
  text: ht,
  toggle_class: Ui
} = window.__gradio__svelte__internal, { onMount: _f, createEventDispatcher: df } = window.__gradio__svelte__internal;
function ji(t) {
  let e, n, i, l, o = Lt(
    /*current_file_upload*/
    t[2]
  ) + "", s, r, a, u, f = (
    /*current_file_upload*/
    t[2].orig_name + ""
  ), c;
  return {
    c() {
      e = it("div"), n = it("span"), i = it("div"), l = it("progress"), s = ht(o), a = xn(), u = it("span"), c = ht(f), jn(l, "visibility", "hidden"), jn(l, "height", "0"), jn(l, "width", "0"), l.value = r = Lt(
        /*current_file_upload*/
        t[2]
      ), nt(l, "max", "100"), nt(l, "class", "svelte-1juivz4"), nt(i, "class", "progress-bar svelte-1juivz4"), nt(u, "class", "file-name svelte-1juivz4"), nt(e, "class", "file svelte-1juivz4");
    },
    m(_, d) {
      Kl(_, e, d), ue(e, n), ue(n, i), ue(i, l), ue(l, s), ue(e, a), ue(e, u), ue(u, c);
    },
    p(_, d) {
      d & /*current_file_upload*/
      4 && o !== (o = Lt(
        /*current_file_upload*/
        _[2]
      ) + "") && on(s, o), d & /*current_file_upload*/
      4 && r !== (r = Lt(
        /*current_file_upload*/
        _[2]
      )) && (l.value = r), d & /*current_file_upload*/
      4 && f !== (f = /*current_file_upload*/
      _[2].orig_name + "") && on(c, f);
    },
    d(_) {
      _ && Yl(e);
    }
  };
}
function hf(t) {
  let e, n, i, l = (
    /*files_with_progress*/
    t[0].length + ""
  ), o, s, r = (
    /*files_with_progress*/
    t[0].length > 1 ? "files" : "file"
  ), a, u, f, c = (
    /*current_file_upload*/
    t[2] && ji(t)
  );
  return {
    c() {
      e = it("div"), n = it("span"), i = ht("Uploading "), o = ht(l), s = xn(), a = ht(r), u = ht("..."), f = xn(), c && c.c(), nt(n, "class", "uploading svelte-1juivz4"), nt(e, "class", "wrap svelte-1juivz4"), Ui(
        e,
        "progress",
        /*progress*/
        t[1]
      );
    },
    m(_, d) {
      Kl(_, e, d), ue(e, n), ue(n, i), ue(n, o), ue(n, s), ue(n, a), ue(n, u), ue(e, f), c && c.m(e, null);
    },
    p(_, [d]) {
      d & /*files_with_progress*/
      1 && l !== (l = /*files_with_progress*/
      _[0].length + "") && on(o, l), d & /*files_with_progress*/
      1 && r !== (r = /*files_with_progress*/
      _[0].length > 1 ? "files" : "file") && on(a, r), /*current_file_upload*/
      _[2] ? c ? c.p(_, d) : (c = ji(_), c.c(), c.m(e, null)) : c && (c.d(1), c = null), d & /*progress*/
      2 && Ui(
        e,
        "progress",
        /*progress*/
        _[1]
      );
    },
    i: Ri,
    o: Ri,
    d(_) {
      _ && Yl(e), c && c.d();
    }
  };
}
function Lt(t) {
  return t.progress * 100 / (t.size || 0) || 0;
}
function mf(t) {
  let e = 0;
  return t.forEach((n) => {
    e += Lt(n);
  }), document.documentElement.style.setProperty("--upload-progress-width", (e / t.length).toFixed(2) + "%"), e / t.length;
}
function gf(t, e, n) {
  var i = this && this.__awaiter || function(d, h, k, y) {
    function p(v) {
      return v instanceof k ? v : new k(function(b) {
        b(v);
      });
    }
    return new (k || (k = Promise))(function(v, b) {
      function m(E) {
        try {
          A(y.next(E));
        } catch (z) {
          b(z);
        }
      }
      function g(E) {
        try {
          A(y.throw(E));
        } catch (z) {
          b(z);
        }
      }
      function A(E) {
        E.done ? v(E.value) : p(E.value).then(m, g);
      }
      A((y = y.apply(d, h || [])).next());
    });
  };
  let { upload_id: l } = e, { root: o } = e, { files: s } = e, r, a = !1, u, f = s.map((d) => Object.assign(Object.assign({}, d), { progress: 0 }));
  const c = df();
  function _(d, h) {
    n(0, f = f.map((k) => (k.orig_name === d && (k.progress += h), k)));
  }
  return _f(() => {
    r = new EventSource(`${o}/upload_progress?upload_id=${l}`), r.onmessage = function(d) {
      return i(this, void 0, void 0, function* () {
        const h = JSON.parse(d.data);
        a || n(1, a = !0), h.msg === "done" ? (r.close(), c("done")) : (n(2, u = h), _(h.orig_name, h.chunk_size));
      });
    };
  }), t.$$set = (d) => {
    "upload_id" in d && n(3, l = d.upload_id), "root" in d && n(4, o = d.root), "files" in d && n(5, s = d.files);
  }, t.$$.update = () => {
    t.$$.dirty & /*files_with_progress*/
    1 && mf(f);
  }, [f, a, u, l, o, s];
}
class pf extends uf {
  constructor(e) {
    super(), ff(this, e, gf, hf, cf, { upload_id: 3, root: 4, files: 5 });
  }
}
const {
  SvelteComponent: bf,
  append: Vi,
  attr: me,
  binding_callbacks: wf,
  bubble: xe,
  check_outros: vf,
  create_component: yf,
  create_slot: kf,
  destroy_component: Sf,
  detach: Hl,
  element: Wi,
  empty: qf,
  get_all_dirty_from_scope: Cf,
  get_slot_changes: Ef,
  group_outros: Nf,
  init: Af,
  insert: Zl,
  listen: ge,
  mount_component: zf,
  prevent_default: et,
  run_all: Lf,
  safe_not_equal: Df,
  set_style: Xi,
  space: Ff,
  stop_propagation: tt,
  toggle_class: Xe,
  transition_in: sn,
  transition_out: rn,
  update_slot_base: Of
} = window.__gradio__svelte__internal, { createEventDispatcher: If, tick: Tf, getContext: Bf } = window.__gradio__svelte__internal;
function Pf(t) {
  let e, n, i, l, o, s, r, a, u, f;
  const c = (
    /*#slots*/
    t[21].default
  ), _ = kf(
    c,
    t,
    /*$$scope*/
    t[20],
    null
  );
  return {
    c() {
      e = Wi("button"), _ && _.c(), n = Ff(), i = Wi("input"), me(i, "aria-label", "file upload"), me(i, "type", "file"), me(
        i,
        "accept",
        /*filetype*/
        t[1]
      ), i.multiple = l = /*file_count*/
      t[5] === "multiple" || void 0, me(i, "webkitdirectory", o = /*file_count*/
      t[5] === "directory" || void 0), me(i, "mozdirectory", s = /*file_count*/
      t[5] === "directory" || void 0), me(i, "class", "svelte-1aq8tno"), me(e, "tabindex", r = /*hidden*/
      t[7] ? -1 : 0), me(e, "class", "svelte-1aq8tno"), Xe(
        e,
        "hidden",
        /*hidden*/
        t[7]
      ), Xe(
        e,
        "center",
        /*center*/
        t[3]
      ), Xe(
        e,
        "boundedheight",
        /*boundedheight*/
        t[2]
      ), Xe(
        e,
        "flex",
        /*flex*/
        t[4]
      ), Xi(
        e,
        "height",
        /*include_sources*/
        t[8] ? "calc(100% - 40px" : "100%"
      );
    },
    m(d, h) {
      Zl(d, e, h), _ && _.m(e, null), Vi(e, n), Vi(e, i), t[29](i), a = !0, u || (f = [
        ge(
          i,
          "change",
          /*load_files_from_upload*/
          t[14]
        ),
        ge(e, "drag", tt(et(
          /*drag_handler*/
          t[22]
        ))),
        ge(e, "dragstart", tt(et(
          /*dragstart_handler*/
          t[23]
        ))),
        ge(e, "dragend", tt(et(
          /*dragend_handler*/
          t[24]
        ))),
        ge(e, "dragover", tt(et(
          /*dragover_handler*/
          t[25]
        ))),
        ge(e, "dragenter", tt(et(
          /*dragenter_handler*/
          t[26]
        ))),
        ge(e, "dragleave", tt(et(
          /*dragleave_handler*/
          t[27]
        ))),
        ge(e, "drop", tt(et(
          /*drop_handler*/
          t[28]
        ))),
        ge(
          e,
          "click",
          /*open_file_upload*/
          t[9]
        ),
        ge(
          e,
          "drop",
          /*loadFilesFromDrop*/
          t[15]
        ),
        ge(
          e,
          "dragenter",
          /*updateDragging*/
          t[13]
        ),
        ge(
          e,
          "dragleave",
          /*updateDragging*/
          t[13]
        )
      ], u = !0);
    },
    p(d, h) {
      _ && _.p && (!a || h[0] & /*$$scope*/
      1048576) && Of(
        _,
        c,
        d,
        /*$$scope*/
        d[20],
        a ? Ef(
          c,
          /*$$scope*/
          d[20],
          h,
          null
        ) : Cf(
          /*$$scope*/
          d[20]
        ),
        null
      ), (!a || h[0] & /*filetype*/
      2) && me(
        i,
        "accept",
        /*filetype*/
        d[1]
      ), (!a || h[0] & /*file_count*/
      32 && l !== (l = /*file_count*/
      d[5] === "multiple" || void 0)) && (i.multiple = l), (!a || h[0] & /*file_count*/
      32 && o !== (o = /*file_count*/
      d[5] === "directory" || void 0)) && me(i, "webkitdirectory", o), (!a || h[0] & /*file_count*/
      32 && s !== (s = /*file_count*/
      d[5] === "directory" || void 0)) && me(i, "mozdirectory", s), (!a || h[0] & /*hidden*/
      128 && r !== (r = /*hidden*/
      d[7] ? -1 : 0)) && me(e, "tabindex", r), (!a || h[0] & /*hidden*/
      128) && Xe(
        e,
        "hidden",
        /*hidden*/
        d[7]
      ), (!a || h[0] & /*center*/
      8) && Xe(
        e,
        "center",
        /*center*/
        d[3]
      ), (!a || h[0] & /*boundedheight*/
      4) && Xe(
        e,
        "boundedheight",
        /*boundedheight*/
        d[2]
      ), (!a || h[0] & /*flex*/
      16) && Xe(
        e,
        "flex",
        /*flex*/
        d[4]
      ), h[0] & /*include_sources*/
      256 && Xi(
        e,
        "height",
        /*include_sources*/
        d[8] ? "calc(100% - 40px" : "100%"
      );
    },
    i(d) {
      a || (sn(_, d), a = !0);
    },
    o(d) {
      rn(_, d), a = !1;
    },
    d(d) {
      d && Hl(e), _ && _.d(d), t[29](null), u = !1, Lf(f);
    }
  };
}
function Mf(t) {
  let e, n;
  return e = new pf({
    props: {
      root: (
        /*root*/
        t[6]
      ),
      upload_id: (
        /*upload_id*/
        t[10]
      ),
      files: (
        /*file_data*/
        t[11]
      )
    }
  }), {
    c() {
      yf(e.$$.fragment);
    },
    m(i, l) {
      zf(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*root*/
      64 && (o.root = /*root*/
      i[6]), l[0] & /*upload_id*/
      1024 && (o.upload_id = /*upload_id*/
      i[10]), l[0] & /*file_data*/
      2048 && (o.files = /*file_data*/
      i[11]), e.$set(o);
    },
    i(i) {
      n || (sn(e.$$.fragment, i), n = !0);
    },
    o(i) {
      rn(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Sf(e, i);
    }
  };
}
function Rf(t) {
  let e, n, i, l;
  const o = [Mf, Pf], s = [];
  function r(a, u) {
    return (
      /*uploading*/
      a[0] ? 0 : 1
    );
  }
  return e = r(t), n = s[e] = o[e](t), {
    c() {
      n.c(), i = qf();
    },
    m(a, u) {
      s[e].m(a, u), Zl(a, i, u), l = !0;
    },
    p(a, u) {
      let f = e;
      e = r(a), e === f ? s[e].p(a, u) : (Nf(), rn(s[f], 1, 1, () => {
        s[f] = null;
      }), vf(), n = s[e], n ? n.p(a, u) : (n = s[e] = o[e](a), n.c()), sn(n, 1), n.m(i.parentNode, i));
    },
    i(a) {
      l || (sn(n), l = !0);
    },
    o(a) {
      rn(n), l = !1;
    },
    d(a) {
      a && Hl(i), s[e].d(a);
    }
  };
}
function Uf(t, e) {
  return !t || t === "*" ? !0 : t.endsWith("/*") ? e.startsWith(t.slice(0, -1)) : t === e;
}
function jf(t, e, n) {
  let { $$slots: i = {}, $$scope: l } = e;
  var o = this && this.__awaiter || function(q, I, S, W) {
    function Q(X) {
      return X instanceof S ? X : new S(function(ce) {
        ce(X);
      });
    }
    return new (S || (S = Promise))(function(X, ce) {
      function se(re) {
        try {
          Ie(W.next(re));
        } catch (ve) {
          ce(ve);
        }
      }
      function M(re) {
        try {
          Ie(W.throw(re));
        } catch (ve) {
          ce(ve);
        }
      }
      function Ie(re) {
        re.done ? X(re.value) : Q(re.value).then(se, M);
      }
      Ie((W = W.apply(q, I || [])).next());
    });
  };
  let { filetype: s = null } = e, { dragging: r = !1 } = e, { boundedheight: a = !0 } = e, { center: u = !0 } = e, { flex: f = !0 } = e, { file_count: c = "single" } = e, { disable_click: _ = !1 } = e, { root: d } = e, { hidden: h = !1 } = e, { format: k = "file" } = e, { include_sources: y = !1 } = e, { uploading: p = !1 } = e, v, b;
  const m = Bf("upload_files");
  let g;
  const A = If();
  function E() {
    n(16, r = !r);
  }
  function z() {
    _ || (n(12, g.value = "", g), g.click());
  }
  function P(q) {
    return o(this, void 0, void 0, function* () {
      yield Tf(), n(10, v = Math.random().toString(36).substring(2, 15)), n(0, p = !0);
      const I = yield ef(q, d, v, m);
      return A("load", c === "single" ? I?.[0] : I), n(0, p = !1), I || [];
    });
  }
  function R(q) {
    return o(this, void 0, void 0, function* () {
      if (!q.length)
        return;
      let I = q.map((S) => new File([S], S.name));
      return n(11, b = yield tf(I)), yield P(b);
    });
  }
  function j(q) {
    return o(this, void 0, void 0, function* () {
      const I = q.target;
      if (I.files)
        if (k != "blob")
          yield R(Array.from(I.files));
        else {
          if (c === "single") {
            A("load", I.files[0]);
            return;
          }
          A("load", I.files);
        }
    });
  }
  function L(q) {
    return o(this, void 0, void 0, function* () {
      var I;
      if (n(16, r = !1), !(!((I = q.dataTransfer) === null || I === void 0) && I.files)) return;
      const S = Array.from(q.dataTransfer.files).filter((W) => s?.split(",").some((Q) => Uf(Q, W.type)) ? !0 : (A("error", `Invalid file type only ${s} allowed.`), !1));
      yield R(S);
    });
  }
  function Y(q) {
    xe.call(this, t, q);
  }
  function C(q) {
    xe.call(this, t, q);
  }
  function w(q) {
    xe.call(this, t, q);
  }
  function V(q) {
    xe.call(this, t, q);
  }
  function T(q) {
    xe.call(this, t, q);
  }
  function N(q) {
    xe.call(this, t, q);
  }
  function U(q) {
    xe.call(this, t, q);
  }
  function O(q) {
    wf[q ? "unshift" : "push"](() => {
      g = q, n(12, g);
    });
  }
  return t.$$set = (q) => {
    "filetype" in q && n(1, s = q.filetype), "dragging" in q && n(16, r = q.dragging), "boundedheight" in q && n(2, a = q.boundedheight), "center" in q && n(3, u = q.center), "flex" in q && n(4, f = q.flex), "file_count" in q && n(5, c = q.file_count), "disable_click" in q && n(17, _ = q.disable_click), "root" in q && n(6, d = q.root), "hidden" in q && n(7, h = q.hidden), "format" in q && n(18, k = q.format), "include_sources" in q && n(8, y = q.include_sources), "uploading" in q && n(0, p = q.uploading), "$$scope" in q && n(20, l = q.$$scope);
  }, [
    p,
    s,
    a,
    u,
    f,
    c,
    d,
    h,
    y,
    z,
    v,
    b,
    g,
    E,
    j,
    L,
    r,
    _,
    k,
    R,
    l,
    i,
    Y,
    C,
    w,
    V,
    T,
    N,
    U,
    O
  ];
}
class Ql extends bf {
  constructor(e) {
    super(), Af(
      this,
      e,
      jf,
      Rf,
      Df,
      {
        filetype: 1,
        dragging: 16,
        boundedheight: 2,
        center: 3,
        flex: 4,
        file_count: 5,
        disable_click: 17,
        root: 6,
        hidden: 7,
        format: 18,
        include_sources: 8,
        uploading: 0,
        open_file_upload: 9,
        load_files: 19
      },
      null,
      [-1, -1]
    );
  }
  get open_file_upload() {
    return this.$$.ctx[9];
  }
  get load_files() {
    return this.$$.ctx[19];
  }
}
const { setContext: kd, getContext: Vf } = window.__gradio__svelte__internal, Wf = "WORKER_PROXY_CONTEXT_KEY";
function Xf() {
  return Vf(Wf);
}
function Gf(t) {
  return t.host === window.location.host || t.host === "localhost:7860" || t.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  t.host === "lite.local";
}
function Jf(t, e) {
  const n = e.toLowerCase();
  for (const [i, l] of Object.entries(t))
    if (i.toLowerCase() === n)
      return l;
}
function Yf(t) {
  if (t == null)
    return !1;
  const e = new URL(t, window.location.href);
  return !(!Gf(e) || e.protocol !== "http:" && e.protocol !== "https:");
}
const {
  SvelteComponent: Kf,
  assign: an,
  check_outros: $l,
  compute_rest_props: Gi,
  create_slot: oi,
  detach: kn,
  element: xl,
  empty: eo,
  exclude_internal_props: Hf,
  get_all_dirty_from_scope: si,
  get_slot_changes: ri,
  get_spread_update: to,
  group_outros: no,
  init: Zf,
  insert: Sn,
  listen: io,
  prevent_default: Qf,
  safe_not_equal: $f,
  set_attributes: un,
  transition_in: rt,
  transition_out: at,
  update_slot_base: ai
} = window.__gradio__svelte__internal, { createEventDispatcher: xf } = window.__gradio__svelte__internal;
function ec(t) {
  let e, n, i, l, o;
  const s = (
    /*#slots*/
    t[8].default
  ), r = oi(
    s,
    t,
    /*$$scope*/
    t[7],
    null
  );
  let a = [
    { href: (
      /*href*/
      t[0]
    ) },
    {
      target: n = typeof window < "u" && window.__is_colab__ ? "_blank" : null
    },
    { rel: "noopener noreferrer" },
    { download: (
      /*download*/
      t[1]
    ) },
    /*$$restProps*/
    t[6]
  ], u = {};
  for (let f = 0; f < a.length; f += 1)
    u = an(u, a[f]);
  return {
    c() {
      e = xl("a"), r && r.c(), un(e, u);
    },
    m(f, c) {
      Sn(f, e, c), r && r.m(e, null), i = !0, l || (o = io(
        e,
        "click",
        /*dispatch*/
        t[3].bind(null, "click")
      ), l = !0);
    },
    p(f, c) {
      r && r.p && (!i || c & /*$$scope*/
      128) && ai(
        r,
        s,
        f,
        /*$$scope*/
        f[7],
        i ? ri(
          s,
          /*$$scope*/
          f[7],
          c,
          null
        ) : si(
          /*$$scope*/
          f[7]
        ),
        null
      ), un(e, u = to(a, [
        (!i || c & /*href*/
        1) && { href: (
          /*href*/
          f[0]
        ) },
        { target: n },
        { rel: "noopener noreferrer" },
        (!i || c & /*download*/
        2) && { download: (
          /*download*/
          f[1]
        ) },
        c & /*$$restProps*/
        64 && /*$$restProps*/
        f[6]
      ]));
    },
    i(f) {
      i || (rt(r, f), i = !0);
    },
    o(f) {
      at(r, f), i = !1;
    },
    d(f) {
      f && kn(e), r && r.d(f), l = !1, o();
    }
  };
}
function tc(t) {
  let e, n, i, l;
  const o = [ic, nc], s = [];
  function r(a, u) {
    return (
      /*is_downloading*/
      a[2] ? 0 : 1
    );
  }
  return e = r(t), n = s[e] = o[e](t), {
    c() {
      n.c(), i = eo();
    },
    m(a, u) {
      s[e].m(a, u), Sn(a, i, u), l = !0;
    },
    p(a, u) {
      let f = e;
      e = r(a), e === f ? s[e].p(a, u) : (no(), at(s[f], 1, 1, () => {
        s[f] = null;
      }), $l(), n = s[e], n ? n.p(a, u) : (n = s[e] = o[e](a), n.c()), rt(n, 1), n.m(i.parentNode, i));
    },
    i(a) {
      l || (rt(n), l = !0);
    },
    o(a) {
      at(n), l = !1;
    },
    d(a) {
      a && kn(i), s[e].d(a);
    }
  };
}
function nc(t) {
  let e, n, i, l;
  const o = (
    /*#slots*/
    t[8].default
  ), s = oi(
    o,
    t,
    /*$$scope*/
    t[7],
    null
  );
  let r = [
    /*$$restProps*/
    t[6],
    { href: (
      /*href*/
      t[0]
    ) }
  ], a = {};
  for (let u = 0; u < r.length; u += 1)
    a = an(a, r[u]);
  return {
    c() {
      e = xl("a"), s && s.c(), un(e, a);
    },
    m(u, f) {
      Sn(u, e, f), s && s.m(e, null), n = !0, i || (l = io(e, "click", Qf(
        /*wasm_click_handler*/
        t[5]
      )), i = !0);
    },
    p(u, f) {
      s && s.p && (!n || f & /*$$scope*/
      128) && ai(
        s,
        o,
        u,
        /*$$scope*/
        u[7],
        n ? ri(
          o,
          /*$$scope*/
          u[7],
          f,
          null
        ) : si(
          /*$$scope*/
          u[7]
        ),
        null
      ), un(e, a = to(r, [
        f & /*$$restProps*/
        64 && /*$$restProps*/
        u[6],
        (!n || f & /*href*/
        1) && { href: (
          /*href*/
          u[0]
        ) }
      ]));
    },
    i(u) {
      n || (rt(s, u), n = !0);
    },
    o(u) {
      at(s, u), n = !1;
    },
    d(u) {
      u && kn(e), s && s.d(u), i = !1, l();
    }
  };
}
function ic(t) {
  let e;
  const n = (
    /*#slots*/
    t[8].default
  ), i = oi(
    n,
    t,
    /*$$scope*/
    t[7],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(l, o) {
      i && i.m(l, o), e = !0;
    },
    p(l, o) {
      i && i.p && (!e || o & /*$$scope*/
      128) && ai(
        i,
        n,
        l,
        /*$$scope*/
        l[7],
        e ? ri(
          n,
          /*$$scope*/
          l[7],
          o,
          null
        ) : si(
          /*$$scope*/
          l[7]
        ),
        null
      );
    },
    i(l) {
      e || (rt(i, l), e = !0);
    },
    o(l) {
      at(i, l), e = !1;
    },
    d(l) {
      i && i.d(l);
    }
  };
}
function lc(t) {
  let e, n, i, l, o;
  const s = [tc, ec], r = [];
  function a(u, f) {
    return f & /*href*/
    1 && (e = null), e == null && (e = !!/*worker_proxy*/
    (u[4] && Yf(
      /*href*/
      u[0]
    ))), e ? 0 : 1;
  }
  return n = a(t, -1), i = r[n] = s[n](t), {
    c() {
      i.c(), l = eo();
    },
    m(u, f) {
      r[n].m(u, f), Sn(u, l, f), o = !0;
    },
    p(u, [f]) {
      let c = n;
      n = a(u, f), n === c ? r[n].p(u, f) : (no(), at(r[c], 1, 1, () => {
        r[c] = null;
      }), $l(), i = r[n], i ? i.p(u, f) : (i = r[n] = s[n](u), i.c()), rt(i, 1), i.m(l.parentNode, l));
    },
    i(u) {
      o || (rt(i), o = !0);
    },
    o(u) {
      at(i), o = !1;
    },
    d(u) {
      u && kn(l), r[n].d(u);
    }
  };
}
function oc(t, e, n) {
  const i = ["href", "download"];
  let l = Gi(e, i), { $$slots: o = {}, $$scope: s } = e;
  var r = this && this.__awaiter || function(h, k, y, p) {
    function v(b) {
      return b instanceof y ? b : new y(function(m) {
        m(b);
      });
    }
    return new (y || (y = Promise))(function(b, m) {
      function g(z) {
        try {
          E(p.next(z));
        } catch (P) {
          m(P);
        }
      }
      function A(z) {
        try {
          E(p.throw(z));
        } catch (P) {
          m(P);
        }
      }
      function E(z) {
        z.done ? b(z.value) : v(z.value).then(g, A);
      }
      E((p = p.apply(h, k || [])).next());
    });
  };
  let { href: a = void 0 } = e, { download: u } = e;
  const f = xf();
  let c = !1;
  const _ = Xf();
  function d() {
    return r(this, void 0, void 0, function* () {
      if (c)
        return;
      if (f("click"), a == null)
        throw new Error("href is not defined.");
      if (_ == null)
        throw new Error("Wasm worker proxy is not available.");
      const k = new URL(a, window.location.href).pathname;
      n(2, c = !0), _.httpRequest({
        method: "GET",
        path: k,
        headers: {},
        query_string: ""
      }).then((y) => {
        if (y.status !== 200)
          throw new Error(`Failed to get file ${k} from the Wasm worker.`);
        const p = new Blob(
          [y.body],
          {
            type: Jf(y.headers, "content-type")
          }
        ), v = URL.createObjectURL(p), b = document.createElement("a");
        b.href = v, b.download = u, b.click(), URL.revokeObjectURL(v);
      }).finally(() => {
        n(2, c = !1);
      });
    });
  }
  return t.$$set = (h) => {
    e = an(an({}, e), Hf(h)), n(6, l = Gi(e, i)), "href" in h && n(0, a = h.href), "download" in h && n(1, u = h.download), "$$scope" in h && n(7, s = h.$$scope);
  }, [
    a,
    u,
    c,
    f,
    _,
    d,
    l,
    s,
    o
  ];
}
class ui extends Kf {
  constructor(e) {
    super(), Zf(this, e, oc, lc, $f, { href: 0, download: 1 });
  }
}
const {
  SvelteComponent: sc,
  add_flush_callback: fi,
  add_iframe_resize_listener: rc,
  add_render_callback: ac,
  append: ei,
  attr: oe,
  bind: ci,
  binding_callbacks: _i,
  check_outros: Ot,
  create_component: Pe,
  create_slot: lo,
  destroy_component: Me,
  detach: Ze,
  element: ut,
  get_all_dirty_from_scope: oo,
  get_slot_changes: so,
  group_outros: It,
  init: uc,
  insert: Qe,
  mount_component: Re,
  noop: vt,
  safe_not_equal: fc,
  set_style: mt,
  space: tn,
  src_url_equal: fn,
  toggle_class: Oe,
  transition_in: G,
  transition_out: Z,
  update_slot_base: ro
} = window.__gradio__svelte__internal, { createEventDispatcher: cc, tick: _c } = window.__gradio__svelte__internal;
function Ji(t) {
  let e, n;
  return e = new Yu({}), e.$on(
    "remove_image",
    /*remove_image_handler*/
    t[16]
  ), {
    c() {
      Pe(e.$$.fragment);
    },
    m(i, l) {
      Re(e, i, l), n = !0;
    },
    p: vt,
    i(i) {
      n || (G(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Z(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Me(e, i);
    }
  };
}
function Yi(t) {
  let e, n, i = (
    /*show_download_button*/
    t[6] && Ki(t)
  );
  return {
    c() {
      e = ut("div"), i && i.c(), oe(e, "class", "icon-buttons svelte-106mu0e");
    },
    m(l, o) {
      Qe(l, e, o), i && i.m(e, null), n = !0;
    },
    p(l, o) {
      /*show_download_button*/
      l[6] ? i ? (i.p(l, o), o & /*show_download_button*/
      64 && G(i, 1)) : (i = Ki(l), i.c(), G(i, 1), i.m(e, null)) : i && (It(), Z(i, 1, 1, () => {
        i = null;
      }), Ot());
    },
    i(l) {
      n || (G(i), n = !0);
    },
    o(l) {
      Z(i), n = !1;
    },
    d(l) {
      l && Ze(e), i && i.d();
    }
  };
}
function Ki(t) {
  let e, n;
  return e = new ui({
    props: {
      href: (
        /*value*/
        t[0][1].url
      ),
      download: (
        /*value*/
        t[0][1].orig_name || "image"
      ),
      $$slots: { default: [dc] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      Pe(e.$$.fragment);
    },
    m(i, l) {
      Re(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*value*/
      1 && (o.href = /*value*/
      i[0][1].url), l & /*value*/
      1 && (o.download = /*value*/
      i[0][1].orig_name || "image"), l & /*$$scope*/
      8388608 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (G(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Z(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Me(e, i);
    }
  };
}
function dc(t) {
  let e, n;
  return e = new vn({ props: { Icon: li } }), {
    c() {
      Pe(e.$$.fragment);
    },
    m(i, l) {
      Re(e, i, l), n = !0;
    },
    p: vt,
    i(i) {
      n || (G(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Z(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Me(e, i);
    }
  };
}
function hc(t) {
  let e, n;
  return {
    c() {
      e = ut("img"), fn(e.src, n = /*value_*/
      t[9][0]?.url) || oe(e, "src", n), oe(e, "alt", ""), oe(e, "class", "svelte-106mu0e"), Oe(
        e,
        "half-wrap",
        /*upload_count*/
        t[5] === 2 && !/*value*/
        t[0]?.[1]?.url
      );
    },
    m(i, l) {
      Qe(i, e, l);
    },
    p(i, l) {
      l & /*value_*/
      512 && !fn(e.src, n = /*value_*/
      i[9][0]?.url) && oe(e, "src", n), l & /*upload_count, value*/
      33 && Oe(
        e,
        "half-wrap",
        /*upload_count*/
        i[5] === 2 && !/*value*/
        i[0]?.[1]?.url
      );
    },
    i: vt,
    o: vt,
    d(i) {
      i && Ze(e);
    }
  };
}
function mc(t) {
  let e, n, i, l;
  function o(r) {
    t[17](r);
  }
  let s = {
    filetype: "image/*",
    disable_click: !!/*value*/
    t[0]?.[0],
    root: (
      /*root*/
      t[4]
    ),
    file_count: "multiple",
    $$slots: { default: [gc] },
    $$scope: { ctx: t }
  };
  return (
    /*dragging*/
    t[8] !== void 0 && (s.dragging = /*dragging*/
    t[8]), n = new Ql({ props: s }), _i.push(() => ci(n, "dragging", o)), n.$on(
      "load",
      /*load_handler*/
      t[18]
    ), {
      c() {
        e = ut("div"), Pe(n.$$.fragment), oe(e, "class", "wrap svelte-106mu0e"), Oe(
          e,
          "half-wrap",
          /*upload_count*/
          t[5] === 1
        );
      },
      m(r, a) {
        Qe(r, e, a), Re(n, e, null), l = !0;
      },
      p(r, a) {
        const u = {};
        a & /*value*/
        1 && (u.disable_click = !!/*value*/
        r[0]?.[0]), a & /*root*/
        16 && (u.root = /*root*/
        r[4]), a & /*$$scope*/
        8388608 && (u.$$scope = { dirty: a, ctx: r }), !i && a & /*dragging*/
        256 && (i = !0, u.dragging = /*dragging*/
        r[8], fi(() => i = !1)), n.$set(u), (!l || a & /*upload_count*/
        32) && Oe(
          e,
          "half-wrap",
          /*upload_count*/
          r[5] === 1
        );
      },
      i(r) {
        l || (G(n.$$.fragment, r), l = !0);
      },
      o(r) {
        Z(n.$$.fragment, r), l = !1;
      },
      d(r) {
        r && Ze(e), Me(n);
      }
    }
  );
}
function gc(t) {
  let e;
  const n = (
    /*#slots*/
    t[15].default
  ), i = lo(
    n,
    t,
    /*$$scope*/
    t[23],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(l, o) {
      i && i.m(l, o), e = !0;
    },
    p(l, o) {
      i && i.p && (!e || o & /*$$scope*/
      8388608) && ro(
        i,
        n,
        l,
        /*$$scope*/
        l[23],
        e ? so(
          n,
          /*$$scope*/
          l[23],
          o,
          null
        ) : oo(
          /*$$scope*/
          l[23]
        ),
        null
      );
    },
    i(l) {
      e || (G(i, l), e = !0);
    },
    o(l) {
      Z(i, l), e = !1;
    },
    d(l) {
      i && i.d(l);
    }
  };
}
function pc(t) {
  let e, n;
  return {
    c() {
      e = ut("img"), fn(e.src, n = /*value_*/
      t[9][1].url) || oe(e, "src", n), oe(e, "alt", ""), oe(
        e,
        "style",
        /*style*/
        t[11]
      ), oe(e, "class", "svelte-106mu0e"), Oe(
        e,
        "fixed",
        /*upload_count*/
        t[5] === 1
      );
    },
    m(i, l) {
      Qe(i, e, l);
    },
    p(i, l) {
      l & /*value_*/
      512 && !fn(e.src, n = /*value_*/
      i[9][1].url) && oe(e, "src", n), l & /*style*/
      2048 && oe(
        e,
        "style",
        /*style*/
        i[11]
      ), l & /*upload_count*/
      32 && Oe(
        e,
        "fixed",
        /*upload_count*/
        i[5] === 1
      );
    },
    i: vt,
    o: vt,
    d(i) {
      i && Ze(e);
    }
  };
}
function bc(t) {
  let e, n, i = `${/*el_width*/
  t[10] * (1 - /*position*/
  t[1])}px`, l = `translateX(${/*el_width*/
  t[10] * /*position*/
  t[1]}px)`, o;
  return n = new Xl({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [vc] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      e = ut("div"), Pe(n.$$.fragment), oe(e, "class", "empty-wrap fixed svelte-106mu0e"), Oe(e, "white-icon", !/*value*/
      t[0]?.[0]?.url), mt(e, "width", i), mt(e, "transform", l);
    },
    m(s, r) {
      Qe(s, e, r), Re(n, e, null), o = !0;
    },
    p(s, r) {
      const a = {};
      r & /*$$scope*/
      8388608 && (a.$$scope = { dirty: r, ctx: s }), n.$set(a), (!o || r & /*value*/
      1) && Oe(e, "white-icon", !/*value*/
      s[0]?.[0]?.url), r & /*el_width, position*/
      1026 && i !== (i = `${/*el_width*/
      s[10] * (1 - /*position*/
      s[1])}px`) && mt(e, "width", i), r & /*el_width, position*/
      1026 && l !== (l = `translateX(${/*el_width*/
      s[10] * /*position*/
      s[1]}px)`) && mt(e, "transform", l);
    },
    i(s) {
      o || (G(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Z(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && Ze(e), Me(n);
    }
  };
}
function wc(t) {
  let e, n, i;
  function l(s) {
    t[19](s);
  }
  let o = {
    filetype: "image/*",
    disable_click: !!/*value*/
    t[0]?.[1],
    root: (
      /*root*/
      t[4]
    ),
    file_count: "multiple",
    $$slots: { default: [yc] },
    $$scope: { ctx: t }
  };
  return (
    /*dragging*/
    t[8] !== void 0 && (o.dragging = /*dragging*/
    t[8]), e = new Ql({ props: o }), _i.push(() => ci(e, "dragging", l)), e.$on(
      "load",
      /*load_handler_1*/
      t[20]
    ), {
      c() {
        Pe(e.$$.fragment);
      },
      m(s, r) {
        Re(e, s, r), i = !0;
      },
      p(s, r) {
        const a = {};
        r & /*value*/
        1 && (a.disable_click = !!/*value*/
        s[0]?.[1]), r & /*root*/
        16 && (a.root = /*root*/
        s[4]), r & /*$$scope*/
        8388608 && (a.$$scope = { dirty: r, ctx: s }), !n && r & /*dragging*/
        256 && (n = !0, a.dragging = /*dragging*/
        s[8], fi(() => n = !1)), e.$set(a);
      },
      i(s) {
        i || (G(e.$$.fragment, s), i = !0);
      },
      o(s) {
        Z(e.$$.fragment, s), i = !1;
      },
      d(s) {
        Me(e, s);
      }
    }
  );
}
function vc(t) {
  let e, n;
  return e = new yn({}), {
    c() {
      Pe(e.$$.fragment);
    },
    m(i, l) {
      Re(e, i, l), n = !0;
    },
    i(i) {
      n || (G(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Z(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Me(e, i);
    }
  };
}
function yc(t) {
  let e;
  const n = (
    /*#slots*/
    t[15].default
  ), i = lo(
    n,
    t,
    /*$$scope*/
    t[23],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(l, o) {
      i && i.m(l, o), e = !0;
    },
    p(l, o) {
      i && i.p && (!e || o & /*$$scope*/
      8388608) && ro(
        i,
        n,
        l,
        /*$$scope*/
        l[23],
        e ? so(
          n,
          /*$$scope*/
          l[23],
          o,
          null
        ) : oo(
          /*$$scope*/
          l[23]
        ),
        null
      );
    },
    i(l) {
      e || (G(i, l), e = !0);
    },
    o(l) {
      Z(i, l), e = !1;
    },
    d(l) {
      i && i.d(l);
    }
  };
}
function kc(t) {
  let e, n, i, l, o, s, r;
  const a = [mc, hc], u = [];
  function f(h, k) {
    return (
      /*value_*/
      h[9]?.[0] ? 1 : 0
    );
  }
  n = f(t), i = u[n] = a[n](t);
  const c = [wc, bc, pc], _ = [];
  function d(h, k) {
    return !/*value_*/
    h[9]?.[1] && /*upload_count*/
    h[5] === 2 ? 0 : !/*value_*/
    h[9]?.[1] && /*upload_count*/
    h[5] === 1 ? 1 : 2;
  }
  return o = d(t), s = _[o] = c[o](t), {
    c() {
      e = ut("div"), i.c(), l = tn(), s.c(), oe(e, "class", "upload-wrap svelte-106mu0e"), Oe(
        e,
        "side-by-side",
        /*upload_count*/
        t[5] === 2
      ), mt(
        e,
        "display",
        /*upload_count*/
        t[5] === 2 ? "flex" : "block"
      );
    },
    m(h, k) {
      Qe(h, e, k), u[n].m(e, null), ei(e, l), _[o].m(e, null), r = !0;
    },
    p(h, k) {
      let y = n;
      n = f(h), n === y ? u[n].p(h, k) : (It(), Z(u[y], 1, 1, () => {
        u[y] = null;
      }), Ot(), i = u[n], i ? i.p(h, k) : (i = u[n] = a[n](h), i.c()), G(i, 1), i.m(e, l));
      let p = o;
      o = d(h), o === p ? _[o].p(h, k) : (It(), Z(_[p], 1, 1, () => {
        _[p] = null;
      }), Ot(), s = _[o], s ? s.p(h, k) : (s = _[o] = c[o](h), s.c()), G(s, 1), s.m(e, null)), (!r || k & /*upload_count*/
      32) && Oe(
        e,
        "side-by-side",
        /*upload_count*/
        h[5] === 2
      ), k & /*upload_count*/
      32 && mt(
        e,
        "display",
        /*upload_count*/
        h[5] === 2 ? "flex" : "block"
      );
    },
    i(h) {
      r || (G(i), G(s), r = !0);
    },
    o(h) {
      Z(i), Z(s), r = !1;
    },
    d(h) {
      h && Ze(e), u[n].d(), _[o].d();
    }
  };
}
function Sc(t) {
  let e, n, i, l, o, s, r, a, u;
  e = new jl({
    props: {
      show_label: (
        /*show_label*/
        t[3]
      ),
      Icon: yn,
      label: (
        /*label*/
        t[2] || "Image"
      )
    }
  });
  let f = (
    /*value*/
    (t[0]?.[0]?.url || /*value*/
    t[0]?.[1]?.url) && Ji(t)
  ), c = (
    /*value*/
    t[0]?.[1]?.url && Yi(t)
  );
  function _(h) {
    t[21](h);
  }
  let d = {
    disabled: (
      /*upload_count*/
      t[5] == 2 || !/*value*/
      t[0]?.[0]
    ),
    slider_color: (
      /*slider_color*/
      t[7]
    ),
    $$slots: { default: [kc] },
    $$scope: { ctx: t }
  };
  return (
    /*position*/
    t[1] !== void 0 && (d.position = /*position*/
    t[1]), s = new Pl({ props: d }), _i.push(() => ci(s, "position", _)), {
      c() {
        Pe(e.$$.fragment), n = tn(), i = ut("div"), f && f.c(), l = tn(), c && c.c(), o = tn(), Pe(s.$$.fragment), oe(i, "data-testid", "image"), oe(i, "class", "image-container svelte-106mu0e"), ac(() => (
          /*div_elementresize_handler*/
          t[22].call(i)
        ));
      },
      m(h, k) {
        Re(e, h, k), Qe(h, n, k), Qe(h, i, k), f && f.m(i, null), ei(i, l), c && c.m(i, null), ei(i, o), Re(s, i, null), a = rc(
          i,
          /*div_elementresize_handler*/
          t[22].bind(i)
        ), u = !0;
      },
      p(h, [k]) {
        const y = {};
        k & /*show_label*/
        8 && (y.show_label = /*show_label*/
        h[3]), k & /*label*/
        4 && (y.label = /*label*/
        h[2] || "Image"), e.$set(y), /*value*/
        h[0]?.[0]?.url || /*value*/
        h[0]?.[1]?.url ? f ? (f.p(h, k), k & /*value*/
        1 && G(f, 1)) : (f = Ji(h), f.c(), G(f, 1), f.m(i, l)) : f && (It(), Z(f, 1, 1, () => {
          f = null;
        }), Ot()), /*value*/
        h[0]?.[1]?.url ? c ? (c.p(h, k), k & /*value*/
        1 && G(c, 1)) : (c = Yi(h), c.c(), G(c, 1), c.m(i, o)) : c && (It(), Z(c, 1, 1, () => {
          c = null;
        }), Ot());
        const p = {};
        k & /*upload_count, value*/
        33 && (p.disabled = /*upload_count*/
        h[5] == 2 || !/*value*/
        h[0]?.[0]), k & /*slider_color*/
        128 && (p.slider_color = /*slider_color*/
        h[7]), k & /*$$scope, upload_count, value, root, dragging, value_, el_width, position, style*/
        8392499 && (p.$$scope = { dirty: k, ctx: h }), !r && k & /*position*/
        2 && (r = !0, p.position = /*position*/
        h[1], fi(() => r = !1)), s.$set(p);
      },
      i(h) {
        u || (G(e.$$.fragment, h), G(f), G(c), G(s.$$.fragment, h), u = !0);
      },
      o(h) {
        Z(e.$$.fragment, h), Z(f), Z(c), Z(s.$$.fragment, h), u = !1;
      },
      d(h) {
        h && (Ze(n), Ze(i)), Me(e, h), f && f.d(), c && c.d(), Me(s), a();
      }
    }
  );
}
function qc(t, e, n) {
  let i, { $$slots: l = {}, $$scope: o } = e;
  var s = this && this.__awaiter || function(L, Y, C, w) {
    function V(T) {
      return T instanceof C ? T : new C(function(N) {
        N(T);
      });
    }
    return new (C || (C = Promise))(function(T, N) {
      function U(I) {
        try {
          q(w.next(I));
        } catch (S) {
          N(S);
        }
      }
      function O(I) {
        try {
          q(w.throw(I));
        } catch (S) {
          N(S);
        }
      }
      function q(I) {
        I.done ? T(I.value) : V(I.value).then(U, O);
      }
      q((w = w.apply(L, Y || [])).next());
    });
  };
  let { value: r } = e, { label: a = void 0 } = e, { show_label: u } = e, { root: f } = e, { position: c } = e, { upload_count: _ = 2 } = e, { show_download_button: d = !0 } = e, { slider_color: h } = e, k = r || [null, null];
  function y(L, Y) {
    return s(this, arguments, void 0, function* ({ detail: C }, w) {
      C.length > 1 ? (n(0, r[0] = Ee(C[0], f, null), r), n(0, r[1] = Ee(C[1], f, null), r)) : n(0, r[w] = Ee(C[0], f, null), r), yield _c(), v("upload", r);
    });
  }
  let p = "";
  const v = cc();
  let b = !1, m;
  const g = () => {
    n(1, c = 0.5), n(0, r = [null, null]), v("clear");
  };
  function A(L) {
    b = L, n(8, b);
  }
  const E = (L) => y(L, 0);
  function z(L) {
    b = L, n(8, b);
  }
  const P = (L) => y(L, 1);
  function R(L) {
    c = L, n(1, c);
  }
  function j() {
    m = this.clientWidth, n(10, m);
  }
  return t.$$set = (L) => {
    "value" in L && n(0, r = L.value), "label" in L && n(2, a = L.label), "show_label" in L && n(3, u = L.show_label), "root" in L && n(4, f = L.root), "position" in L && n(1, c = L.position), "upload_count" in L && n(5, _ = L.upload_count), "show_download_button" in L && n(6, d = L.show_download_button), "slider_color" in L && n(7, h = L.slider_color), "$$scope" in L && n(23, o = L.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*value, old_value*/
    16385 && JSON.stringify(r) !== p && (n(14, p = JSON.stringify(r)), n(9, k = r)), t.$$.dirty & /*dragging*/
    256 && v("drag", b), t.$$.dirty & /*upload_count, position*/
    34 && n(11, i = _ === 1 ? `clip-path: inset(0 0 0 ${c * 100}%)` : "");
  }, [
    r,
    c,
    a,
    u,
    f,
    _,
    d,
    h,
    b,
    k,
    m,
    i,
    y,
    v,
    p,
    l,
    g,
    A,
    E,
    z,
    P,
    R,
    j,
    o
  ];
}
class Cc extends sc {
  constructor(e) {
    super(), uc(this, e, qc, Sc, fc, {
      value: 0,
      label: 2,
      show_label: 3,
      root: 4,
      position: 1,
      upload_count: 5,
      show_download_button: 6,
      slider_color: 7
    });
  }
}
function gt(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; t > 1e3 && n < e.length - 1; )
    t /= 1e3, n++;
  let i = e[n];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + i;
}
function nn() {
}
function Ec(t, e) {
  return t != t ? e == e : t !== e || t && typeof t == "object" || typeof t == "function";
}
const ao = typeof window < "u";
let Hi = ao ? () => window.performance.now() : () => Date.now(), uo = ao ? (t) => requestAnimationFrame(t) : nn;
const wt = /* @__PURE__ */ new Set();
function fo(t) {
  wt.forEach((e) => {
    e.c(t) || (wt.delete(e), e.f());
  }), wt.size !== 0 && uo(fo);
}
function Nc(t) {
  let e;
  return wt.size === 0 && uo(fo), {
    promise: new Promise((n) => {
      wt.add(e = { c: t, f: n });
    }),
    abort() {
      wt.delete(e);
    }
  };
}
const dt = [];
function Ac(t, e = nn) {
  let n;
  const i = /* @__PURE__ */ new Set();
  function l(r) {
    if (Ec(t, r) && (t = r, n)) {
      const a = !dt.length;
      for (const u of i)
        u[1](), dt.push(u, t);
      if (a) {
        for (let u = 0; u < dt.length; u += 2)
          dt[u][0](dt[u + 1]);
        dt.length = 0;
      }
    }
  }
  function o(r) {
    l(r(t));
  }
  function s(r, a = nn) {
    const u = [r, a];
    return i.add(u), i.size === 1 && (n = e(l, o) || nn), r(t), () => {
      i.delete(u), i.size === 0 && n && (n(), n = null);
    };
  }
  return { set: l, update: o, subscribe: s };
}
function Zi(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function ti(t, e, n, i) {
  if (typeof n == "number" || Zi(n)) {
    const l = i - n, o = (n - e) / (t.dt || 1 / 60), s = t.opts.stiffness * l, r = t.opts.damping * o, a = (s - r) * t.inv_mass, u = (o + a) * t.dt;
    return Math.abs(u) < t.opts.precision && Math.abs(l) < t.opts.precision ? i : (t.settled = !1, Zi(n) ? new Date(n.getTime() + u) : n + u);
  } else {
    if (Array.isArray(n))
      return n.map(
        (l, o) => ti(t, e[o], n[o], i[o])
      );
    if (typeof n == "object") {
      const l = {};
      for (const o in n)
        l[o] = ti(t, e[o], n[o], i[o]);
      return l;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function Qi(t, e = {}) {
  const n = Ac(t), { stiffness: i = 0.15, damping: l = 0.8, precision: o = 0.01 } = e;
  let s, r, a, u = t, f = t, c = 1, _ = 0, d = !1;
  function h(y, p = {}) {
    f = y;
    const v = a = {};
    return t == null || p.hard || k.stiffness >= 1 && k.damping >= 1 ? (d = !0, s = Hi(), u = y, n.set(t = f), Promise.resolve()) : (p.soft && (_ = 1 / ((p.soft === !0 ? 0.5 : +p.soft) * 60), c = 0), r || (s = Hi(), d = !1, r = Nc((b) => {
      if (d)
        return d = !1, r = null, !1;
      c = Math.min(c + _, 1);
      const m = {
        inv_mass: c,
        opts: k,
        settled: !0,
        dt: (b - s) * 60 / 1e3
      }, g = ti(m, u, t, f);
      return s = b, u = t, n.set(t = g), m.settled && (r = null), !m.settled;
    })), new Promise((b) => {
      r.promise.then(() => {
        v === a && b();
      });
    }));
  }
  const k = {
    set: h,
    update: (y, p) => h(y(f, t), p),
    subscribe: n.subscribe,
    stiffness: i,
    damping: l,
    precision: o
  };
  return k;
}
const {
  SvelteComponent: zc,
  append: qe,
  attr: B,
  component_subscribe: $i,
  detach: Lc,
  element: Dc,
  init: Fc,
  insert: Oc,
  noop: xi,
  safe_not_equal: Ic,
  set_style: Gt,
  svg_element: Ce,
  toggle_class: el
} = window.__gradio__svelte__internal, { onMount: Tc } = window.__gradio__svelte__internal;
function Bc(t) {
  let e, n, i, l, o, s, r, a, u, f, c, _;
  return {
    c() {
      e = Dc("div"), n = Ce("svg"), i = Ce("g"), l = Ce("path"), o = Ce("path"), s = Ce("path"), r = Ce("path"), a = Ce("g"), u = Ce("path"), f = Ce("path"), c = Ce("path"), _ = Ce("path"), B(l, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), B(l, "fill", "#FF7C00"), B(l, "fill-opacity", "0.4"), B(l, "class", "svelte-43sxxs"), B(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), B(o, "fill", "#FF7C00"), B(o, "class", "svelte-43sxxs"), B(s, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), B(s, "fill", "#FF7C00"), B(s, "fill-opacity", "0.4"), B(s, "class", "svelte-43sxxs"), B(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), B(r, "fill", "#FF7C00"), B(r, "class", "svelte-43sxxs"), Gt(i, "transform", "translate(" + /*$top*/
      t[1][0] + "px, " + /*$top*/
      t[1][1] + "px)"), B(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), B(u, "fill", "#FF7C00"), B(u, "fill-opacity", "0.4"), B(u, "class", "svelte-43sxxs"), B(f, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), B(f, "fill", "#FF7C00"), B(f, "class", "svelte-43sxxs"), B(c, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), B(c, "fill", "#FF7C00"), B(c, "fill-opacity", "0.4"), B(c, "class", "svelte-43sxxs"), B(_, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), B(_, "fill", "#FF7C00"), B(_, "class", "svelte-43sxxs"), Gt(a, "transform", "translate(" + /*$bottom*/
      t[2][0] + "px, " + /*$bottom*/
      t[2][1] + "px)"), B(n, "viewBox", "-1200 -1200 3000 3000"), B(n, "fill", "none"), B(n, "xmlns", "http://www.w3.org/2000/svg"), B(n, "class", "svelte-43sxxs"), B(e, "class", "svelte-43sxxs"), el(
        e,
        "margin",
        /*margin*/
        t[0]
      );
    },
    m(d, h) {
      Oc(d, e, h), qe(e, n), qe(n, i), qe(i, l), qe(i, o), qe(i, s), qe(i, r), qe(n, a), qe(a, u), qe(a, f), qe(a, c), qe(a, _);
    },
    p(d, [h]) {
      h & /*$top*/
      2 && Gt(i, "transform", "translate(" + /*$top*/
      d[1][0] + "px, " + /*$top*/
      d[1][1] + "px)"), h & /*$bottom*/
      4 && Gt(a, "transform", "translate(" + /*$bottom*/
      d[2][0] + "px, " + /*$bottom*/
      d[2][1] + "px)"), h & /*margin*/
      1 && el(
        e,
        "margin",
        /*margin*/
        d[0]
      );
    },
    i: xi,
    o: xi,
    d(d) {
      d && Lc(e);
    }
  };
}
function Pc(t, e, n) {
  let i, l;
  var o = this && this.__awaiter || function(d, h, k, y) {
    function p(v) {
      return v instanceof k ? v : new k(function(b) {
        b(v);
      });
    }
    return new (k || (k = Promise))(function(v, b) {
      function m(E) {
        try {
          A(y.next(E));
        } catch (z) {
          b(z);
        }
      }
      function g(E) {
        try {
          A(y.throw(E));
        } catch (z) {
          b(z);
        }
      }
      function A(E) {
        E.done ? v(E.value) : p(E.value).then(m, g);
      }
      A((y = y.apply(d, h || [])).next());
    });
  };
  let { margin: s = !0 } = e;
  const r = Qi([0, 0]);
  $i(t, r, (d) => n(1, i = d));
  const a = Qi([0, 0]);
  $i(t, a, (d) => n(2, l = d));
  let u;
  function f() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), a.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), a.set([125, -140])]), yield Promise.all([r.set([-125, 0]), a.set([125, -0])]), yield Promise.all([r.set([125, 0]), a.set([-125, 0])]);
    });
  }
  function c() {
    return o(this, void 0, void 0, function* () {
      yield f(), u || c();
    });
  }
  function _() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), a.set([-125, 0])]), c();
    });
  }
  return Tc(() => (_(), () => u = !0)), t.$$set = (d) => {
    "margin" in d && n(0, s = d.margin);
  }, [s, i, l, r, a];
}
class Mc extends zc {
  constructor(e) {
    super(), Fc(this, e, Pc, Bc, Ic, { margin: 0 });
  }
}
const {
  SvelteComponent: Rc,
  append: ot,
  attr: Le,
  binding_callbacks: tl,
  check_outros: co,
  create_component: Uc,
  create_slot: jc,
  destroy_component: Vc,
  destroy_each: _o,
  detach: D,
  element: Be,
  empty: St,
  ensure_array_like: cn,
  get_all_dirty_from_scope: Wc,
  get_slot_changes: Xc,
  group_outros: ho,
  init: Gc,
  insert: F,
  mount_component: Jc,
  noop: ni,
  safe_not_equal: Yc,
  set_data: we,
  set_style: Ye,
  space: De,
  text: J,
  toggle_class: pe,
  transition_in: yt,
  transition_out: kt,
  update_slot_base: Kc
} = window.__gradio__svelte__internal, { tick: Hc } = window.__gradio__svelte__internal, { onDestroy: Zc } = window.__gradio__svelte__internal, Qc = (t) => ({}), nl = (t) => ({});
function il(t, e, n) {
  const i = t.slice();
  return i[39] = e[n], i[41] = n, i;
}
function ll(t, e, n) {
  const i = t.slice();
  return i[39] = e[n], i;
}
function $c(t) {
  let e, n = (
    /*i18n*/
    t[1]("common.error") + ""
  ), i, l, o;
  const s = (
    /*#slots*/
    t[29].error
  ), r = jc(
    s,
    t,
    /*$$scope*/
    t[28],
    nl
  );
  return {
    c() {
      e = Be("span"), i = J(n), l = De(), r && r.c(), Le(e, "class", "error svelte-1txqlrd");
    },
    m(a, u) {
      F(a, e, u), ot(e, i), F(a, l, u), r && r.m(a, u), o = !0;
    },
    p(a, u) {
      (!o || u[0] & /*i18n*/
      2) && n !== (n = /*i18n*/
      a[1]("common.error") + "") && we(i, n), r && r.p && (!o || u[0] & /*$$scope*/
      268435456) && Kc(
        r,
        s,
        a,
        /*$$scope*/
        a[28],
        o ? Xc(
          s,
          /*$$scope*/
          a[28],
          u,
          Qc
        ) : Wc(
          /*$$scope*/
          a[28]
        ),
        nl
      );
    },
    i(a) {
      o || (yt(r, a), o = !0);
    },
    o(a) {
      kt(r, a), o = !1;
    },
    d(a) {
      a && (D(e), D(l)), r && r.d(a);
    }
  };
}
function xc(t) {
  let e, n, i, l, o, s, r, a, u, f = (
    /*variant*/
    t[8] === "default" && /*show_eta_bar*/
    t[18] && /*show_progress*/
    t[6] === "full" && ol(t)
  );
  function c(b, m) {
    if (
      /*progress*/
      b[7]
    ) return n_;
    if (
      /*queue_position*/
      b[2] !== null && /*queue_size*/
      b[3] !== void 0 && /*queue_position*/
      b[2] >= 0
    ) return t_;
    if (
      /*queue_position*/
      b[2] === 0
    ) return e_;
  }
  let _ = c(t), d = _ && _(t), h = (
    /*timer*/
    t[5] && al(t)
  );
  const k = [s_, o_], y = [];
  function p(b, m) {
    return (
      /*last_progress_level*/
      b[15] != null ? 0 : (
        /*show_progress*/
        b[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = p(t)) && (s = y[o] = k[o](t));
  let v = !/*timer*/
  t[5] && ml(t);
  return {
    c() {
      f && f.c(), e = De(), n = Be("div"), d && d.c(), i = De(), h && h.c(), l = De(), s && s.c(), r = De(), v && v.c(), a = St(), Le(n, "class", "progress-text svelte-1txqlrd"), pe(
        n,
        "meta-text-center",
        /*variant*/
        t[8] === "center"
      ), pe(
        n,
        "meta-text",
        /*variant*/
        t[8] === "default"
      );
    },
    m(b, m) {
      f && f.m(b, m), F(b, e, m), F(b, n, m), d && d.m(n, null), ot(n, i), h && h.m(n, null), F(b, l, m), ~o && y[o].m(b, m), F(b, r, m), v && v.m(b, m), F(b, a, m), u = !0;
    },
    p(b, m) {
      /*variant*/
      b[8] === "default" && /*show_eta_bar*/
      b[18] && /*show_progress*/
      b[6] === "full" ? f ? f.p(b, m) : (f = ol(b), f.c(), f.m(e.parentNode, e)) : f && (f.d(1), f = null), _ === (_ = c(b)) && d ? d.p(b, m) : (d && d.d(1), d = _ && _(b), d && (d.c(), d.m(n, i))), /*timer*/
      b[5] ? h ? h.p(b, m) : (h = al(b), h.c(), h.m(n, null)) : h && (h.d(1), h = null), (!u || m[0] & /*variant*/
      256) && pe(
        n,
        "meta-text-center",
        /*variant*/
        b[8] === "center"
      ), (!u || m[0] & /*variant*/
      256) && pe(
        n,
        "meta-text",
        /*variant*/
        b[8] === "default"
      );
      let g = o;
      o = p(b), o === g ? ~o && y[o].p(b, m) : (s && (ho(), kt(y[g], 1, 1, () => {
        y[g] = null;
      }), co()), ~o ? (s = y[o], s ? s.p(b, m) : (s = y[o] = k[o](b), s.c()), yt(s, 1), s.m(r.parentNode, r)) : s = null), /*timer*/
      b[5] ? v && (v.d(1), v = null) : v ? v.p(b, m) : (v = ml(b), v.c(), v.m(a.parentNode, a));
    },
    i(b) {
      u || (yt(s), u = !0);
    },
    o(b) {
      kt(s), u = !1;
    },
    d(b) {
      b && (D(e), D(n), D(l), D(r), D(a)), f && f.d(b), d && d.d(), h && h.d(), ~o && y[o].d(b), v && v.d(b);
    }
  };
}
function ol(t) {
  let e, n = `translateX(${/*eta_level*/
  (t[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Be("div"), Le(e, "class", "eta-bar svelte-1txqlrd"), Ye(e, "transform", n);
    },
    m(i, l) {
      F(i, e, l);
    },
    p(i, l) {
      l[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (i[17] || 0) * 100 - 100}%)`) && Ye(e, "transform", n);
    },
    d(i) {
      i && D(e);
    }
  };
}
function e_(t) {
  let e;
  return {
    c() {
      e = J("processing |");
    },
    m(n, i) {
      F(n, e, i);
    },
    p: ni,
    d(n) {
      n && D(e);
    }
  };
}
function t_(t) {
  let e, n = (
    /*queue_position*/
    t[2] + 1 + ""
  ), i, l, o, s;
  return {
    c() {
      e = J("queue: "), i = J(n), l = J("/"), o = J(
        /*queue_size*/
        t[3]
      ), s = J(" |");
    },
    m(r, a) {
      F(r, e, a), F(r, i, a), F(r, l, a), F(r, o, a), F(r, s, a);
    },
    p(r, a) {
      a[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      r[2] + 1 + "") && we(i, n), a[0] & /*queue_size*/
      8 && we(
        o,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (D(e), D(i), D(l), D(o), D(s));
    }
  };
}
function n_(t) {
  let e, n = cn(
    /*progress*/
    t[7]
  ), i = [];
  for (let l = 0; l < n.length; l += 1)
    i[l] = rl(ll(t, n, l));
  return {
    c() {
      for (let l = 0; l < i.length; l += 1)
        i[l].c();
      e = St();
    },
    m(l, o) {
      for (let s = 0; s < i.length; s += 1)
        i[s] && i[s].m(l, o);
      F(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*progress*/
      128) {
        n = cn(
          /*progress*/
          l[7]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const r = ll(l, n, s);
          i[s] ? i[s].p(r, o) : (i[s] = rl(r), i[s].c(), i[s].m(e.parentNode, e));
        }
        for (; s < i.length; s += 1)
          i[s].d(1);
        i.length = n.length;
      }
    },
    d(l) {
      l && D(e), _o(i, l);
    }
  };
}
function sl(t) {
  let e, n = (
    /*p*/
    t[39].unit + ""
  ), i, l, o = " ", s;
  function r(f, c) {
    return (
      /*p*/
      f[39].length != null ? l_ : i_
    );
  }
  let a = r(t), u = a(t);
  return {
    c() {
      u.c(), e = De(), i = J(n), l = J(" | "), s = J(o);
    },
    m(f, c) {
      u.m(f, c), F(f, e, c), F(f, i, c), F(f, l, c), F(f, s, c);
    },
    p(f, c) {
      a === (a = r(f)) && u ? u.p(f, c) : (u.d(1), u = a(f), u && (u.c(), u.m(e.parentNode, e))), c[0] & /*progress*/
      128 && n !== (n = /*p*/
      f[39].unit + "") && we(i, n);
    },
    d(f) {
      f && (D(e), D(i), D(l), D(s)), u.d(f);
    }
  };
}
function i_(t) {
  let e = gt(
    /*p*/
    t[39].index || 0
  ) + "", n;
  return {
    c() {
      n = J(e);
    },
    m(i, l) {
      F(i, n, l);
    },
    p(i, l) {
      l[0] & /*progress*/
      128 && e !== (e = gt(
        /*p*/
        i[39].index || 0
      ) + "") && we(n, e);
    },
    d(i) {
      i && D(n);
    }
  };
}
function l_(t) {
  let e = gt(
    /*p*/
    t[39].index || 0
  ) + "", n, i, l = gt(
    /*p*/
    t[39].length
  ) + "", o;
  return {
    c() {
      n = J(e), i = J("/"), o = J(l);
    },
    m(s, r) {
      F(s, n, r), F(s, i, r), F(s, o, r);
    },
    p(s, r) {
      r[0] & /*progress*/
      128 && e !== (e = gt(
        /*p*/
        s[39].index || 0
      ) + "") && we(n, e), r[0] & /*progress*/
      128 && l !== (l = gt(
        /*p*/
        s[39].length
      ) + "") && we(o, l);
    },
    d(s) {
      s && (D(n), D(i), D(o));
    }
  };
}
function rl(t) {
  let e, n = (
    /*p*/
    t[39].index != null && sl(t)
  );
  return {
    c() {
      n && n.c(), e = St();
    },
    m(i, l) {
      n && n.m(i, l), F(i, e, l);
    },
    p(i, l) {
      /*p*/
      i[39].index != null ? n ? n.p(i, l) : (n = sl(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && D(e), n && n.d(i);
    }
  };
}
function al(t) {
  let e, n = (
    /*eta*/
    t[0] ? `/${/*formatted_eta*/
    t[19]}` : ""
  ), i, l;
  return {
    c() {
      e = J(
        /*formatted_timer*/
        t[20]
      ), i = J(n), l = J("s");
    },
    m(o, s) {
      F(o, e, s), F(o, i, s), F(o, l, s);
    },
    p(o, s) {
      s[0] & /*formatted_timer*/
      1048576 && we(
        e,
        /*formatted_timer*/
        o[20]
      ), s[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && we(i, n);
    },
    d(o) {
      o && (D(e), D(i), D(l));
    }
  };
}
function o_(t) {
  let e, n;
  return e = new Mc({
    props: { margin: (
      /*variant*/
      t[8] === "default"
    ) }
  }), {
    c() {
      Uc(e.$$.fragment);
    },
    m(i, l) {
      Jc(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l[0] & /*variant*/
      256 && (o.margin = /*variant*/
      i[8] === "default"), e.$set(o);
    },
    i(i) {
      n || (yt(e.$$.fragment, i), n = !0);
    },
    o(i) {
      kt(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Vc(e, i);
    }
  };
}
function s_(t) {
  let e, n, i, l, o, s = `${/*last_progress_level*/
  t[15] * 100}%`, r = (
    /*progress*/
    t[7] != null && ul(t)
  );
  return {
    c() {
      e = Be("div"), n = Be("div"), r && r.c(), i = De(), l = Be("div"), o = Be("div"), Le(n, "class", "progress-level-inner svelte-1txqlrd"), Le(o, "class", "progress-bar svelte-1txqlrd"), Ye(o, "width", s), Le(l, "class", "progress-bar-wrap svelte-1txqlrd"), Le(e, "class", "progress-level svelte-1txqlrd");
    },
    m(a, u) {
      F(a, e, u), ot(e, n), r && r.m(n, null), ot(e, i), ot(e, l), ot(l, o), t[30](o);
    },
    p(a, u) {
      /*progress*/
      a[7] != null ? r ? r.p(a, u) : (r = ul(a), r.c(), r.m(n, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && s !== (s = `${/*last_progress_level*/
      a[15] * 100}%`) && Ye(o, "width", s);
    },
    i: ni,
    o: ni,
    d(a) {
      a && D(e), r && r.d(), t[30](null);
    }
  };
}
function ul(t) {
  let e, n = cn(
    /*progress*/
    t[7]
  ), i = [];
  for (let l = 0; l < n.length; l += 1)
    i[l] = hl(il(t, n, l));
  return {
    c() {
      for (let l = 0; l < i.length; l += 1)
        i[l].c();
      e = St();
    },
    m(l, o) {
      for (let s = 0; s < i.length; s += 1)
        i[s] && i[s].m(l, o);
      F(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        n = cn(
          /*progress*/
          l[7]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const r = il(l, n, s);
          i[s] ? i[s].p(r, o) : (i[s] = hl(r), i[s].c(), i[s].m(e.parentNode, e));
        }
        for (; s < i.length; s += 1)
          i[s].d(1);
        i.length = n.length;
      }
    },
    d(l) {
      l && D(e), _o(i, l);
    }
  };
}
function fl(t) {
  let e, n, i, l, o = (
    /*i*/
    t[41] !== 0 && r_()
  ), s = (
    /*p*/
    t[39].desc != null && cl(t)
  ), r = (
    /*p*/
    t[39].desc != null && /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[41]
    ] != null && _l()
  ), a = (
    /*progress_level*/
    t[14] != null && dl(t)
  );
  return {
    c() {
      o && o.c(), e = De(), s && s.c(), n = De(), r && r.c(), i = De(), a && a.c(), l = St();
    },
    m(u, f) {
      o && o.m(u, f), F(u, e, f), s && s.m(u, f), F(u, n, f), r && r.m(u, f), F(u, i, f), a && a.m(u, f), F(u, l, f);
    },
    p(u, f) {
      /*p*/
      u[39].desc != null ? s ? s.p(u, f) : (s = cl(u), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*p*/
      u[39].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[41]
      ] != null ? r || (r = _l(), r.c(), r.m(i.parentNode, i)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? a ? a.p(u, f) : (a = dl(u), a.c(), a.m(l.parentNode, l)) : a && (a.d(1), a = null);
    },
    d(u) {
      u && (D(e), D(n), D(i), D(l)), o && o.d(u), s && s.d(u), r && r.d(u), a && a.d(u);
    }
  };
}
function r_(t) {
  let e;
  return {
    c() {
      e = J(" /");
    },
    m(n, i) {
      F(n, e, i);
    },
    d(n) {
      n && D(e);
    }
  };
}
function cl(t) {
  let e = (
    /*p*/
    t[39].desc + ""
  ), n;
  return {
    c() {
      n = J(e);
    },
    m(i, l) {
      F(i, n, l);
    },
    p(i, l) {
      l[0] & /*progress*/
      128 && e !== (e = /*p*/
      i[39].desc + "") && we(n, e);
    },
    d(i) {
      i && D(n);
    }
  };
}
function _l(t) {
  let e;
  return {
    c() {
      e = J("-");
    },
    m(n, i) {
      F(n, e, i);
    },
    d(n) {
      n && D(e);
    }
  };
}
function dl(t) {
  let e = (100 * /*progress_level*/
  (t[14][
    /*i*/
    t[41]
  ] || 0)).toFixed(1) + "", n, i;
  return {
    c() {
      n = J(e), i = J("%");
    },
    m(l, o) {
      F(l, n, o), F(l, i, o);
    },
    p(l, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (l[14][
        /*i*/
        l[41]
      ] || 0)).toFixed(1) + "") && we(n, e);
    },
    d(l) {
      l && (D(n), D(i));
    }
  };
}
function hl(t) {
  let e, n = (
    /*p*/
    (t[39].desc != null || /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[41]
    ] != null) && fl(t)
  );
  return {
    c() {
      n && n.c(), e = St();
    },
    m(i, l) {
      n && n.m(i, l), F(i, e, l);
    },
    p(i, l) {
      /*p*/
      i[39].desc != null || /*progress_level*/
      i[14] && /*progress_level*/
      i[14][
        /*i*/
        i[41]
      ] != null ? n ? n.p(i, l) : (n = fl(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && D(e), n && n.d(i);
    }
  };
}
function ml(t) {
  let e, n;
  return {
    c() {
      e = Be("p"), n = J(
        /*loading_text*/
        t[9]
      ), Le(e, "class", "loading svelte-1txqlrd");
    },
    m(i, l) {
      F(i, e, l), ot(e, n);
    },
    p(i, l) {
      l[0] & /*loading_text*/
      512 && we(
        n,
        /*loading_text*/
        i[9]
      );
    },
    d(i) {
      i && D(e);
    }
  };
}
function a_(t) {
  let e, n, i, l, o;
  const s = [xc, $c], r = [];
  function a(u, f) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = a(t)) && (i = r[n] = s[n](t)), {
    c() {
      e = Be("div"), i && i.c(), Le(e, "class", l = "wrap " + /*variant*/
      t[8] + " " + /*show_progress*/
      t[6] + " svelte-1txqlrd"), pe(e, "hide", !/*status*/
      t[4] || /*status*/
      t[4] === "complete" || /*show_progress*/
      t[6] === "hidden"), pe(
        e,
        "translucent",
        /*variant*/
        t[8] === "center" && /*status*/
        (t[4] === "pending" || /*status*/
        t[4] === "error") || /*translucent*/
        t[11] || /*show_progress*/
        t[6] === "minimal"
      ), pe(
        e,
        "generating",
        /*status*/
        t[4] === "generating"
      ), pe(
        e,
        "border",
        /*border*/
        t[12]
      ), Ye(
        e,
        "position",
        /*absolute*/
        t[10] ? "absolute" : "static"
      ), Ye(
        e,
        "padding",
        /*absolute*/
        t[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, f) {
      F(u, e, f), ~n && r[n].m(e, null), t[31](e), o = !0;
    },
    p(u, f) {
      let c = n;
      n = a(u), n === c ? ~n && r[n].p(u, f) : (i && (ho(), kt(r[c], 1, 1, () => {
        r[c] = null;
      }), co()), ~n ? (i = r[n], i ? i.p(u, f) : (i = r[n] = s[n](u), i.c()), yt(i, 1), i.m(e, null)) : i = null), (!o || f[0] & /*variant, show_progress*/
      320 && l !== (l = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-1txqlrd")) && Le(e, "class", l), (!o || f[0] & /*variant, show_progress, status, show_progress*/
      336) && pe(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden"), (!o || f[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && pe(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!o || f[0] & /*variant, show_progress, status*/
      336) && pe(
        e,
        "generating",
        /*status*/
        u[4] === "generating"
      ), (!o || f[0] & /*variant, show_progress, border*/
      4416) && pe(
        e,
        "border",
        /*border*/
        u[12]
      ), f[0] & /*absolute*/
      1024 && Ye(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), f[0] & /*absolute*/
      1024 && Ye(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      o || (yt(i), o = !0);
    },
    o(u) {
      kt(i), o = !1;
    },
    d(u) {
      u && D(e), ~n && r[n].d(), t[31](null);
    }
  };
}
var u_ = function(t, e, n, i) {
  function l(o) {
    return o instanceof n ? o : new n(function(s) {
      s(o);
    });
  }
  return new (n || (n = Promise))(function(o, s) {
    function r(f) {
      try {
        u(i.next(f));
      } catch (c) {
        s(c);
      }
    }
    function a(f) {
      try {
        u(i.throw(f));
      } catch (c) {
        s(c);
      }
    }
    function u(f) {
      f.done ? o(f.value) : l(f.value).then(r, a);
    }
    u((i = i.apply(t, e || [])).next());
  });
};
let Jt = [], Vn = !1;
function f_(t) {
  return u_(this, arguments, void 0, function* (e, n = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && n !== !0)) {
      if (Jt.push(e), !Vn) Vn = !0;
      else return;
      yield Hc(), requestAnimationFrame(() => {
        let i = [0, 0];
        for (let l = 0; l < Jt.length; l++) {
          const s = Jt[l].getBoundingClientRect();
          (l === 0 || s.top + window.scrollY <= i[0]) && (i[0] = s.top + window.scrollY, i[1] = l);
        }
        window.scrollTo({ top: i[0] - 20, behavior: "smooth" }), Vn = !1, Jt = [];
      });
    }
  });
}
function c_(t, e, n) {
  let i, { $$slots: l = {}, $$scope: o } = e;
  this && this.__awaiter;
  let { i18n: s } = e, { eta: r = null } = e, { queue: a = !1 } = e, { queue_position: u } = e, { queue_size: f } = e, { status: c } = e, { scroll_to_output: _ = !1 } = e, { timer: d = !0 } = e, { show_progress: h = "full" } = e, { message: k = null } = e, { progress: y = null } = e, { variant: p = "default" } = e, { loading_text: v = "Loading..." } = e, { absolute: b = !0 } = e, { translucent: m = !1 } = e, { border: g = !1 } = e, { autoscroll: A } = e, E, z = !1, P = 0, R = 0, j = null, L = 0, Y = null, C, w = null, V = !0;
  const T = () => {
    n(25, P = performance.now()), n(26, R = 0), z = !0, N();
  };
  function N() {
    requestAnimationFrame(() => {
      n(26, R = (performance.now() - P) / 1e3), z && N();
    });
  }
  function U() {
    n(26, R = 0), z && (z = !1);
  }
  Zc(() => {
    z && U();
  });
  let O = null;
  function q(S) {
    tl[S ? "unshift" : "push"](() => {
      w = S, n(16, w), n(7, y), n(14, Y), n(15, C);
    });
  }
  function I(S) {
    tl[S ? "unshift" : "push"](() => {
      E = S, n(13, E);
    });
  }
  return t.$$set = (S) => {
    "i18n" in S && n(1, s = S.i18n), "eta" in S && n(0, r = S.eta), "queue" in S && n(21, a = S.queue), "queue_position" in S && n(2, u = S.queue_position), "queue_size" in S && n(3, f = S.queue_size), "status" in S && n(4, c = S.status), "scroll_to_output" in S && n(22, _ = S.scroll_to_output), "timer" in S && n(5, d = S.timer), "show_progress" in S && n(6, h = S.show_progress), "message" in S && n(23, k = S.message), "progress" in S && n(7, y = S.progress), "variant" in S && n(8, p = S.variant), "loading_text" in S && n(9, v = S.loading_text), "absolute" in S && n(10, b = S.absolute), "translucent" in S && n(11, m = S.translucent), "border" in S && n(12, g = S.border), "autoscroll" in S && n(24, A = S.autoscroll), "$$scope" in S && n(28, o = S.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*eta, old_eta, queue, timer_start*/
    169869313 && (r === null ? n(0, r = j) : a && n(0, r = (performance.now() - P) / 1e3 + r), r != null && (n(19, O = r.toFixed(1)), n(27, j = r))), t.$$.dirty[0] & /*eta, timer_diff*/
    67108865 && n(17, L = r === null || r <= 0 || !R ? null : Math.min(R / r, 1)), t.$$.dirty[0] & /*progress*/
    128 && y != null && n(18, V = !1), t.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (y != null ? n(14, Y = y.map((S) => {
      if (S.index != null && S.length != null)
        return S.index / S.length;
      if (S.progress != null)
        return S.progress;
    })) : n(14, Y = null), Y ? (n(15, C = Y[Y.length - 1]), w && (C === 0 ? n(16, w.style.transition = "0", w) : n(16, w.style.transition = "150ms", w))) : n(15, C = void 0)), t.$$.dirty[0] & /*status*/
    16 && (c === "pending" ? T() : U()), t.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && E && _ && (c === "pending" || c === "complete") && f_(E, A), t.$$.dirty[0] & /*status, message*/
    8388624, t.$$.dirty[0] & /*timer_diff*/
    67108864 && n(20, i = R.toFixed(1));
  }, [
    r,
    s,
    u,
    f,
    c,
    d,
    h,
    y,
    p,
    v,
    b,
    m,
    g,
    E,
    Y,
    C,
    w,
    L,
    V,
    O,
    i,
    a,
    _,
    k,
    A,
    P,
    R,
    j,
    o,
    l,
    q,
    I
  ];
}
class mo extends Rc {
  constructor(e) {
    super(), Gc(
      this,
      e,
      c_,
      a_,
      Yc,
      {
        i18n: 1,
        eta: 0,
        queue: 21,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: __,
  add_flush_callback: d_,
  assign: h_,
  bind: m_,
  binding_callbacks: g_,
  create_component: _n,
  destroy_component: dn,
  detach: p_,
  flush: ne,
  get_spread_object: b_,
  get_spread_update: w_,
  init: v_,
  insert: y_,
  mount_component: hn,
  safe_not_equal: k_,
  space: S_,
  transition_in: mn,
  transition_out: gn
} = window.__gradio__svelte__internal;
function q_(t) {
  let e, n;
  return e = new Lu({
    props: {
      i18n: (
        /*gradio*/
        t[17].i18n
      ),
      type: "image"
    }
  }), {
    c() {
      _n(e.$$.fragment);
    },
    m(i, l) {
      hn(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*gradio*/
      131072 && (o.i18n = /*gradio*/
      i[17].i18n), e.$set(o);
    },
    i(i) {
      n || (mn(e.$$.fragment, i), n = !0);
    },
    o(i) {
      gn(e.$$.fragment, i), n = !1;
    },
    d(i) {
      dn(e, i);
    }
  };
}
function C_(t) {
  let e, n, i, l, o;
  const s = [
    {
      autoscroll: (
        /*gradio*/
        t[17].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      t[17].i18n
    ) },
    /*loading_status*/
    t[12]
  ];
  let r = {};
  for (let f = 0; f < s.length; f += 1)
    r = h_(r, s[f]);
  e = new mo({ props: r });
  function a(f) {
    t[20](f);
  }
  let u = {
    slider_color: (
      /*slider_color*/
      t[16]
    ),
    position: (
      /*position*/
      t[14]
    ),
    root: (
      /*root*/
      t[13]
    ),
    label: (
      /*label*/
      t[4]
    ),
    show_label: (
      /*show_label*/
      t[5]
    ),
    upload_count: (
      /*upload_count*/
      t[15]
    ),
    show_download_button: (
      /*show_download_button*/
      t[6]
    ),
    $$slots: { default: [q_] },
    $$scope: { ctx: t }
  };
  return (
    /*value*/
    t[0] !== void 0 && (u.value = /*value*/
    t[0]), i = new Cc({ props: u }), g_.push(() => m_(i, "value", a)), i.$on(
      "edit",
      /*edit_handler*/
      t[21]
    ), i.$on(
      "clear",
      /*clear_handler*/
      t[22]
    ), i.$on(
      "stream",
      /*stream_handler*/
      t[23]
    ), i.$on(
      "drag",
      /*drag_handler*/
      t[24]
    ), i.$on(
      "upload",
      /*handle_upload*/
      t[19]
    ), i.$on(
      "select",
      /*select_handler*/
      t[25]
    ), i.$on(
      "share",
      /*share_handler*/
      t[26]
    ), {
      c() {
        _n(e.$$.fragment), n = S_(), _n(i.$$.fragment);
      },
      m(f, c) {
        hn(e, f, c), y_(f, n, c), hn(i, f, c), o = !0;
      },
      p(f, c) {
        const _ = c & /*gradio, loading_status*/
        135168 ? w_(s, [
          c & /*gradio*/
          131072 && {
            autoscroll: (
              /*gradio*/
              f[17].autoscroll
            )
          },
          c & /*gradio*/
          131072 && { i18n: (
            /*gradio*/
            f[17].i18n
          ) },
          c & /*loading_status*/
          4096 && b_(
            /*loading_status*/
            f[12]
          )
        ]) : {};
        e.$set(_);
        const d = {};
        c & /*slider_color*/
        65536 && (d.slider_color = /*slider_color*/
        f[16]), c & /*position*/
        16384 && (d.position = /*position*/
        f[14]), c & /*root*/
        8192 && (d.root = /*root*/
        f[13]), c & /*label*/
        16 && (d.label = /*label*/
        f[4]), c & /*show_label*/
        32 && (d.show_label = /*show_label*/
        f[5]), c & /*upload_count*/
        32768 && (d.upload_count = /*upload_count*/
        f[15]), c & /*show_download_button*/
        64 && (d.show_download_button = /*show_download_button*/
        f[6]), c & /*$$scope, gradio*/
        268566528 && (d.$$scope = { dirty: c, ctx: f }), !l && c & /*value*/
        1 && (l = !0, d.value = /*value*/
        f[0], d_(() => l = !1)), i.$set(d);
      },
      i(f) {
        o || (mn(e.$$.fragment, f), mn(i.$$.fragment, f), o = !0);
      },
      o(f) {
        gn(e.$$.fragment, f), gn(i.$$.fragment, f), o = !1;
      },
      d(f) {
        f && p_(n), dn(e, f), dn(i, f);
      }
    }
  );
}
function E_(t) {
  let e, n;
  return e = new Ul({
    props: {
      visible: (
        /*visible*/
        t[3]
      ),
      variant: (
        /*value*/
        t[0] === null ? "dashed" : "solid"
      ),
      border_mode: (
        /*dragging*/
        t[18] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        t[1]
      ),
      elem_classes: (
        /*elem_classes*/
        t[2]
      ),
      height: (
        /*height*/
        t[7]
      ),
      width: (
        /*width*/
        t[8]
      ),
      allow_overflow: !1,
      container: (
        /*container*/
        t[9]
      ),
      scale: (
        /*scale*/
        t[10]
      ),
      min_width: (
        /*min_width*/
        t[11]
      ),
      $$slots: { default: [C_] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      _n(e.$$.fragment);
    },
    m(i, l) {
      hn(e, i, l), n = !0;
    },
    p(i, [l]) {
      const o = {};
      l & /*visible*/
      8 && (o.visible = /*visible*/
      i[3]), l & /*value*/
      1 && (o.variant = /*value*/
      i[0] === null ? "dashed" : "solid"), l & /*dragging*/
      262144 && (o.border_mode = /*dragging*/
      i[18] ? "focus" : "base"), l & /*elem_id*/
      2 && (o.elem_id = /*elem_id*/
      i[1]), l & /*elem_classes*/
      4 && (o.elem_classes = /*elem_classes*/
      i[2]), l & /*height*/
      128 && (o.height = /*height*/
      i[7]), l & /*width*/
      256 && (o.width = /*width*/
      i[8]), l & /*container*/
      512 && (o.container = /*container*/
      i[9]), l & /*scale*/
      1024 && (o.scale = /*scale*/
      i[10]), l & /*min_width*/
      2048 && (o.min_width = /*min_width*/
      i[11]), l & /*$$scope, slider_color, position, root, label, show_label, upload_count, show_download_button, value, gradio, dragging, loading_status*/
      268955761 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (mn(e.$$.fragment, i), n = !0);
    },
    o(i) {
      gn(e.$$.fragment, i), n = !1;
    },
    d(i) {
      dn(e, i);
    }
  };
}
function N_(t, e, n) {
  var i = this && this.__awaiter || function(w, V, T, N) {
    function U(O) {
      return O instanceof T ? O : new T(function(q) {
        q(O);
      });
    }
    return new (T || (T = Promise))(function(O, q) {
      function I(Q) {
        try {
          W(N.next(Q));
        } catch (X) {
          q(X);
        }
      }
      function S(Q) {
        try {
          W(N.throw(Q));
        } catch (X) {
          q(X);
        }
      }
      function W(Q) {
        Q.done ? O(Q.value) : U(Q.value).then(I, S);
      }
      W((N = N.apply(w, V || [])).next());
    });
  };
  let { elem_id: l = "" } = e, { elem_classes: o = [] } = e, { visible: s = !0 } = e, { value: r = [null, null] } = e, { label: a } = e, { show_label: u } = e, { show_download_button: f = !0 } = e, { height: c } = e, { width: _ } = e, { container: d = !0 } = e, { scale: h = null } = e, { min_width: k = void 0 } = e, { loading_status: y } = e, { root: p } = e, { position: v } = e, { upload_count: b = 2 } = e, { slider_color: m } = e, { gradio: g } = e, A;
  function E(w) {
    return i(this, arguments, void 0, function* ({ detail: V }) {
      n(0, r = V), g.dispatch("upload");
    });
  }
  function z(w) {
    r = w, n(0, r), n(13, p);
  }
  const P = () => g.dispatch("edit"), R = () => g.dispatch("clear"), j = () => g.dispatch("stream"), L = ({ detail: w }) => n(18, A = w), Y = ({ detail: w }) => g.dispatch("select", w), C = ({ detail: w }) => g.dispatch("share", w);
  return t.$$set = (w) => {
    "elem_id" in w && n(1, l = w.elem_id), "elem_classes" in w && n(2, o = w.elem_classes), "visible" in w && n(3, s = w.visible), "value" in w && n(0, r = w.value), "label" in w && n(4, a = w.label), "show_label" in w && n(5, u = w.show_label), "show_download_button" in w && n(6, f = w.show_download_button), "height" in w && n(7, c = w.height), "width" in w && n(8, _ = w.width), "container" in w && n(9, d = w.container), "scale" in w && n(10, h = w.scale), "min_width" in w && n(11, k = w.min_width), "loading_status" in w && n(12, y = w.loading_status), "root" in w && n(13, p = w.root), "position" in w && n(14, v = w.position), "upload_count" in w && n(15, b = w.upload_count), "slider_color" in w && n(16, m = w.slider_color), "gradio" in w && n(17, g = w.gradio);
  }, t.$$.update = () => {
    t.$$.dirty & /*value, root*/
    8193 && n(0, r = r ? Ee(r, p, null) : null), t.$$.dirty & /*value, gradio*/
    131073 && g.dispatch("change");
  }, [
    r,
    l,
    o,
    s,
    a,
    u,
    f,
    c,
    _,
    d,
    h,
    k,
    y,
    p,
    v,
    b,
    m,
    g,
    A,
    E,
    z,
    P,
    R,
    j,
    L,
    Y,
    C
  ];
}
class A_ extends __ {
  constructor(e) {
    super(), v_(this, e, N_, E_, k_, {
      elem_id: 1,
      elem_classes: 2,
      visible: 3,
      value: 0,
      label: 4,
      show_label: 5,
      show_download_button: 6,
      height: 7,
      width: 8,
      container: 9,
      scale: 10,
      min_width: 11,
      loading_status: 12,
      root: 13,
      position: 14,
      upload_count: 15,
      slider_color: 16,
      gradio: 17
    });
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), ne();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), ne();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), ne();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), ne();
  }
  get label() {
    return this.$$.ctx[4];
  }
  set label(e) {
    this.$$set({ label: e }), ne();
  }
  get show_label() {
    return this.$$.ctx[5];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), ne();
  }
  get show_download_button() {
    return this.$$.ctx[6];
  }
  set show_download_button(e) {
    this.$$set({ show_download_button: e }), ne();
  }
  get height() {
    return this.$$.ctx[7];
  }
  set height(e) {
    this.$$set({ height: e }), ne();
  }
  get width() {
    return this.$$.ctx[8];
  }
  set width(e) {
    this.$$set({ width: e }), ne();
  }
  get container() {
    return this.$$.ctx[9];
  }
  set container(e) {
    this.$$set({ container: e }), ne();
  }
  get scale() {
    return this.$$.ctx[10];
  }
  set scale(e) {
    this.$$set({ scale: e }), ne();
  }
  get min_width() {
    return this.$$.ctx[11];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), ne();
  }
  get loading_status() {
    return this.$$.ctx[12];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), ne();
  }
  get root() {
    return this.$$.ctx[13];
  }
  set root(e) {
    this.$$set({ root: e }), ne();
  }
  get position() {
    return this.$$.ctx[14];
  }
  set position(e) {
    this.$$set({ position: e }), ne();
  }
  get upload_count() {
    return this.$$.ctx[15];
  }
  set upload_count(e) {
    this.$$set({ upload_count: e }), ne();
  }
  get slider_color() {
    return this.$$.ctx[16];
  }
  set slider_color(e) {
    this.$$set({ slider_color: e }), ne();
  }
  get gradio() {
    return this.$$.ctx[17];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), ne();
  }
}
const {
  SvelteComponent: z_,
  add_flush_callback: L_,
  add_iframe_resize_listener: D_,
  add_render_callback: F_,
  attr: ae,
  bind: O_,
  binding_callbacks: I_,
  check_outros: go,
  create_component: qt,
  destroy_component: Ct,
  detach: Ke,
  element: pn,
  empty: T_,
  group_outros: po,
  init: B_,
  insert: He,
  mount_component: Et,
  safe_not_equal: P_,
  space: di,
  src_url_equal: Yt,
  toggle_class: Kt,
  transition_in: Ne,
  transition_out: Fe
} = window.__gradio__svelte__internal;
function M_(t) {
  let e, n, i, l, o, s, r, a = (
    /*show_download_button*/
    t[4] && gl(t)
  );
  function u(c) {
    t[12](c);
  }
  let f = {
    slider_color: (
      /*slider_color*/
      t[9]
    ),
    $$slots: { default: [j_] },
    $$scope: { ctx: t }
  };
  return (
    /*position*/
    t[1] !== void 0 && (f.position = /*position*/
    t[1]), l = new Pl({ props: f }), I_.push(() => O_(l, "position", u)), {
      c() {
        e = pn("div"), a && a.c(), n = di(), i = pn("div"), qt(l.$$.fragment), ae(e, "class", "icon-buttons svelte-1qi1njr"), ae(i, "class", "slider-wrap svelte-1qi1njr"), F_(() => (
          /*div1_elementresize_handler*/
          t[13].call(i)
        ));
      },
      m(c, _) {
        He(c, e, _), a && a.m(e, null), He(c, n, _), He(c, i, _), Et(l, i, null), s = D_(
          i,
          /*div1_elementresize_handler*/
          t[13].bind(i)
        ), r = !0;
      },
      p(c, _) {
        /*show_download_button*/
        c[4] ? a ? (a.p(c, _), _ & /*show_download_button*/
        16 && Ne(a, 1)) : (a = gl(c), a.c(), Ne(a, 1), a.m(e, null)) : a && (po(), Fe(a, 1, 1, () => {
          a = null;
        }), go());
        const d = {};
        _ & /*slider_color*/
        512 && (d.slider_color = /*slider_color*/
        c[9]), _ & /*$$scope, value, style, layer_images*/
        17537 && (d.$$scope = { dirty: _, ctx: c }), !o && _ & /*position*/
        2 && (o = !0, d.position = /*position*/
        c[1], L_(() => o = !1)), l.$set(d);
      },
      i(c) {
        r || (Ne(a), Ne(l.$$.fragment, c), r = !0);
      },
      o(c) {
        Fe(a), Fe(l.$$.fragment, c), r = !1;
      },
      d(c) {
        c && (Ke(e), Ke(n), Ke(i)), a && a.d(), Ct(l), s();
      }
    }
  );
}
function R_(t) {
  let e, n;
  return e = new Xl({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [V_] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      qt(e.$$.fragment);
    },
    m(i, l) {
      Et(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*$$scope*/
      16384 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (Ne(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Fe(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Ct(e, i);
    }
  };
}
function gl(t) {
  let e, n;
  return e = new ui({
    props: {
      href: (
        /*value*/
        t[0][1].url
      ),
      download: (
        /*value*/
        t[0][1].orig_name || "image"
      ),
      $$slots: { default: [U_] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      qt(e.$$.fragment);
    },
    m(i, l) {
      Et(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*value*/
      1 && (o.href = /*value*/
      i[0][1].url), l & /*value*/
      1 && (o.download = /*value*/
      i[0][1].orig_name || "image"), l & /*$$scope, i18n*/
      16448 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (Ne(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Fe(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Ct(e, i);
    }
  };
}
function U_(t) {
  let e, n;
  return e = new vn({
    props: {
      Icon: li,
      label: (
        /*i18n*/
        t[6]("common.download")
      )
    }
  }), {
    c() {
      qt(e.$$.fragment);
    },
    m(i, l) {
      Et(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*i18n*/
      64 && (o.label = /*i18n*/
      i[6]("common.download")), e.$set(o);
    },
    i(i) {
      n || (Ne(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Fe(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Ct(e, i);
    }
  };
}
function j_(t) {
  let e, n, i, l, o;
  return {
    c() {
      e = pn("img"), i = di(), l = pn("img"), Yt(e.src, n = /*value*/
      t[0]?.[0]?.url) || ae(e, "src", n), ae(e, "alt", ""), ae(e, "loading", "lazy"), ae(e, "class", "svelte-1qi1njr"), Yt(l.src, o = /*value*/
      t[0]?.[1]?.url) || ae(l, "src", o), ae(l, "alt", ""), ae(l, "loading", "lazy"), ae(
        l,
        "style",
        /*style*/
        t[10]
      ), ae(l, "class", "svelte-1qi1njr"), Kt(
        l,
        "fixed",
        /*layer_images*/
        t[7]
      ), Kt(l, "hidden", !/*value*/
      t[0]?.[1]?.url);
    },
    m(s, r) {
      He(s, e, r), He(s, i, r), He(s, l, r);
    },
    p(s, r) {
      r & /*value*/
      1 && !Yt(e.src, n = /*value*/
      s[0]?.[0]?.url) && ae(e, "src", n), r & /*value*/
      1 && !Yt(l.src, o = /*value*/
      s[0]?.[1]?.url) && ae(l, "src", o), r & /*style*/
      1024 && ae(
        l,
        "style",
        /*style*/
        s[10]
      ), r & /*layer_images*/
      128 && Kt(
        l,
        "fixed",
        /*layer_images*/
        s[7]
      ), r & /*value*/
      1 && Kt(l, "hidden", !/*value*/
      s[0]?.[1]?.url);
    },
    d(s) {
      s && (Ke(e), Ke(i), Ke(l));
    }
  };
}
function V_(t) {
  let e, n;
  return e = new yn({}), {
    c() {
      qt(e.$$.fragment);
    },
    m(i, l) {
      Et(e, i, l), n = !0;
    },
    i(i) {
      n || (Ne(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Fe(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Ct(e, i);
    }
  };
}
function W_(t) {
  let e, n, i, l, o, s;
  e = new jl({
    props: {
      show_label: (
        /*show_label*/
        t[5]
      ),
      Icon: yn,
      label: (
        /*label*/
        t[3] || /*i18n*/
        t[6]("image.image")
      )
    }
  });
  const r = [R_, M_], a = [];
  function u(f, c) {
    return (
      /*value*/
      (f[0] === null || /*value*/
      f[0][0] === null || /*value*/
      f[0][1] === null) && !/*show_single*/
      f[8] ? 0 : 1
    );
  }
  return i = u(t), l = a[i] = r[i](t), {
    c() {
      qt(e.$$.fragment), n = di(), l.c(), o = T_();
    },
    m(f, c) {
      Et(e, f, c), He(f, n, c), a[i].m(f, c), He(f, o, c), s = !0;
    },
    p(f, [c]) {
      const _ = {};
      c & /*show_label*/
      32 && (_.show_label = /*show_label*/
      f[5]), c & /*label, i18n*/
      72 && (_.label = /*label*/
      f[3] || /*i18n*/
      f[6]("image.image")), e.$set(_);
      let d = i;
      i = u(f), i === d ? a[i].p(f, c) : (po(), Fe(a[d], 1, 1, () => {
        a[d] = null;
      }), go(), l = a[i], l ? l.p(f, c) : (l = a[i] = r[i](f), l.c()), Ne(l, 1), l.m(o.parentNode, o));
    },
    i(f) {
      s || (Ne(e.$$.fragment, f), Ne(l), s = !0);
    },
    o(f) {
      Fe(e.$$.fragment, f), Fe(l), s = !1;
    },
    d(f) {
      f && (Ke(n), Ke(o)), Ct(e, f), a[i].d(f);
    }
  };
}
function X_(t, e, n) {
  let i, { value: l = [null, null] } = e, { label: o = void 0 } = e, { show_download_button: s = !0 } = e, { show_label: r } = e, { root: a } = e, { i18n: u } = e, { position: f } = e, { layer_images: c = !0 } = e, { show_single: _ = !1 } = e, { slider_color: d } = e, { el_width: h } = e;
  function k(p) {
    f = p, n(1, f);
  }
  function y() {
    h = this.clientWidth, n(2, h);
  }
  return t.$$set = (p) => {
    "value" in p && n(0, l = p.value), "label" in p && n(3, o = p.label), "show_download_button" in p && n(4, s = p.show_download_button), "show_label" in p && n(5, r = p.show_label), "root" in p && n(11, a = p.root), "i18n" in p && n(6, u = p.i18n), "position" in p && n(1, f = p.position), "layer_images" in p && n(7, c = p.layer_images), "show_single" in p && n(8, _ = p.show_single), "slider_color" in p && n(9, d = p.slider_color), "el_width" in p && n(2, h = p.el_width);
  }, t.$$.update = () => {
    t.$$.dirty & /*value, root*/
    2049 && n(0, l = Ee(l, a, null)), t.$$.dirty & /*layer_images, position*/
    130 && n(10, i = c ? `clip-path: inset(0 0 0 ${f * 100}%)` : "");
  }, [
    l,
    f,
    h,
    o,
    s,
    r,
    u,
    c,
    _,
    d,
    i,
    a,
    k,
    y
  ];
}
class G_ extends z_ {
  constructor(e) {
    super(), B_(this, e, X_, W_, P_, {
      value: 0,
      label: 3,
      show_download_button: 4,
      show_label: 5,
      root: 11,
      i18n: 6,
      position: 1,
      layer_images: 7,
      show_single: 8,
      slider_color: 9,
      el_width: 2
    });
  }
}
const {
  SvelteComponent: J_,
  add_flush_callback: pl,
  assign: Y_,
  attr: bl,
  bind: wl,
  binding_callbacks: vl,
  check_outros: K_,
  create_component: Tt,
  destroy_component: Bt,
  detach: Ht,
  element: yl,
  flush: x,
  get_spread_object: H_,
  get_spread_update: Z_,
  group_outros: Q_,
  init: $_,
  insert: Zt,
  mount_component: Pt,
  safe_not_equal: x_,
  set_style: Qt,
  space: kl,
  toggle_class: Sl,
  transition_in: Je,
  transition_out: st
} = window.__gradio__svelte__internal;
function ql(t) {
  let e, n;
  return e = new ui({
    props: {
      href: (
        /*value*/
        t[0][1].url
      ),
      download: (
        /*value*/
        t[0][1].orig_name || "image"
      ),
      $$slots: { default: [ed] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      Tt(e.$$.fragment);
    },
    m(i, l) {
      Pt(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*value*/
      1 && (o.href = /*value*/
      i[0][1].url), l & /*value*/
      1 && (o.download = /*value*/
      i[0][1].orig_name || "image"), l & /*$$scope, i18n*/
      268439552 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (Je(e.$$.fragment, i), n = !0);
    },
    o(i) {
      st(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Bt(e, i);
    }
  };
}
function ed(t) {
  let e, n;
  return e = new vn({
    props: {
      Icon: li,
      label: (
        /*i18n*/
        t[12]("common.download")
      )
    }
  }), {
    c() {
      Tt(e.$$.fragment);
    },
    m(i, l) {
      Pt(e, i, l), n = !0;
    },
    p(i, l) {
      const o = {};
      l & /*i18n*/
      4096 && (o.label = /*i18n*/
      i[12]("common.download")), e.$set(o);
    },
    i(i) {
      n || (Je(e.$$.fragment, i), n = !0);
    },
    o(i) {
      st(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Bt(e, i);
    }
  };
}
function td(t) {
  let e, n, i, l, o = `${/*is_half*/
  t[20] ? (
    /*el_width*/
    t[19] * (1 - /*position*/
    t[1])
  ) : (
    /*el_width*/
    t[19]
  )}px`, s = `translateX(${/*is_half*/
  t[20] ? (
    /*el_width*/
    t[19] * /*position*/
    t[1]
  ) : 0}px)`, r, a, u, f, c, _ = (
    /*show_download_button*/
    t[8] && /*value*/
    t[0] && /*value*/
    t[0][1] && ql(t)
  );
  const d = [
    {
      autoscroll: (
        /*gradio*/
        t[18].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      t[18].i18n
    ) },
    /*loading_status*/
    t[17]
  ];
  let h = {};
  for (let v = 0; v < d.length; v += 1)
    h = Y_(h, d[v]);
  l = new mo({ props: h });
  function k(v) {
    t[23](v);
  }
  function y(v) {
    t[24](v);
  }
  let p = {
    root: (
      /*root*/
      t[7]
    ),
    value: (
      /*value*/
      t[0]
    ),
    label: (
      /*label*/
      t[5]
    ),
    show_label: (
      /*show_label*/
      t[6]
    ),
    i18n: (
      /*gradio*/
      t[18].i18n
    ),
    layer_images: (
      /*layer_images*/
      t[11]
    ),
    show_single: (
      /*is_half*/
      t[20]
    ),
    slider_color: (
      /*slider_color*/
      t[13]
    ),
    show_download_button: (
      /*show_download_button*/
      t[8]
    )
  };
  return (
    /*position*/
    t[1] !== void 0 && (p.position = /*position*/
    t[1]), /*el_width*/
    t[19] !== void 0 && (p.el_width = /*el_width*/
    t[19]), a = new G_({ props: p }), vl.push(() => wl(a, "position", k)), vl.push(() => wl(a, "el_width", y)), a.$on(
      "select",
      /*select_handler*/
      t[25]
    ), a.$on(
      "share",
      /*share_handler*/
      t[26]
    ), a.$on(
      "error",
      /*error_handler*/
      t[27]
    ), {
      c() {
        e = yl("div"), _ && _.c(), n = kl(), i = yl("div"), Tt(l.$$.fragment), r = kl(), Tt(a.$$.fragment), bl(e, "class", "icon-buttons svelte-6wvohu"), bl(i, "class", "status-wrap svelte-6wvohu"), Sl(
          i,
          "half",
          /*is_half*/
          t[20]
        ), Qt(i, "width", o), Qt(i, "transform", s);
      },
      m(v, b) {
        Zt(v, e, b), _ && _.m(e, null), Zt(v, n, b), Zt(v, i, b), Pt(l, i, null), Zt(v, r, b), Pt(a, v, b), c = !0;
      },
      p(v, b) {
        /*show_download_button*/
        v[8] && /*value*/
        v[0] && /*value*/
        v[0][1] ? _ ? (_.p(v, b), b & /*show_download_button, value*/
        257 && Je(_, 1)) : (_ = ql(v), _.c(), Je(_, 1), _.m(e, null)) : _ && (Q_(), st(_, 1, 1, () => {
          _ = null;
        }), K_());
        const m = b & /*gradio, loading_status*/
        393216 ? Z_(d, [
          b & /*gradio*/
          262144 && {
            autoscroll: (
              /*gradio*/
              v[18].autoscroll
            )
          },
          b & /*gradio*/
          262144 && { i18n: (
            /*gradio*/
            v[18].i18n
          ) },
          b & /*loading_status*/
          131072 && H_(
            /*loading_status*/
            v[17]
          )
        ]) : {};
        l.$set(m), (!c || b & /*is_half*/
        1048576) && Sl(
          i,
          "half",
          /*is_half*/
          v[20]
        ), b & /*is_half, el_width, position*/
        1572866 && o !== (o = `${/*is_half*/
        v[20] ? (
          /*el_width*/
          v[19] * (1 - /*position*/
          v[1])
        ) : (
          /*el_width*/
          v[19]
        )}px`) && Qt(i, "width", o), b & /*is_half, el_width, position*/
        1572866 && s !== (s = `translateX(${/*is_half*/
        v[20] ? (
          /*el_width*/
          v[19] * /*position*/
          v[1]
        ) : 0}px)`) && Qt(i, "transform", s);
        const g = {};
        b & /*root*/
        128 && (g.root = /*root*/
        v[7]), b & /*value*/
        1 && (g.value = /*value*/
        v[0]), b & /*label*/
        32 && (g.label = /*label*/
        v[5]), b & /*show_label*/
        64 && (g.show_label = /*show_label*/
        v[6]), b & /*gradio*/
        262144 && (g.i18n = /*gradio*/
        v[18].i18n), b & /*layer_images*/
        2048 && (g.layer_images = /*layer_images*/
        v[11]), b & /*is_half*/
        1048576 && (g.show_single = /*is_half*/
        v[20]), b & /*slider_color*/
        8192 && (g.slider_color = /*slider_color*/
        v[13]), b & /*show_download_button*/
        256 && (g.show_download_button = /*show_download_button*/
        v[8]), !u && b & /*position*/
        2 && (u = !0, g.position = /*position*/
        v[1], pl(() => u = !1)), !f && b & /*el_width*/
        524288 && (f = !0, g.el_width = /*el_width*/
        v[19], pl(() => f = !1)), a.$set(g);
      },
      i(v) {
        c || (Je(_), Je(l.$$.fragment, v), Je(a.$$.fragment, v), c = !0);
      },
      o(v) {
        st(_), st(l.$$.fragment, v), st(a.$$.fragment, v), c = !1;
      },
      d(v) {
        v && (Ht(e), Ht(n), Ht(i), Ht(r)), _ && _.d(), Bt(l), Bt(a, v);
      }
    }
  );
}
function nd(t) {
  let e, n;
  return e = new Ul({
    props: {
      visible: (
        /*visible*/
        t[4]
      ),
      variant: "solid",
      border_mode: (
        /*dragging*/
        t[21] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        t[2]
      ),
      elem_classes: (
        /*elem_classes*/
        t[3]
      ),
      height: (
        /*height*/
        t[9]
      ),
      width: (
        /*width*/
        t[10]
      ),
      allow_overflow: !1,
      container: (
        /*container*/
        t[14]
      ),
      scale: (
        /*scale*/
        t[15]
      ),
      min_width: (
        /*min_width*/
        t[16]
      ),
      $$slots: { default: [td] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      Tt(e.$$.fragment);
    },
    m(i, l) {
      Pt(e, i, l), n = !0;
    },
    p(i, [l]) {
      const o = {};
      l & /*visible*/
      16 && (o.visible = /*visible*/
      i[4]), l & /*elem_id*/
      4 && (o.elem_id = /*elem_id*/
      i[2]), l & /*elem_classes*/
      8 && (o.elem_classes = /*elem_classes*/
      i[3]), l & /*height*/
      512 && (o.height = /*height*/
      i[9]), l & /*width*/
      1024 && (o.width = /*width*/
      i[10]), l & /*container*/
      16384 && (o.container = /*container*/
      i[14]), l & /*scale*/
      32768 && (o.scale = /*scale*/
      i[15]), l & /*min_width*/
      65536 && (o.min_width = /*min_width*/
      i[16]), l & /*$$scope, root, value, label, show_label, gradio, layer_images, is_half, slider_color, show_download_button, position, el_width, loading_status, i18n*/
      270416355 && (o.$$scope = { dirty: l, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (Je(e.$$.fragment, i), n = !0);
    },
    o(i) {
      st(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Bt(e, i);
    }
  };
}
function id(t, e, n) {
  let i, { elem_id: l = "" } = e, { elem_classes: o = [] } = e, { visible: s = !0 } = e, { value: r = null } = e, { label: a } = e, { show_label: u } = e, { root: f } = e, { upload_count: c = 2 } = e, { show_download_button: _ = !0 } = e, { height: d } = e, { width: h } = e, { layer_images: k = !0 } = e, { i18n: y } = e, { slider_color: p } = e, { container: v = !0 } = e, { scale: b = null } = e, { min_width: m = void 0 } = e, { loading_status: g } = e, { gradio: A } = e, { position: E } = e, z, P;
  function R(w) {
    E = w, n(1, E);
  }
  function j(w) {
    z = w, n(19, z);
  }
  const L = ({ detail: w }) => A.dispatch("select", w), Y = ({ detail: w }) => A.dispatch("share", w), C = ({ detail: w }) => A.dispatch("error", w);
  return t.$$set = (w) => {
    "elem_id" in w && n(2, l = w.elem_id), "elem_classes" in w && n(3, o = w.elem_classes), "visible" in w && n(4, s = w.visible), "value" in w && n(0, r = w.value), "label" in w && n(5, a = w.label), "show_label" in w && n(6, u = w.show_label), "root" in w && n(7, f = w.root), "upload_count" in w && n(22, c = w.upload_count), "show_download_button" in w && n(8, _ = w.show_download_button), "height" in w && n(9, d = w.height), "width" in w && n(10, h = w.width), "layer_images" in w && n(11, k = w.layer_images), "i18n" in w && n(12, y = w.i18n), "slider_color" in w && n(13, p = w.slider_color), "container" in w && n(14, v = w.container), "scale" in w && n(15, b = w.scale), "min_width" in w && n(16, m = w.min_width), "loading_status" in w && n(17, g = w.loading_status), "gradio" in w && n(18, A = w.gradio), "position" in w && n(1, E = w.position);
  }, t.$$.update = () => {
    t.$$.dirty & /*value*/
    1 && n(0, r = r || null), t.$$.dirty & /*value, gradio*/
    262145 && A.dispatch("change"), t.$$.dirty & /*upload_count, value*/
    4194305 && n(20, i = c === 1 && r && r[0] != null && r[1] == null);
  }, [
    r,
    E,
    l,
    o,
    s,
    a,
    u,
    f,
    _,
    d,
    h,
    k,
    y,
    p,
    v,
    b,
    m,
    g,
    A,
    z,
    i,
    P,
    c,
    R,
    j,
    L,
    Y,
    C
  ];
}
class ld extends J_ {
  constructor(e) {
    super(), $_(this, e, id, nd, x_, {
      elem_id: 2,
      elem_classes: 3,
      visible: 4,
      value: 0,
      label: 5,
      show_label: 6,
      root: 7,
      upload_count: 22,
      show_download_button: 8,
      height: 9,
      width: 10,
      layer_images: 11,
      i18n: 12,
      slider_color: 13,
      container: 14,
      scale: 15,
      min_width: 16,
      loading_status: 17,
      gradio: 18,
      position: 1
    });
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), x();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), x();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(e) {
    this.$$set({ visible: e }), x();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), x();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(e) {
    this.$$set({ label: e }), x();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), x();
  }
  get root() {
    return this.$$.ctx[7];
  }
  set root(e) {
    this.$$set({ root: e }), x();
  }
  get upload_count() {
    return this.$$.ctx[22];
  }
  set upload_count(e) {
    this.$$set({ upload_count: e }), x();
  }
  get show_download_button() {
    return this.$$.ctx[8];
  }
  set show_download_button(e) {
    this.$$set({ show_download_button: e }), x();
  }
  get height() {
    return this.$$.ctx[9];
  }
  set height(e) {
    this.$$set({ height: e }), x();
  }
  get width() {
    return this.$$.ctx[10];
  }
  set width(e) {
    this.$$set({ width: e }), x();
  }
  get layer_images() {
    return this.$$.ctx[11];
  }
  set layer_images(e) {
    this.$$set({ layer_images: e }), x();
  }
  get i18n() {
    return this.$$.ctx[12];
  }
  set i18n(e) {
    this.$$set({ i18n: e }), x();
  }
  get slider_color() {
    return this.$$.ctx[13];
  }
  set slider_color(e) {
    this.$$set({ slider_color: e }), x();
  }
  get container() {
    return this.$$.ctx[14];
  }
  set container(e) {
    this.$$set({ container: e }), x();
  }
  get scale() {
    return this.$$.ctx[15];
  }
  set scale(e) {
    this.$$set({ scale: e }), x();
  }
  get min_width() {
    return this.$$.ctx[16];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), x();
  }
  get loading_status() {
    return this.$$.ctx[17];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), x();
  }
  get gradio() {
    return this.$$.ctx[18];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), x();
  }
  get position() {
    return this.$$.ctx[1];
  }
  set position(e) {
    this.$$set({ position: e }), x();
  }
}
const {
  SvelteComponent: od,
  add_flush_callback: bo,
  bind: wo,
  binding_callbacks: vo,
  check_outros: sd,
  create_component: yo,
  destroy_component: ko,
  detach: rd,
  empty: ad,
  flush: le,
  group_outros: ud,
  init: fd,
  insert: cd,
  mount_component: So,
  safe_not_equal: _d,
  transition_in: bn,
  transition_out: wn
} = window.__gradio__svelte__internal;
function dd(t) {
  let e, n, i;
  function l(s) {
    t[17](s);
  }
  let o = {
    slider_color: (
      /*slider_color*/
      t[14]
    ),
    i18n: (
      /*gradio*/
      t[15].i18n
    ),
    elem_id: (
      /*elem_id*/
      t[1]
    ),
    elem_classes: (
      /*elem_classes*/
      t[2]
    ),
    visible: (
      /*visible*/
      t[3]
    ),
    label: (
      /*label*/
      t[4]
    ),
    show_label: (
      /*show_label*/
      t[6]
    ),
    show_download_button: (
      /*show_download_button*/
      t[5]
    ),
    loading_status: (
      /*loading_status*/
      t[10]
    ),
    height: (
      /*height*/
      t[8]
    ),
    width: (
      /*width*/
      t[9]
    ),
    root: (
      /*root*/
      t[7]
    ),
    gradio: (
      /*gradio*/
      t[15]
    ),
    position: (
      /*position*/
      t[12]
    ),
    layer_images: !0,
    upload_count: (
      /*upload_count*/
      t[13]
    )
  };
  return (
    /*value*/
    t[0] !== void 0 && (o.value = /*value*/
    t[0]), e = new ld({ props: o }), vo.push(() => wo(e, "value", l)), {
      c() {
        yo(e.$$.fragment);
      },
      m(s, r) {
        So(e, s, r), i = !0;
      },
      p(s, r) {
        const a = {};
        r & /*slider_color*/
        16384 && (a.slider_color = /*slider_color*/
        s[14]), r & /*gradio*/
        32768 && (a.i18n = /*gradio*/
        s[15].i18n), r & /*elem_id*/
        2 && (a.elem_id = /*elem_id*/
        s[1]), r & /*elem_classes*/
        4 && (a.elem_classes = /*elem_classes*/
        s[2]), r & /*visible*/
        8 && (a.visible = /*visible*/
        s[3]), r & /*label*/
        16 && (a.label = /*label*/
        s[4]), r & /*show_label*/
        64 && (a.show_label = /*show_label*/
        s[6]), r & /*show_download_button*/
        32 && (a.show_download_button = /*show_download_button*/
        s[5]), r & /*loading_status*/
        1024 && (a.loading_status = /*loading_status*/
        s[10]), r & /*height*/
        256 && (a.height = /*height*/
        s[8]), r & /*width*/
        512 && (a.width = /*width*/
        s[9]), r & /*root*/
        128 && (a.root = /*root*/
        s[7]), r & /*gradio*/
        32768 && (a.gradio = /*gradio*/
        s[15]), r & /*position*/
        4096 && (a.position = /*position*/
        s[12]), r & /*upload_count*/
        8192 && (a.upload_count = /*upload_count*/
        s[13]), !n && r & /*value*/
        1 && (n = !0, a.value = /*value*/
        s[0], bo(() => n = !1)), e.$set(a);
      },
      i(s) {
        i || (bn(e.$$.fragment, s), i = !0);
      },
      o(s) {
        wn(e.$$.fragment, s), i = !1;
      },
      d(s) {
        ko(e, s);
      }
    }
  );
}
function hd(t) {
  let e, n, i;
  function l(s) {
    t[16](s);
  }
  let o = {
    slider_color: (
      /*slider_color*/
      t[14]
    ),
    elem_id: (
      /*elem_id*/
      t[1]
    ),
    elem_classes: (
      /*elem_classes*/
      t[2]
    ),
    visible: (
      /*visible*/
      t[3]
    ),
    label: (
      /*label*/
      t[4]
    ),
    show_label: (
      /*show_label*/
      t[6]
    ),
    show_download_button: (
      /*show_download_button*/
      t[5]
    ),
    loading_status: (
      /*loading_status*/
      t[10]
    ),
    height: (
      /*height*/
      t[8]
    ),
    width: (
      /*width*/
      t[9]
    ),
    root: (
      /*root*/
      t[7]
    ),
    gradio: (
      /*gradio*/
      t[15]
    ),
    position: (
      /*position*/
      t[12]
    ),
    upload_count: (
      /*upload_count*/
      t[13]
    )
  };
  return (
    /*value*/
    t[0] !== void 0 && (o.value = /*value*/
    t[0]), e = new A_({ props: o }), vo.push(() => wo(e, "value", l)), {
      c() {
        yo(e.$$.fragment);
      },
      m(s, r) {
        So(e, s, r), i = !0;
      },
      p(s, r) {
        const a = {};
        r & /*slider_color*/
        16384 && (a.slider_color = /*slider_color*/
        s[14]), r & /*elem_id*/
        2 && (a.elem_id = /*elem_id*/
        s[1]), r & /*elem_classes*/
        4 && (a.elem_classes = /*elem_classes*/
        s[2]), r & /*visible*/
        8 && (a.visible = /*visible*/
        s[3]), r & /*label*/
        16 && (a.label = /*label*/
        s[4]), r & /*show_label*/
        64 && (a.show_label = /*show_label*/
        s[6]), r & /*show_download_button*/
        32 && (a.show_download_button = /*show_download_button*/
        s[5]), r & /*loading_status*/
        1024 && (a.loading_status = /*loading_status*/
        s[10]), r & /*height*/
        256 && (a.height = /*height*/
        s[8]), r & /*width*/
        512 && (a.width = /*width*/
        s[9]), r & /*root*/
        128 && (a.root = /*root*/
        s[7]), r & /*gradio*/
        32768 && (a.gradio = /*gradio*/
        s[15]), r & /*position*/
        4096 && (a.position = /*position*/
        s[12]), r & /*upload_count*/
        8192 && (a.upload_count = /*upload_count*/
        s[13]), !n && r & /*value*/
        1 && (n = !0, a.value = /*value*/
        s[0], bo(() => n = !1)), e.$set(a);
      },
      i(s) {
        i || (bn(e.$$.fragment, s), i = !0);
      },
      o(s) {
        wn(e.$$.fragment, s), i = !1;
      },
      d(s) {
        ko(e, s);
      }
    }
  );
}
function md(t) {
  let e, n, i, l;
  const o = [hd, dd], s = [];
  function r(a, u) {
    return (
      /*interactive*/
      a[11] ? 0 : 1
    );
  }
  return e = r(t), n = s[e] = o[e](t), {
    c() {
      n.c(), i = ad();
    },
    m(a, u) {
      s[e].m(a, u), cd(a, i, u), l = !0;
    },
    p(a, [u]) {
      let f = e;
      e = r(a), e === f ? s[e].p(a, u) : (ud(), wn(s[f], 1, 1, () => {
        s[f] = null;
      }), sd(), n = s[e], n ? n.p(a, u) : (n = s[e] = o[e](a), n.c()), bn(n, 1), n.m(i.parentNode, i));
    },
    i(a) {
      l || (bn(n), l = !0);
    },
    o(a) {
      wn(n), l = !1;
    },
    d(a) {
      a && rd(i), s[e].d(a);
    }
  };
}
function gd(t, e, n) {
  let { elem_id: i = "" } = e, { elem_classes: l = [] } = e, { visible: o = !0 } = e, { value: s = [null, null] } = e, { label: r } = e, { show_download_button: a } = e, { show_label: u } = e, { root: f } = e, { height: c } = e, { width: _ } = e, { loading_status: d } = e, { interactive: h } = e, { position: k } = e, { upload_count: y = 2 } = e, { slider_color: p = "var(--border-color-primary)" } = e, { gradio: v } = e;
  function b(g) {
    s = g, n(0, s);
  }
  function m(g) {
    s = g, n(0, s);
  }
  return t.$$set = (g) => {
    "elem_id" in g && n(1, i = g.elem_id), "elem_classes" in g && n(2, l = g.elem_classes), "visible" in g && n(3, o = g.visible), "value" in g && n(0, s = g.value), "label" in g && n(4, r = g.label), "show_download_button" in g && n(5, a = g.show_download_button), "show_label" in g && n(6, u = g.show_label), "root" in g && n(7, f = g.root), "height" in g && n(8, c = g.height), "width" in g && n(9, _ = g.width), "loading_status" in g && n(10, d = g.loading_status), "interactive" in g && n(11, h = g.interactive), "position" in g && n(12, k = g.position), "upload_count" in g && n(13, y = g.upload_count), "slider_color" in g && n(14, p = g.slider_color), "gradio" in g && n(15, v = g.gradio);
  }, [
    s,
    i,
    l,
    o,
    r,
    a,
    u,
    f,
    c,
    _,
    d,
    h,
    k,
    y,
    p,
    v,
    b,
    m
  ];
}
class Sd extends od {
  constructor(e) {
    super(), fd(this, e, gd, md, _d, {
      elem_id: 1,
      elem_classes: 2,
      visible: 3,
      value: 0,
      label: 4,
      show_download_button: 5,
      show_label: 6,
      root: 7,
      height: 8,
      width: 9,
      loading_status: 10,
      interactive: 11,
      position: 12,
      upload_count: 13,
      slider_color: 14,
      gradio: 15
    });
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), le();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), le();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), le();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), le();
  }
  get label() {
    return this.$$.ctx[4];
  }
  set label(e) {
    this.$$set({ label: e }), le();
  }
  get show_download_button() {
    return this.$$.ctx[5];
  }
  set show_download_button(e) {
    this.$$set({ show_download_button: e }), le();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), le();
  }
  get root() {
    return this.$$.ctx[7];
  }
  set root(e) {
    this.$$set({ root: e }), le();
  }
  get height() {
    return this.$$.ctx[8];
  }
  set height(e) {
    this.$$set({ height: e }), le();
  }
  get width() {
    return this.$$.ctx[9];
  }
  set width(e) {
    this.$$set({ width: e }), le();
  }
  get loading_status() {
    return this.$$.ctx[10];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), le();
  }
  get interactive() {
    return this.$$.ctx[11];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), le();
  }
  get position() {
    return this.$$.ctx[12];
  }
  set position(e) {
    this.$$set({ position: e }), le();
  }
  get upload_count() {
    return this.$$.ctx[13];
  }
  set upload_count(e) {
    this.$$set({ upload_count: e }), le();
  }
  get slider_color() {
    return this.$$.ctx[14];
  }
  set slider_color(e) {
    this.$$set({ slider_color: e }), le();
  }
  get gradio() {
    return this.$$.ctx[15];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), le();
  }
}
export {
  Sd as default
};
