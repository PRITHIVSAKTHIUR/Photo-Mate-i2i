const {
  SvelteComponent: b,
  append: g,
  attr: n,
  detach: k,
  element: m,
  init: y,
  insert: p,
  noop: w,
  safe_not_equal: h,
  space: o,
  src_url_equal: d,
  toggle_class: f
} = window.__gradio__svelte__internal;
function q(a) {
  let e, l, c, u, i, r, s, v;
  return {
    c() {
      e = m("div"), l = m("img"), u = o(), i = m("img"), s = o(), v = m("span"), d(l.src, c = /*samples_dir*/
      a[1] + /*value*/
      a[0][0]) || n(l, "src", c), n(l, "class", "svelte-l4wpk0"), d(i.src, r = /*samples_dir*/
      a[1] + /*value*/
      a[0][1]) || n(i, "src", r), n(i, "class", "svelte-l4wpk0"), n(v, "class", "svelte-l4wpk0"), n(e, "class", "wrap svelte-l4wpk0"), f(
        e,
        "table",
        /*type*/
        a[2] === "table"
      ), f(
        e,
        "gallery",
        /*type*/
        a[2] === "gallery"
      ), f(
        e,
        "selected",
        /*selected*/
        a[3]
      );
    },
    m(t, _) {
      p(t, e, _), g(e, l), g(e, u), g(e, i), g(e, s), g(e, v);
    },
    p(t, [_]) {
      _ & /*samples_dir, value*/
      3 && !d(l.src, c = /*samples_dir*/
      t[1] + /*value*/
      t[0][0]) && n(l, "src", c), _ & /*samples_dir, value*/
      3 && !d(i.src, r = /*samples_dir*/
      t[1] + /*value*/
      t[0][1]) && n(i, "src", r), _ & /*type*/
      4 && f(
        e,
        "table",
        /*type*/
        t[2] === "table"
      ), _ & /*type*/
      4 && f(
        e,
        "gallery",
        /*type*/
        t[2] === "gallery"
      ), _ & /*selected*/
      8 && f(
        e,
        "selected",
        /*selected*/
        t[3]
      );
    },
    i: w,
    o: w,
    d(t) {
      t && k(e);
    }
  };
}
function C(a, e, l) {
  let { value: c } = e, { samples_dir: u } = e, { type: i } = e, { selected: r = !1 } = e;
  return a.$$set = (s) => {
    "value" in s && l(0, c = s.value), "samples_dir" in s && l(1, u = s.samples_dir), "type" in s && l(2, i = s.type), "selected" in s && l(3, r = s.selected);
  }, [c, u, i, r];
}
class I extends b {
  constructor(e) {
    super(), y(this, e, C, q, h, {
      value: 0,
      samples_dir: 1,
      type: 2,
      selected: 3
    });
  }
}
export {
  I as default
};
